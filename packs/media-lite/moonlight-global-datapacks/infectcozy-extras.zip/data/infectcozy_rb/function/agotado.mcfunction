item replace entity @s weapon.mainhand with minecraft:air
playsound minecraft:entity.item.break player @a ~ ~ ~ 1 1
title @s actionbar {"text":"El rompedor de piedra base se gastó.","color":"gray"}
