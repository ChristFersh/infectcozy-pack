# Rompedor de piedra base: clic derecho con el objeto apuntando a la piedra base
scoreboard objectives add ic_rb_uso minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add ic_rb dummy
scoreboard objectives add ic_rb_cd dummy
#   dar uno (admins):  /function infectcozy_rb:dar
