# (como el jugador) gasta un uso; sin encantamientos para que Reparacion no lo vuelva infinito
item modify entity @s weapon.mainhand infectcozy_rb:gastar
execute store result score @s ic_rb run data get entity @s SelectedItem.components."minecraft:damage"
execute if score @s ic_rb matches 16.. run function infectcozy_rb:agotado
