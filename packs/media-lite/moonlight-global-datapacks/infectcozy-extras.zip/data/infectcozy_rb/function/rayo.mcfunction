# avanza 0,1 bloques por paso desde los ojos, hasta 5 bloques, y se detiene en el primer bloque solido
scoreboard players add #paso ic_rb 1
execute if score #paso ic_rb matches 51.. run return 0
execute if block ~ ~ ~ #infectcozy_rb:atravesable positioned ^ ^ ^0.1 run return run function infectcozy_rb:rayo
execute unless block ~ ~ ~ minecraft:bedrock run return run scoreboard players set #res ic_rb 2
# debajo esta el vacio: es la capa del fondo del mundo
execute if block ~ ~-1 ~ minecraft:void_air run return run scoreboard players set #res ic_rb 3
execute align xyz positioned ~0.5 ~0.5 ~0.5 run function infectcozy_rb:romper
