# /function infectcozy_rb:dar  -> te da un Rompedor de piedra base
loot give @s loot infectcozy_rb:rompedor
