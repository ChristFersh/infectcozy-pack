scoreboard players remove @a[scores={ic_rb_cd=1..}] ic_rb_cd 1
execute as @a[scores={ic_rb_uso=1..}] at @s run function infectcozy_rb:usar
