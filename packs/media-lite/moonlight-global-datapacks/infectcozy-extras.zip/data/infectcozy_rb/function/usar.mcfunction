# (como y en el jugador) uso con clic derecho
scoreboard players reset @s ic_rb_uso
execute unless items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{infectcozy_rompebase:1b}] run return 0
# medio segundo entre usos (si mantienes el clic, no gasta todo de golpe)
execute if score @s ic_rb_cd matches 1.. run return 0
scoreboard players set @s ic_rb_cd 10
execute unless dimension minecraft:overworld unless dimension minecraft:the_nether unless dimension minecraft:the_end run return run title @s actionbar {"text":"El rompedor no funciona en esta dimensión.","color":"red"}
scoreboard players set #paso ic_rb 0
scoreboard players set #res ic_rb 0
execute anchored eyes positioned ^ ^ ^ run function infectcozy_rb:rayo
execute if score #res ic_rb matches 0 run title @s actionbar {"text":"Apunta a la piedra base, a menos de 5 bloques.","color":"gray"}
execute if score #res ic_rb matches 2 run title @s actionbar {"text":"Eso no es piedra base.","color":"gray"}
execute if score #res ic_rb matches 3 run title @s actionbar {"text":"Es la capa del fondo del mundo: esa no se puede romper.","color":"red"}
execute if score #res ic_rb matches 1 run function infectcozy_rb:gastar
