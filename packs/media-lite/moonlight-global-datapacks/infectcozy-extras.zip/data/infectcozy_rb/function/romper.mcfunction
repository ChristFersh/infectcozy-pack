# (en el centro del bloque de piedra base)
setblock ~ ~ ~ minecraft:air destroy
particle minecraft:reverse_portal ~ ~ ~ 0.3 0.3 0.3 0.05 40
playsound minecraft:block.respawn_anchor.deplete block @a ~ ~ ~ 1 0.7
scoreboard players set #res ic_rb 1
