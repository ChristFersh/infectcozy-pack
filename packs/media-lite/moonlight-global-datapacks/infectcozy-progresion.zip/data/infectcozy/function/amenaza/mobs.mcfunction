function infectcozy:amenaza/jefes
execute unless score #amz_on ic_amz matches 1 run return 0
# Cada enemigo nuevo a 64 bloques de algun jugador toma el nivel del jugador MAS CERCANO a el
# (antes: el del jugador mas fuerte de la zona, y un novato junto a un veterano peleaba contra nivel 5).
execute as @a[gamemode=!creative,gamemode=!spectator] at @s as @e[distance=..64,tag=!ic_amz,type=!#infectcozy:amenaza_ignorar,tag=!apostle,tag=!inf_pla_boss] at @s run function infectcozy:amenaza/cercano
