# infectcozy:amenaza/jefe_aplicar  (como y en el jefe; #jl = nivel, #jn = jugadores)
#   nivel 1-3: sin cambios | 4: x1,5 vida, +15 % dano, +2 por golpe | 5: x2, +30 %, +4
#   6: x3, +50 %, +6 | 7: x4, +75 %, +8
#   Grupo: +50 % de la vida base por cada jugador extra (hasta +200 %).
#   "Por golpe" es dano extra que ignora armadura y Proteccion (advancement amenaza/furia_N).
#   Los jefes con tope de dano por segundo (infectcozy:jefes_con_tope, los de Cataclysm) solo suben el dano.
execute store result score #v0 ic_tmp run attribute @s minecraft:generic.max_health get 1
scoreboard players operation @s ic_jefe_l = #jl ic_tmp
scoreboard players operation @s ic_jefe_n = #jn ic_tmp
attribute @s minecraft:generic.max_health modifier remove infectcozy:jefe_vida
attribute @s minecraft:generic.max_health modifier remove infectcozy:jefe_grupo
attribute @s minecraft:generic.attack_damage modifier remove infectcozy:jefe_dano
tag @s remove ic_jf4
tag @s remove ic_jf5
tag @s remove ic_jf6
tag @s remove ic_jf7
# dano (todos los jefes)
execute if score #jl ic_tmp matches 4 run attribute @s minecraft:generic.attack_damage modifier add infectcozy:jefe_dano 0.15 add_multiplied_base
execute if score #jl ic_tmp matches 5 run attribute @s minecraft:generic.attack_damage modifier add infectcozy:jefe_dano 0.3 add_multiplied_base
execute if score #jl ic_tmp matches 6 run attribute @s minecraft:generic.attack_damage modifier add infectcozy:jefe_dano 0.5 add_multiplied_base
execute if score #jl ic_tmp matches 7 run attribute @s minecraft:generic.attack_damage modifier add infectcozy:jefe_dano 0.75 add_multiplied_base
execute if score #jl ic_tmp matches 4 run tag @s add ic_jf4
execute if score #jl ic_tmp matches 5 run tag @s add ic_jf5
execute if score #jl ic_tmp matches 6 run tag @s add ic_jf6
execute if score #jl ic_tmp matches 7 run tag @s add ic_jf7
# vida (menos los que tienen tope de dano)
execute unless entity @s[type=#infectcozy:jefes_con_tope] run function infectcozy:amenaza/jefe_vida
# la vida actual sube lo mismo que la maxima (si la pelea ya empezo, no lo cura del todo)
execute store result score #v1 ic_tmp run attribute @s minecraft:generic.max_health get 1
scoreboard players operation #v1 ic_tmp -= #v0 ic_tmp
execute store result score #h ic_tmp run data get entity @s Health 1
scoreboard players operation #h ic_tmp += #v1 ic_tmp
execute if score #v1 ic_tmp matches 1.. store result entity @s Health float 1 run scoreboard players get #h ic_tmp
tag @s add ic_jefe_esc
# aviso a los jugadores cercanos
execute if score #jl ic_tmp matches 4.. run function infectcozy:amenaza/jefe_aviso
execute if score #jl ic_tmp matches ..3 if score #jn ic_tmp matches 2.. run function infectcozy:amenaza/jefe_aviso
