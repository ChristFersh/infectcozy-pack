# infectcozy:amenaza/arbol  (como el jugador)
# Puntos ganados en el arbol de combate de Pufferfish's Skills. Funcion aparte: si falta el mod, solo esta no carga.
execute store result score @s ic_amz_arb run puffish_skills points get @s puffish_skills:combat
