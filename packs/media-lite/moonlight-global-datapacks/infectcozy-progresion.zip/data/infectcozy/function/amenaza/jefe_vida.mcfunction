# infectcozy:amenaza/jefe_vida  (como el jefe)
execute if score #jl ic_tmp matches 4 run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_vida 0.5 add_multiplied_base
execute if score #jl ic_tmp matches 5 run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_vida 1.0 add_multiplied_base
execute if score #jl ic_tmp matches 6 run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_vida 2.0 add_multiplied_base
execute if score #jl ic_tmp matches 7 run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_vida 3.0 add_multiplied_base
execute if score #jn ic_tmp matches 2 run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_grupo 0.5 add_multiplied_base
execute if score #jn ic_tmp matches 3 run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_grupo 1.0 add_multiplied_base
execute if score #jn ic_tmp matches 4 run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_grupo 1.5 add_multiplied_base
execute if score #jn ic_tmp matches 5.. run attribute @s minecraft:generic.max_health modifier add infectcozy:jefe_grupo 2.0 add_multiplied_base
