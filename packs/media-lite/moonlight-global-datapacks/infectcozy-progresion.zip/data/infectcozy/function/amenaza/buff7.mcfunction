# nivel 7: +250 % vida, +100 % dano, +10 armadura
attribute @s minecraft:generic.max_health modifier add infectcozy:amenaza_vida 2.5 add_multiplied_base
attribute @s minecraft:generic.attack_damage modifier add infectcozy:amenaza_dano 1.0 add_multiplied_base
attribute @s minecraft:generic.armor modifier add infectcozy:amenaza_armadura 10 add_value
