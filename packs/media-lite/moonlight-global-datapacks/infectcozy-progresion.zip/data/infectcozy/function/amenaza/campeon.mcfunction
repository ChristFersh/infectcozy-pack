# Campeones segun el nivel (sustituye a los campeones al azar del mod):
#   nivel 1: 3 % rango 1 | 2: 4 % rango 1-2 | 3: 5 % rango 2-3 | 4: 6 % rango 3-4 | 5: 7 % rango 4-5
#   nivel 6: 8 % y nivel 7: 9 %, rango 5 (el maximo de Champions; campeones/aplicar no pasa de 5)
execute if entity @s[tag=ic_camp_x] run return 0
scoreboard players operation #p ic_tmp = #amz_l ic_tmp
scoreboard players add #p ic_tmp 2
execute store result score #r ic_tmp run random value 1..100
execute if score #r ic_tmp > #p ic_tmp run return 0
tag @s add ic_camp_x
scoreboard players operation #camp_rank ic_camp = #amz_l ic_tmp
scoreboard players remove #camp_rank ic_camp 1
execute store result score #r ic_tmp run random value 1..100
execute if score #r ic_tmp matches ..50 run scoreboard players add #camp_rank ic_camp 1
execute if score #camp_rank ic_camp matches ..0 run scoreboard players set #camp_rank ic_camp 1
function infectcozy:campeones/aplicar
