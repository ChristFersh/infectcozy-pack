# infectcozy:amenaza/furia/n4  (como el jugador golpeado por un jefe de nivel 4)
# 2 de dano extra que ignora armadura y Proteccion; el mensaje de muerte nombra al jefe.
# Como mucho una vez cada 10 ticks, para que las rafagas de proyectiles no la sumen varias veces.
advancement revoke @s only infectcozy:amenaza/furia_4
execute if score @s ic_furia matches 1.. run return 0
scoreboard players set @s ic_furia 10
damage @s 2 infectcozy:furia_jefe by @e[tag=ic_jf4,distance=..128,sort=nearest,limit=1]
