# infectcozy:amenaza/jefes  -  cada segundo: jefes adaptativos
# Los jefes (etiqueta infectcozy:jefes_adaptativos) toman el nivel de amenaza del jugador mas fuerte a 48 bloques
# y ganan vida por cada jugador extra. Interruptor: scoreboard players set #amz_jefes ic_amz 0
execute unless score #amz_jefes ic_amz matches 1 run return 0
# (se busca desde cada jugador, que es mas barato que revisar todas las entidades; si hay dos cerca, la segunda pasada no cambia nada)
execute as @a[gamemode=!creative,gamemode=!spectator] at @s as @e[type=#infectcozy:jefes_adaptativos,distance=..48] at @s run function infectcozy:amenaza/jefe
