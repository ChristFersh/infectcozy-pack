# infectcozy:amenaza/jefe  (como y en el jefe)
execute on owner run return 0
# nivel = el mas alto de los jugadores a 48 bloques; grupo = cuantos jugadores hay (hasta 5)
scoreboard players set #jl ic_tmp 1
execute as @a[gamemode=!creative,gamemode=!spectator,distance=..48] if score @s ic_amz_n > #jl ic_tmp run scoreboard players operation #jl ic_tmp = @s ic_amz_n
execute if score #jl ic_tmp matches 8.. run scoreboard players set #jl ic_tmp 7
execute store result score #jn ic_tmp if entity @a[gamemode=!creative,gamemode=!spectator,distance=..48]
execute if score #jn ic_tmp matches 6.. run scoreboard players set #jn ic_tmp 5
# nunca baja: se queda con lo mas alto que haya visto en esta pelea
scoreboard players add @s ic_jefe_l 0
scoreboard players add @s ic_jefe_n 0
execute if score #jl ic_tmp < @s ic_jefe_l run scoreboard players operation #jl ic_tmp = @s ic_jefe_l
execute if score #jn ic_tmp < @s ic_jefe_n run scoreboard players operation #jn ic_tmp = @s ic_jefe_n
execute if score #jl ic_tmp = @s ic_jefe_l if score #jn ic_tmp = @s ic_jefe_n run return 0
function infectcozy:amenaza/jefe_aplicar
