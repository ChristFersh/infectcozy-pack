# infectcozy:amenaza/calcular  (como el jugador)
# Mide el equipo que LLEVA: armadura (hasta 20, lo maximo que cuenta en Minecraft) y ataque (cuerpo a cuerpo,
# hechizos o arco). Lo guardado baja 1 punto por minuto hasta lo que lleva ahora: cambiar de arma un momento
# no cambia el nivel, pero probarse equipo prestado o quitarselo si lo baja con el tiempo.
execute store result score #a ic_tmp run attribute @s minecraft:generic.armor get 1
execute if score #a ic_tmp matches 21.. run scoreboard players set #a ic_tmp 20
# ataque cuerpo a cuerpo (sin contar la pocion de fuerza)
scoreboard players set #k ic_tmp 0
execute unless predicate infectcozy:amenaza_fuerza store result score #k ic_tmp run attribute @s minecraft:generic.attack_damage get 1
# magos y arqueros (funciones aparte: si falta el mod, solo esas no cargan)
function infectcozy:amenaza/hechizo
function infectcozy:amenaza/distancia
# lo guardado: baja 1 por minuto, nunca por debajo de lo que lleva ahora
execute if score @s ic_amz_arm matches 21.. run scoreboard players set @s ic_amz_arm 20
execute if score #amz_dec ic_amz matches 1 run scoreboard players remove @s ic_amz_arm 1
execute if score #amz_dec ic_amz matches 1 run scoreboard players remove @s ic_amz_atk 1
execute unless score @s ic_amz_arm >= #a ic_tmp run scoreboard players operation @s ic_amz_arm = #a ic_tmp
execute unless score @s ic_amz_atk >= #k ic_tmp run scoreboard players operation @s ic_amz_atk = #k ic_tmp
# puntaje = armadura + ataque + 3 por cada jefe derrotado + la mitad de los puntos del arbol de combate
scoreboard players operation #g ic_tmp = @s ic_amz_arm
scoreboard players operation #g ic_tmp += @s ic_amz_atk
scoreboard players add @s ic_jefes 0
scoreboard players operation #j ic_tmp = @s ic_jefes
scoreboard players operation #j ic_tmp *= #c3 ic_amz
scoreboard players operation #g ic_tmp += #j ic_tmp
# arbol de combate (Pufferfish's Skills): 148 nodos -> hasta +74
function infectcozy:amenaza/arbol
scoreboard players add @s ic_amz_arb 0
scoreboard players operation #t ic_tmp = @s ic_amz_arb
scoreboard players operation #t ic_tmp /= #c2 ic_amz
execute if score #t ic_tmp matches 75.. run scoreboard players set #t ic_tmp 74
execute if score #t ic_tmp matches ..-1 run scoreboard players set #t ic_tmp 0
scoreboard players operation #g ic_tmp += #t ic_tmp
scoreboard players operation @s ic_amz_g = #g ic_tmp
# niveles
scoreboard players set #n ic_tmp 1
execute if score #g ic_tmp matches 20.. run scoreboard players set #n ic_tmp 2
execute if score #g ic_tmp matches 32.. run scoreboard players set #n ic_tmp 3
execute if score #g ic_tmp matches 48.. run scoreboard players set #n ic_tmp 4
execute if score #g ic_tmp matches 75.. run scoreboard players set #n ic_tmp 5
execute if score #g ic_tmp matches 110.. run scoreboard players set #n ic_tmp 6
execute if score #g ic_tmp matches 145.. run scoreboard players set #n ic_tmp 7
scoreboard players add @s ic_amz_n 0
execute if score #n ic_tmp > @s ic_amz_n if score @s ic_amz_n matches 1.. run function infectcozy:amenaza/subio
scoreboard players operation @s ic_amz_n = #n ic_tmp
