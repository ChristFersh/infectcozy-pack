# infectcozy:amenaza/load  -  Nivel de amenaza: los enemigos se adaptan al equipo del jugador
scoreboard objectives add ic_tmp dummy
scoreboard objectives add ic_amz dummy
scoreboard objectives add ic_amz_arm dummy
scoreboard objectives add ic_amz_atk dummy
scoreboard objectives add ic_amz_g dummy
scoreboard objectives add ic_amz_n dummy
scoreboard objectives add ic_jefes dummy
scoreboard objectives add amenaza trigger
scoreboard objectives add ic_amz_arb dummy
scoreboard objectives add ic_jefe_l dummy
scoreboard objectives add ic_jefe_n dummy
scoreboard objectives add ic_furia dummy
# Interruptores para admins (1 = activo, 0 = apagado):
#   scoreboard players set #amz_on ic_amz 0      -> sin escalado de enemigos
#   scoreboard players set #amz_camp ic_amz 0    -> sin campeones por nivel
#   scoreboard players set #amz_jefes ic_amz 0   -> sin jefes adaptativos
execute unless score #amz_on ic_amz matches 0..1 run scoreboard players set #amz_on ic_amz 1
execute unless score #amz_camp ic_amz matches 0..1 run scoreboard players set #amz_camp ic_amz 1
execute unless score #amz_jefes ic_amz matches 0..1 run scoreboard players set #amz_jefes ic_amz 1
scoreboard players set #c2 ic_amz 2
scoreboard players set #c3 ic_amz 3
scoreboard players add #amz_t ic_amz 0
