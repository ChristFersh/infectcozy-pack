# infectcozy:amenaza/cercano  (como y en el enemigo)  -> #amz_l = nivel del jugador mas cercano, #amz_nov = 1 si es novato
scoreboard players set #amz_l ic_tmp 1
scoreboard players set #amz_nov ic_tmp 0
execute as @p[gamemode=!creative,gamemode=!spectator] run scoreboard players operation #amz_l ic_tmp = @s ic_amz_n
execute as @p[gamemode=!creative,gamemode=!spectator] if entity @s[tag=ic_novato] run scoreboard players set #amz_nov ic_tmp 1
execute if score #amz_l ic_tmp matches ..1 run scoreboard players set #amz_l ic_tmp 1
execute if score #amz_l ic_tmp matches 8.. run scoreboard players set #amz_l ic_tmp 7
function infectcozy:amenaza/mob
