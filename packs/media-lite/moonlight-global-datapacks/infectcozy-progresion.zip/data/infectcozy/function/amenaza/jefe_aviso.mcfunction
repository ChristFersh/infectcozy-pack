# infectcozy:amenaza/jefe_aviso  (como y en el jefe)
tellraw @a[distance=..48] [{"text":"☣ ","color":"dark_red"},{"selector":"@s","color":"red","bold":true},{"text":" se adapta a sus rivales: nivel ","color":"gray"},{"score":{"name":"#jl","objective":"ic_tmp"},"color":"red","bold":true},{"text":", ","color":"gray"},{"score":{"name":"#jn","objective":"ic_tmp"},"color":"white"},{"text":" jugador(es)","color":"gray"}]
playsound minecraft:entity.warden.heartbeat hostile @a[distance=..48] ~ ~ ~ 1 0.5
particle minecraft:sculk_soul ~ ~1.5 ~ 1 1.5 1 0.05 60 force
