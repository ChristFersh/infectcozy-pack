# nivel 6: +200 % vida, +80 % dano, +8 armadura
attribute @s minecraft:generic.max_health modifier add infectcozy:amenaza_vida 2.0 add_multiplied_base
attribute @s minecraft:generic.attack_damage modifier add infectcozy:amenaza_dano 0.8 add_multiplied_base
attribute @s minecraft:generic.armor modifier add infectcozy:amenaza_armadura 8 add_value
