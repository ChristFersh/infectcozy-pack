# el ultimo jugador salio: descargar todo lo que la infeccion tenia forzado
execute in minecraft:overworld run forceload remove all
execute in minecraft:the_nether run forceload remove all
execute in minecraft:the_end run forceload remove all
execute in inqui:dream run forceload remove all
