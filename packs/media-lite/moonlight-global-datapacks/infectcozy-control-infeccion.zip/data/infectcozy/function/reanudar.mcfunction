# /function infectcozy:reanudar  -> los contadores vuelven a correr
scoreboard players set #pausa ic_ctrl 0
tellraw @a [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"La infeccion vuelve a avanzar.","color":"red"}]
