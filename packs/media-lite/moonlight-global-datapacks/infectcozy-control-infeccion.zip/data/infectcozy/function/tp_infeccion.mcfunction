# /function infectcozy:tp_infeccion  -> te lleva al punto donde cae (o cayo) el REDNIGHT
execute unless entity @s[type=minecraft:player] run return 0
function infectcozy:rednight/tp with storage infectcozy:ctrl rn
effect give @s minecraft:slow_falling 10 0 true
tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"REDNIGHT en X ","color":"gray"},{"storage":"infectcozy:ctrl","nbt":"rn.x","color":"white"},{"text":" Z ","color":"gray"},{"storage":"infectcozy:ctrl","nbt":"rn.z","color":"white"}]
execute if score #estado ic_ctrl matches 0 run tellraw @s {"text":"Todavia no ha caido: aqui caera cuando se cumpla la espera.","color":"yellow"}
