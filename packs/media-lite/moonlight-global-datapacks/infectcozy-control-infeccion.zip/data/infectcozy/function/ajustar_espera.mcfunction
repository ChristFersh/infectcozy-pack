# /function infectcozy:ajustar_espera {horas:12}  -> horas de juego (con gente conectada) antes del REDNIGHT
$scoreboard players set #espera ic_ctrl $(horas)
scoreboard players operation #espera ic_ctrl *= #72000 ic_ctrl
function infectcozy:estado
