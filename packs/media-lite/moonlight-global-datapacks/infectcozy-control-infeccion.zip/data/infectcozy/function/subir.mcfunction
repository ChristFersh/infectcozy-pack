scoreboard players set #progreso ic_ctrl 0
scoreboard players add !finale proto 1
