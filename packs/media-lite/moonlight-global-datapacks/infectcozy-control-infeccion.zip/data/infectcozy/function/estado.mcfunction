# /function infectcozy:estado  -> muestra el estado actual
scoreboard players operation #h ic_ctrl = #tiempo ic_ctrl
scoreboard players operation #h ic_ctrl /= #72000 ic_ctrl
scoreboard players operation #hesp ic_ctrl = #espera ic_ctrl
scoreboard players operation #hesp ic_ctrl /= #72000 ic_ctrl
scoreboard players operation #m ic_ctrl = #progreso ic_ctrl
scoreboard players operation #m ic_ctrl /= #1200 ic_ctrl
scoreboard players operation #mpaso ic_ctrl = #paso ic_ctrl
scoreboard players operation #mpaso ic_ctrl /= #1200 ic_ctrl
execute if score #estado ic_ctrl matches 0 run tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Infeccion en espera: ","color":"gray"},{"score":{"name":"#h","objective":"ic_ctrl"},"color":"white"},{"text":" h de ","color":"gray"},{"score":{"name":"#hesp","objective":"ic_ctrl"},"color":"white"},{"text":" h de juego acumulado.","color":"gray"}]
execute if score #estado ic_ctrl matches 1 run tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Infeccion activa. Corrupcion: ","color":"gray"},{"score":{"name":"!finale","objective":"proto"},"color":"red"},{"text":" | proximo punto en ","color":"gray"},{"score":{"name":"#m","objective":"ic_ctrl"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"#mpaso","objective":"ic_ctrl"},"color":"white"},{"text":" min de juego","color":"gray"}]
execute if score #pausa ic_ctrl matches 1 run tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"EN PAUSA","color":"yellow","bold":true},{"text":" (/function infectcozy:reanudar)","color":"gray"}]
execute unless score #rn_dir ic_ctrl matches -1 run tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"REDNIGHT: X ","color":"gray"},{"storage":"infectcozy:ctrl","nbt":"rn.x","color":"white"},{"text":" Z ","color":"gray"},{"storage":"infectcozy:ctrl","nbt":"rn.z","color":"white"},{"text":" (","color":"gray"},{"score":{"name":"#rn_d","objective":"ic_ctrl"},"color":"white"},{"text":" bloques al ","color":"gray"},{"storage":"infectcozy:ctrl","nbt":"rn.dir","color":"white"},{"text":" del spawn)","color":"gray"}]
execute if score #rn_dir ic_ctrl matches -1 run tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"REDNIGHT: X ","color":"gray"},{"storage":"infectcozy:ctrl","nbt":"rn.x","color":"white"},{"text":" Z ","color":"gray"},{"storage":"infectcozy:ctrl","nbt":"rn.z","color":"white"},{"text":" (cayo en el spawn, version anterior)","color":"gray"}]
