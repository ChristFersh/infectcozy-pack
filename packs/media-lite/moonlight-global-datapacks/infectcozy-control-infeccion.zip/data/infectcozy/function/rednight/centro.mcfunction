# (MACRO x z) el mod devuelve el REDNIGHT al "centro" cada hora: el centro ahora es su punto, no el spawn
$execute in minecraft:overworld run tp @e[type=spore:mound,nbt={age:10}] $(x) 2000 $(z)
