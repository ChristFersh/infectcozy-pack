# Lee el spawn del mundo (las funciones del servidor se ejecutan ahi) y fija el punto del REDNIGHT.
scoreboard players set #sx ic_ctrl 0
scoreboard players set #sz ic_ctrl 0
execute in minecraft:overworld summon minecraft:marker run function infectcozy:rednight/leer_spawn
# Si la infeccion ya empezo antes de esta version, el REDNIGHT cayo en el spawn: se respeta
execute if score #estado ic_ctrl matches 1 run function infectcozy:rednight/legado
execute if score #estado ic_ctrl matches 0 run function infectcozy:rednight/sortear
scoreboard players set #rn_ok ic_ctrl 1
