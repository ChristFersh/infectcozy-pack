# Punto al azar a 350-500 bloques del spawn en una de 8 direcciones
execute store result score #rn_d ic_ctrl run random value 350..500
execute store result score #rn_dir ic_ctrl run random value 0..7
scoreboard players operation #rn_g ic_ctrl = #rn_d ic_ctrl
scoreboard players operation #rn_g ic_ctrl *= #707 ic_ctrl
scoreboard players operation #rn_g ic_ctrl /= #1000 ic_ctrl
scoreboard players operation #rx ic_ctrl = #sx ic_ctrl
scoreboard players operation #rz ic_ctrl = #sz ic_ctrl
# 0 norte (-Z), 2 este (+X), 4 sur (+Z), 6 oeste (-X); impares = diagonales
execute if score #rn_dir ic_ctrl matches 0 run scoreboard players operation #rz ic_ctrl -= #rn_d ic_ctrl
execute if score #rn_dir ic_ctrl matches 1 run scoreboard players operation #rx ic_ctrl += #rn_g ic_ctrl
execute if score #rn_dir ic_ctrl matches 1 run scoreboard players operation #rz ic_ctrl -= #rn_g ic_ctrl
execute if score #rn_dir ic_ctrl matches 2 run scoreboard players operation #rx ic_ctrl += #rn_d ic_ctrl
execute if score #rn_dir ic_ctrl matches 3 run scoreboard players operation #rx ic_ctrl += #rn_g ic_ctrl
execute if score #rn_dir ic_ctrl matches 3 run scoreboard players operation #rz ic_ctrl += #rn_g ic_ctrl
execute if score #rn_dir ic_ctrl matches 4 run scoreboard players operation #rz ic_ctrl += #rn_d ic_ctrl
execute if score #rn_dir ic_ctrl matches 5 run scoreboard players operation #rx ic_ctrl -= #rn_g ic_ctrl
execute if score #rn_dir ic_ctrl matches 5 run scoreboard players operation #rz ic_ctrl += #rn_g ic_ctrl
execute if score #rn_dir ic_ctrl matches 6 run scoreboard players operation #rx ic_ctrl -= #rn_d ic_ctrl
execute if score #rn_dir ic_ctrl matches 7 run scoreboard players operation #rx ic_ctrl -= #rn_g ic_ctrl
execute if score #rn_dir ic_ctrl matches 7 run scoreboard players operation #rz ic_ctrl -= #rn_g ic_ctrl
function infectcozy:rednight/guardar
