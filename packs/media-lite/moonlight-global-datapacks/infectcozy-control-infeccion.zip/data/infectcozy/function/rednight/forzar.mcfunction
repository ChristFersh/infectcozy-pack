# (MACRO x z) mantiene cargada la zona del REDNIGHT (antes era el spawn)
$execute in minecraft:overworld positioned $(x) 0 $(z) run forceload add ~-100 ~-100 ~100 ~100
