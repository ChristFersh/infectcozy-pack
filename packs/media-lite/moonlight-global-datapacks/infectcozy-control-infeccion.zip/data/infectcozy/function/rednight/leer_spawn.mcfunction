execute store result score #sx ic_ctrl run data get entity @s Pos[0]
execute store result score #sz ic_ctrl run data get entity @s Pos[2]
kill @s
