# (MACRO x z) sube al jugador sobre el punto; al cargar el chunk, aterrizar lo baja al suelo
$execute in minecraft:overworld run tp @s $(x) 250 $(z)
tag @s add ic_tp_rn
scoreboard players set #tp_try ic_ctrl 0
schedule function infectcozy:rednight/aterrizar 1s
