execute store result storage infectcozy:ctrl rn.x int 1 run scoreboard players get #rx ic_ctrl
execute store result storage infectcozy:ctrl rn.z int 1 run scoreboard players get #rz ic_ctrl
execute if score #rn_dir ic_ctrl matches -1 run data modify storage infectcozy:ctrl rn.dir set value "centro"
execute if score #rn_dir ic_ctrl matches 0 run data modify storage infectcozy:ctrl rn.dir set value "norte"
execute if score #rn_dir ic_ctrl matches 1 run data modify storage infectcozy:ctrl rn.dir set value "noreste"
execute if score #rn_dir ic_ctrl matches 2 run data modify storage infectcozy:ctrl rn.dir set value "este"
execute if score #rn_dir ic_ctrl matches 3 run data modify storage infectcozy:ctrl rn.dir set value "sureste"
execute if score #rn_dir ic_ctrl matches 4 run data modify storage infectcozy:ctrl rn.dir set value "sur"
execute if score #rn_dir ic_ctrl matches 5 run data modify storage infectcozy:ctrl rn.dir set value "suroeste"
execute if score #rn_dir ic_ctrl matches 6 run data modify storage infectcozy:ctrl rn.dir set value "oeste"
execute if score #rn_dir ic_ctrl matches 7 run data modify storage infectcozy:ctrl rn.dir set value "noroeste"
