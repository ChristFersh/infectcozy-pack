scoreboard players add #tp_try ic_ctrl 1
execute as @a[tag=ic_tp_rn] at @s if loaded ~ ~ ~ positioned over motion_blocking_no_leaves run tp @s ~ ~ ~
execute as @a[tag=ic_tp_rn] at @s if loaded ~ ~ ~ run tag @s remove ic_tp_rn
execute if score #tp_try ic_ctrl matches 10.. run tag @a remove ic_tp_rn
execute if entity @a[tag=ic_tp_rn] run schedule function infectcozy:rednight/aterrizar 1s
