# (MACRO x z) se llama cada tick mientras #rn_pend = 1; espera a que la zona este cargada
$execute in minecraft:overworld unless loaded $(x) 64 $(z) run return 0
# en oceano, rio o agua: otro punto (hasta 12 intentos)
scoreboard players set #rn_agua ic_ctrl 0
$execute in minecraft:overworld positioned $(x) 64 $(z) if biome ~ ~ ~ #minecraft:is_ocean run scoreboard players set #rn_agua ic_ctrl 1
$execute in minecraft:overworld positioned $(x) 64 $(z) if biome ~ ~ ~ #minecraft:is_river run scoreboard players set #rn_agua ic_ctrl 1
$execute in minecraft:overworld positioned $(x) 64 $(z) positioned over motion_blocking if block ~ ~-1 ~ minecraft:water run scoreboard players set #rn_agua ic_ctrl 1
execute if score #rn_agua ic_ctrl matches 1 if score #rn_try ic_ctrl matches ..11 run return run function infectcozy:rednight/otro
$execute in minecraft:overworld positioned $(x) ~ $(z) unless entity @e[type=spore:mound,nbt={age:10}] run function inqui:summon_primordial_mound
scoreboard players set #rn_pend ic_ctrl 0
tellraw @a [{"text":"Algo cae del cielo a unos ","color":"dark_red","bold":true},{"score":{"name":"#rn_d","objective":"ic_ctrl"},"color":"red","bold":true},{"text":" bloques al ","color":"dark_red","bold":true},{"storage":"infectcozy:ctrl","nbt":"rn.dir","color":"red","bold":true},{"text":" del spawn... ","color":"dark_red","bold":true},{"text":"la infeccion ha comenzado.","color":"red"}]
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 1 0.5
