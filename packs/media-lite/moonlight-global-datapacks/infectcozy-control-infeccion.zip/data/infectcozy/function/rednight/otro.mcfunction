# el punto cayo en agua: se sortea otro y se carga su zona
scoreboard players add #rn_try ic_ctrl 1
function infectcozy:rednight/punto
function inqui:chunkloader
