scoreboard players set #rn_try ic_ctrl 0
function infectcozy:rednight/punto
