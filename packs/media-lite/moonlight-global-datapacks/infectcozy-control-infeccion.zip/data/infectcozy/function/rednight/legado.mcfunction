scoreboard players operation #rx ic_ctrl = #sx ic_ctrl
scoreboard players operation #rz ic_ctrl = #sz ic_ctrl
scoreboard players set #rn_d ic_ctrl 0
scoreboard players set #rn_dir ic_ctrl -1
function infectcozy:rednight/guardar
