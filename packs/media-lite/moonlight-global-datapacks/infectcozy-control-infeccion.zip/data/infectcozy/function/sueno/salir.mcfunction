# /function infectcozy:sueno/salir  -> saca al jugador (@s) del Sueno y lo devuelve al mundo normal
effect clear @s
scoreboard players set @s ic_sueno_t 0
tag @s add ic_salir
execute store success score @s ic_tmp run data get entity @s SpawnX
execute if data entity @s {SpawnDimension:"inqui:dream"} run scoreboard players set @s ic_tmp 0
# con cama/punto de reaparicion propio: volver ahi
execute if score @s ic_tmp matches 1 run function infectcozy:sueno/tp_cama with entity @s
# sin cama: volver al spawn del mundo (el schedule corre en el spawn del Overworld)
execute unless score @s ic_tmp matches 1 run schedule function infectcozy:sueno/tp_spawn 1t append
