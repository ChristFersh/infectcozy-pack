# el jugador (@s) entra al Sueno de la colmena
scoreboard players set @s webon 1
tag @s add sleep_executor
tag @s add ic_sonando
# respawn inmediato solo un momento, lo necesita el mod para llevarte al sueno
gamerule doImmediateRespawn true
schedule function inqui:sleep/2 4t
schedule function infectcozy:sueno/restaurar 60t
