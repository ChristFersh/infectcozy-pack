$bossbar remove infectcozy:sueno_$(id)
