# calcula el tiempo restante del jugador (@s) y actualiza su barra
execute unless score @s ic_id matches 1.. run scoreboard players add #siguiente ic_id 1
execute unless score @s ic_id matches 1.. run scoreboard players operation @s ic_id = #siguiente ic_id
scoreboard players operation #rest ic_tmp = #dur_sueno ic_ctrl
scoreboard players operation #rest ic_tmp -= @s ic_sueno_t
execute if score #rest ic_tmp matches ..-1 run scoreboard players set #rest ic_tmp 0
scoreboard players operation #seg ic_tmp = #rest ic_tmp
scoreboard players operation #seg ic_tmp /= #20 ic_ctrl
scoreboard players operation #min ic_tmp = #seg ic_tmp
scoreboard players operation #min ic_tmp /= #60 ic_ctrl
scoreboard players operation #seg ic_tmp %= #60 ic_ctrl
scoreboard players operation #d1 ic_tmp = #seg ic_tmp
scoreboard players operation #d1 ic_tmp /= #10 ic_ctrl
scoreboard players operation #d2 ic_tmp = #seg ic_tmp
scoreboard players operation #d2 ic_tmp %= #10 ic_ctrl
execute store result storage infectcozy:barra id int 1 run scoreboard players get @s ic_id
execute store result storage infectcozy:barra max int 1 run scoreboard players get #dur_sueno ic_ctrl
execute store result storage infectcozy:barra rest int 1 run scoreboard players get #rest ic_tmp
execute store result storage infectcozy:barra min int 1 run scoreboard players get #min ic_tmp
execute store result storage infectcozy:barra d1 int 1 run scoreboard players get #d1 ic_tmp
execute store result storage infectcozy:barra d2 int 1 run scoreboard players get #d2 ic_tmp
function infectcozy:sueno/barra with storage infectcozy:barra
