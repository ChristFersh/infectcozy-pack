# /function infectcozy:sueno/despertar  -> despertar del Sueno
# si todavia estas dentro del sueno, primero te saca; la animacion se reproduce al llegar al mundo normal
execute if dimension inqui:dream run return run function infectcozy:sueno/salir
tag @s remove ic_sonando
tag @s remove ic_en_sueno
scoreboard players set @s ic_sueno_t 0
# quitar la barra del sueno
execute if score @s ic_id matches 1.. store result storage infectcozy:barra id int 1 run scoreboard players get @s ic_id
execute if score @s ic_id matches 1.. run function infectcozy:sueno/barra_quitar with storage infectcozy:barra
# si ya no queda nadie en el sueno, liberar sus chunks
execute unless entity @a[tag=ic_en_sueno] in inqui:dream run forceload remove all
effect give @s minecraft:darkness 4 0 true
effect give @s minecraft:blindness 2 0 true
effect give @s minecraft:slowness 3 4 true
effect give @s minecraft:resistance 5 4 true
title @s times 10 60 30
title @s title {"text":"Despiertas...","color":"dark_red","bold":true}
title @s subtitle {"text":"la colmena te dejo ir... por ahora","color":"gray","italic":true}
playsound revivebydeath:cutscene_heartbeat master @s ~ ~ ~ 1 1
playsound minecraft:block.respawn_anchor.deplete master @s ~ ~ ~ 0.8 0.6
playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.5
particle minecraft:reverse_portal ~ ~1 ~ 0.4 0.8 0.4 0.05 120 force @s
particle minecraft:sculk_soul ~ ~1 ~ 0.5 0.8 0.5 0.02 25 force @s
