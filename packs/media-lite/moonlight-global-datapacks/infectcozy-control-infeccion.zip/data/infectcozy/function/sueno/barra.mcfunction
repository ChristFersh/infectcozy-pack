$bossbar add infectcozy:sueno_$(id) ""
$bossbar set infectcozy:sueno_$(id) color purple
$bossbar set infectcozy:sueno_$(id) style notched_10
$bossbar set infectcozy:sueno_$(id) max $(max)
$bossbar set infectcozy:sueno_$(id) value $(rest)
$bossbar set infectcozy:sueno_$(id) name [{"text":"Sueño de la Colmena","color":"dark_purple","bold":true},{"text":"  —  despiertas en ","color":"gray"},{"text":"$(min):$(d1)$(d2)","color":"light_purple","bold":true}]
$bossbar set infectcozy:sueno_$(id) players @s
$bossbar set infectcozy:sueno_$(id) visible true
