execute as @a[tag=ic_salir] in minecraft:overworld run tp @s ~ ~ ~
tag @a remove ic_salir
