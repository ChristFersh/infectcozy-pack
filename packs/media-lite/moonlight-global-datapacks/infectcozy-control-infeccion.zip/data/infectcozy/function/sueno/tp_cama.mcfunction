$execute in $(SpawnDimension) run tp @s $(SpawnX) $(SpawnY) $(SpawnZ)
tag @s remove ic_salir
