# ===== Infect Cozy: control de la infeccion =====
scoreboard objectives add ic_ctrl dummy "Infect Cozy"
# --- AJUSTES (ticks: 72000 = 1 hora de juego con alguien conectado) ---
# Tiempo de juego acumulado antes de que caiga el REDNIGHT (por defecto 12 horas)
#   cambiarlo:  /function infectcozy:ajustar_espera {horas:12}
execute unless score #espera ic_ctrl matches 0.. run scoreboard players set #espera ic_ctrl 864000
# Cada cuanto tiempo de juego sube 1 punto la corrupcion (por defecto 1 hora)
execute unless score #paso ic_ctrl matches 1.. run scoreboard players set #paso ic_ctrl 72000
# --- estado interno ---
execute unless score #estado ic_ctrl matches 0.. run scoreboard players set #estado ic_ctrl 0
execute unless score #tiempo ic_ctrl matches 0.. run scoreboard players set #tiempo ic_ctrl 0
execute unless score #progreso ic_ctrl matches 0.. run scoreboard players set #progreso ic_ctrl 0
scoreboard players set #antes ic_ctrl 0
scoreboard players set #72000 ic_ctrl 72000
scoreboard players set #1200 ic_ctrl 1200
scoreboard players set #60 ic_ctrl 60
# sin jugadores no quedan chunks del spawn cargados (la infeccion no avanza sola)
gamerule spawnChunkRadius 0
# la corrupcion de Spore Inquisition la maneja este datapack, no el mod
scoreboard players set !finale corruption_rate 0
# mostrar la pantalla de muerte normal
gamerule doImmediateRespawn false
scoreboard objectives add ic_dado dummy
# probabilidad (en %) de caer en el Sueno al morir por un infectado
execute unless score #prob_sueno ic_ctrl matches 0.. run scoreboard players set #prob_sueno ic_ctrl 10
scoreboard objectives add ic_sueno_t dummy
scoreboard objectives add ic_tmp dummy
# duracion del sueno antes de despertar solo (ticks; 3600 = 3 minutos)
execute unless score #dur_sueno ic_ctrl matches 1.. run scoreboard players set #dur_sueno ic_ctrl 3600
scoreboard players operation #aviso_sueno ic_ctrl = #dur_sueno ic_ctrl
scoreboard players remove #aviso_sueno ic_ctrl 600
scoreboard objectives add ic_id dummy
scoreboard players set #20 ic_ctrl 20
scoreboard players set #10 ic_ctrl 10
# pausa de los contadores (0 = corre, 1 = en pausa): /function infectcozy:pausar  y  /function infectcozy:reanudar
execute unless score #pausa ic_ctrl matches 0..1 run scoreboard players set #pausa ic_ctrl 0
scoreboard players set #707 ic_ctrl 707
scoreboard players set #1000 ic_ctrl 1000
# --- actualizacion v2 (una sola vez): espera de 6 h -> 12 h y reaparicion cerca del spawn ---
execute unless score #ver ic_ctrl matches 2.. if score #espera ic_ctrl matches 432000 run scoreboard players set #espera ic_ctrl 864000
execute unless score #ver ic_ctrl matches 2.. run gamerule spawnRadius 48
scoreboard players set #ver ic_ctrl 2
