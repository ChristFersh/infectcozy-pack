# ===== Infect Cozy: control de la infeccion =====
scoreboard objectives add ic_ctrl dummy "Infect Cozy"
# --- AJUSTES (ticks: 72000 = 1 hora de juego con alguien conectado) ---
# Tiempo de juego acumulado antes de que caiga el REDNIGHT (por defecto 12 horas)
#   cambiarlo:  /function infectcozy:ajustar_espera {horas:12}
execute unless score #espera ic_ctrl matches 0.. run scoreboard players set #espera ic_ctrl 864000
# Cada cuanto tiempo de juego sube 1 punto la corrupcion (por defecto 1 hora)
execute unless score #paso ic_ctrl matches 1.. run scoreboard players set #paso ic_ctrl 72000
# --- estado interno ---
execute unless score #estado ic_ctrl matches 0.. run scoreboard players set #estado ic_ctrl 0
execute unless score #tiempo ic_ctrl matches 0.. run scoreboard players set #tiempo ic_ctrl 0
execute unless score #progreso ic_ctrl matches 0.. run scoreboard players set #progreso ic_ctrl 0
scoreboard players set #antes ic_ctrl 0
scoreboard players set #72000 ic_ctrl 72000
scoreboard players set #1200 ic_ctrl 1200
scoreboard players set #60 ic_ctrl 60
# sin jugadores no quedan chunks del spawn cargados (la infeccion no avanza sola)
gamerule spawnChunkRadius 0
# corrupcion (la usan los campeones y los hitos de los otros datapacks)
scoreboard objectives add proto dummy
# la corrupcion de Spore Inquisition la maneja este datapack, no el mod
scoreboard players set !finale corruption_rate 0
# probabilidad (en %) de caer en el Sueno al morir por un infectado
execute unless score #prob_sueno ic_ctrl matches 0.. run scoreboard players set #prob_sueno ic_ctrl 10
scoreboard objectives add ic_sueno_t dummy
# duracion del sueno antes de despertar solo (ticks; 3600 = 3 minutos)
execute unless score #dur_sueno ic_ctrl matches 1.. run scoreboard players set #dur_sueno ic_ctrl 3600
scoreboard players operation #aviso_sueno ic_ctrl = #dur_sueno ic_ctrl
scoreboard players remove #aviso_sueno ic_ctrl 600
# mostrar la pantalla de muerte normal
gamerule doImmediateRespawn false
scoreboard objectives add ic_dado dummy
scoreboard objectives add ic_tmp dummy
scoreboard objectives add ic_id dummy
scoreboard players set #2 ic_ctrl 2
scoreboard players set #20 ic_ctrl 20
scoreboard players set #10 ic_ctrl 10
# pausa de los contadores (0 = corre, 1 = en pausa): /function infectcozy:pausar  y  /function infectcozy:reanudar
execute unless score #pausa ic_ctrl matches 0..1 run scoreboard players set #pausa ic_ctrl 0
scoreboard players set #707 ic_ctrl 707
scoreboard players set #1000 ic_ctrl 1000
# --- actualizacion v2 (una sola vez): espera de 6 h -> 12 h y reaparicion cerca del spawn ---
execute unless score #ver ic_ctrl matches 2.. if score #espera ic_ctrl matches 432000 run scoreboard players set #espera ic_ctrl 864000
execute unless score #ver ic_ctrl matches 2.. run gamerule spawnRadius 48
# --- rebalanceo 1.6 ---
# Proteccion de novato: las primeras horas de juego de cada jugador (ticks; 360000 = 5 horas)
#   cambiarlo:  /scoreboard players set #novato_t ic_ctrl 360000
execute unless score #novato_t ic_ctrl matches 0.. run scoreboard players set #novato_t ic_ctrl 360000
scoreboard objectives add ic_jugado minecraft.custom:minecraft.play_time
scoreboard objectives add novato trigger
# Zonas de infeccion: el radio (#zona_r) ahora crece despacio (ver "zona infectada" abajo).
#   marcar / quitar / ver focos extra:  /function infectcozy:zonas/marcar  |  zonas/quitar  |  zonas/lista
execute unless score #zona_r ic_ctrl matches 1.. run scoreboard players set #zona_r ic_ctrl 250
execute unless data storage infectcozy:zonas lista run data modify storage infectcozy:zonas lista set value []
scoreboard players set #-1 ic_ctrl -1
scoreboard players set #c5s ic_ctrl 0

# --- v3/v4: zona infectada que crece despacio ---
# Los infectados ya no salen del suelo en cualquier parte: solo dentro de la zona (y en lo oscuro, como siempre).
# La zona tiene centro en la colmena (punto del REDNIGHT) y su radio crece solo con jugadores conectados.
#   ver todo:              /function infectcozy:estado
#   radio ahora mismo:     /function infectcozy:infeccion/radio {r:250}
#   velocidad:             /function infectcozy:infeccion/velocidad {bloques:10}   (bloques por hora con jugadores; 0 = no crece)
#   retroceso al matar:    /function infectcozy:infeccion/retroceso_ajustar {proto:25,tumor:10}
#   radio de las bases:    /function infectcozy:infeccion/bases_radio {r:48}
# ticks de juego por cada bloque que crece el radio (7200 = 10 bloques por hora)
execute unless score #zona_paso ic_ctrl matches 1.. run scoreboard players set #zona_paso ic_ctrl 7200
execute unless score #zona_t ic_ctrl matches 0.. run scoreboard players set #zona_t ic_ctrl 0
# radio minimo / maximo de la zona
execute unless score #zona_min ic_ctrl matches 1.. run scoreboard players set #zona_min ic_ctrl 16
execute unless score #zona_max ic_ctrl matches 1.. run scoreboard players set #zona_max ic_ctrl 3000
# los infectados que se alejan mas de este margen de la frontera desaparecen
execute unless score #zona_margen ic_ctrl matches 0.. run scoreboard players set #zona_margen ic_ctrl 32
# bloques que retrocede la zona por cada Proto Hivemind / Hivetumor que mata un jugador
execute unless score #ret_proto ic_ctrl matches 0.. run scoreboard players set #ret_proto ic_ctrl 25
execute unless score #ret_tumor ic_ctrl matches 0.. run scoreboard players set #ret_tumor ic_ctrl 10
# radio de proteccion de las bases (/trigger base)
execute unless score #base_r ic_ctrl matches 1.. run scoreboard players set #base_r ic_ctrl 48
scoreboard objectives add ic_kproto minecraft.killed:spore.proto
scoreboard objectives add ic_ktumor minecraft.killed:spore.hivetumor
scoreboard objectives add base trigger
scoreboard objectives add ic_bid dummy
execute unless data storage infectcozy:bases lista run data modify storage infectcozy:bases lista set value []
scoreboard players set #c1s ic_ctrl 0
scoreboard players set #c10 ic_ctrl 0
# v4: Spore Inquisition vuelve (con el Sueno) pero sin ordalias; lo que estaba programado de ellas se cancela
schedule clear inqui:calls/ordeal1_2
schedule clear inqui:calls/ordeal2_2
schedule clear inqui:calls/ordeal3_2
schedule clear inqui:calls/ordeal4_2
tag @e[tag=ordeal_runner] remove ordeal_runner
# una sola vez: soltar las zonas que la colmena dejo cargadas a la fuerza
execute unless score #ver ic_ctrl matches 3.. in minecraft:overworld run forceload remove all
execute unless score #ver ic_ctrl matches 3.. in minecraft:the_nether run forceload remove all
execute unless score #ver ic_ctrl matches 3.. in minecraft:the_end run forceload remove all
scoreboard players set #ver ic_ctrl 3
