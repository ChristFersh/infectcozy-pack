# /function infectcozy:iniciar_ya  -> lanza la infeccion ahora mismo
execute if score #estado ic_ctrl matches 1 run return run tellraw @s {"text":"La infección ya empezó. Para cambiar su tamaño usa /function infectcozy:infeccion/radio {r:N}","color":"yellow"}
function infectcozy:iniciar
