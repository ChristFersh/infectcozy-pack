# /function infectcozy:iniciar_ya  -> lanza la infeccion ahora mismo
function infectcozy:iniciar
