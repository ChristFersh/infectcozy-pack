# /function infectcozy:zonas/lista
tellraw @s ["",{"text":"☣ Zonas de infección (radio ","color":"dark_green"},{"score":{"name":"#zona_r","objective":"ic_ctrl"},"color":"white"},{"text":" bloques)","color":"dark_green"}]
execute if score #rn_ok ic_ctrl matches 1 run tellraw @s ["",{"text":" · Colmena: ","color":"gray"},{"nbt":"rn.x","storage":"infectcozy:ctrl","color":"white"},{"text":", ","color":"gray"},{"nbt":"rn.z","storage":"infectcozy:ctrl","color":"white"}]
tellraw @s ["",{"text":" · Marcadas: ","color":"gray"},{"nbt":"lista","storage":"infectcozy:zonas","color":"white"}]
