# /function infectcozy:zonas/marcar  (un admin, parado en el centro de la nueva zona de infeccion)
# solo como jugador (necesita una posicion)
execute unless entity @s[type=minecraft:player] run return fail
execute unless dimension minecraft:overworld run return run tellraw @s {"text":"Las zonas de infección solo existen en el Overworld.","color":"red"}
execute store result storage infectcozy:zonas nueva.x int 1 run data get entity @s Pos[0]
execute store result storage infectcozy:zonas nueva.z int 1 run data get entity @s Pos[2]
data modify storage infectcozy:zonas lista append from storage infectcozy:zonas nueva
tellraw @s ["",{"text":"☣ Zona de infección marcada en ","color":"dark_green"},{"nbt":"nueva.x","storage":"infectcozy:zonas","color":"white"},{"text":", ","color":"gray"},{"nbt":"nueva.z","storage":"infectcozy:zonas","color":"white"},{"text":" (radio ","color":"gray"},{"score":{"name":"#zona_r","objective":"ic_ctrl"},"color":"white"},{"text":" bloques).","color":"gray"}]
