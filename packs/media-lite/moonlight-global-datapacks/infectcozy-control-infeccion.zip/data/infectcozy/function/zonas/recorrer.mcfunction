# Recorre storage infectcozy:zonas tmp (copia de la lista) hasta encontrar una zona que contenga (#ex, #ez)
execute unless data storage infectcozy:zonas tmp[0] run return 0
execute store result score #zx ic_ctrl run data get storage infectcozy:zonas tmp[0].x
execute store result score #zz ic_ctrl run data get storage infectcozy:zonas tmp[0].z
function infectcozy:zonas/medir
execute if score #dentro ic_ctrl matches 1 run return 1
data remove storage infectcozy:zonas tmp[0]
function infectcozy:zonas/recorrer
