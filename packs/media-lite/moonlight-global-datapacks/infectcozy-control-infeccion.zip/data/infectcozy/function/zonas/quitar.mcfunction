# /function infectcozy:zonas/quitar  (un admin, dentro de la zona marcada que quiere borrar)
# El spawn y la colmena no se pueden quitar: son zonas fijas.
# solo como jugador (necesita una posicion)
execute unless entity @s[type=minecraft:player] run return fail
execute store result score #ex ic_ctrl run data get entity @s Pos[0]
execute store result score #ez ic_ctrl run data get entity @s Pos[2]
scoreboard players set #quitadas ic_ctrl 0
data modify storage infectcozy:zonas tmp set from storage infectcozy:zonas lista
data modify storage infectcozy:zonas queda set value []
function infectcozy:zonas/quitar_recorrer
data modify storage infectcozy:zonas lista set from storage infectcozy:zonas queda
tellraw @s ["",{"text":"☣ Zonas marcadas quitadas: ","color":"dark_green"},{"score":{"name":"#quitadas","objective":"ic_ctrl"},"color":"white"}]
