# /function infectcozy:zonas/marcar_en {x:1200,z:-340}  (desde la consola o el chat, sin ir al lugar)
$data modify storage infectcozy:zonas lista append value {x:$(x),z:$(z)}
