# (como y en el foco fuera de zona) La infeccion no arraiga aqui: se hunde en el vacio, sin soltar nada en la superficie.
particle minecraft:sculk_soul ~ ~1 ~ 0.6 0.8 0.6 0.02 30 force
particle minecraft:large_smoke ~ ~1 ~ 0.6 0.8 0.6 0.02 20 force
playsound minecraft:entity.warden.dig hostile @a[distance=..32] ~ ~ ~ 0.8 1.4
tellraw @a[distance=..48] ["",{"text":"☣ ","color":"dark_green"},{"text":"La infección no puede arraigar aquí: está fuera de sus zonas.","color":"gray","italic":true}]
tp @s ~ -400 ~
