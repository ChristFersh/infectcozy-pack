# #dentro = 1 si (#ex, #ez) esta a #zona_r bloques o menos de (#zx, #zz)
scoreboard players operation #dx ic_ctrl = #ex ic_ctrl
scoreboard players operation #dx ic_ctrl -= #zx ic_ctrl
scoreboard players operation #dz ic_ctrl = #ez ic_ctrl
scoreboard players operation #dz ic_ctrl -= #zz ic_ctrl
# descarte rapido por el cuadrado (y evita desbordes al elevar al cuadrado)
scoreboard players operation #nr ic_ctrl = #zona_r ic_ctrl
scoreboard players operation #nr ic_ctrl *= #-1 ic_ctrl
execute if score #dx ic_ctrl > #zona_r ic_ctrl run return 0
execute if score #dx ic_ctrl < #nr ic_ctrl run return 0
execute if score #dz ic_ctrl > #zona_r ic_ctrl run return 0
execute if score #dz ic_ctrl < #nr ic_ctrl run return 0
scoreboard players operation #dx ic_ctrl *= #dx ic_ctrl
scoreboard players operation #dz ic_ctrl *= #dz ic_ctrl
scoreboard players operation #dx ic_ctrl += #dz ic_ctrl
scoreboard players operation #r2 ic_ctrl = #zona_r ic_ctrl
scoreboard players operation #r2 ic_ctrl *= #zona_r ic_ctrl
execute if score #dx ic_ctrl <= #r2 ic_ctrl run scoreboard players set #dentro ic_ctrl 1
