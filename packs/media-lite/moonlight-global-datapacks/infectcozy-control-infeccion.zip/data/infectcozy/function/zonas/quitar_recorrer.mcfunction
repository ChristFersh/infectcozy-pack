# Copia a "queda" las zonas de "tmp" que NO contienen la posicion (#ex, #ez)
execute unless data storage infectcozy:zonas tmp[0] run return 0
execute store result score #zx ic_ctrl run data get storage infectcozy:zonas tmp[0].x
execute store result score #zz ic_ctrl run data get storage infectcozy:zonas tmp[0].z
scoreboard players set #dentro ic_ctrl 0
function infectcozy:zonas/medir
execute if score #dentro ic_ctrl matches 1 run scoreboard players add #quitadas ic_ctrl 1
execute if score #dentro ic_ctrl matches 0 run data modify storage infectcozy:zonas queda append from storage infectcozy:zonas tmp[0]
data remove storage infectcozy:zonas tmp[0]
function infectcozy:zonas/quitar_recorrer
