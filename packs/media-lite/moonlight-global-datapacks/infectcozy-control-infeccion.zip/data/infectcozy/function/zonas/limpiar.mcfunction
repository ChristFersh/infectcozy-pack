# Zonas de infeccion (Overworld): la de la colmena (punto del REDNIGHT, radio #zona_r que crece) y las marcadas por un admin.
# Fuera de ellas no pueden existir monticulos, tumores ni colmenas: asi la infeccion no se esparce hasta las bases.
# distance=0.. limita la busqueda al Overworld. El monticulo del REDNIGHT (age 10) y su colmena no se tocan.
execute in minecraft:overworld as @e[type=spore:mound,distance=0..,nbt=!{age:10}] at @s run function infectcozy:zonas/revisar
execute in minecraft:overworld as @e[type=spore:hivetumor,distance=0..] at @s run function infectcozy:zonas/revisar
execute in minecraft:overworld as @e[type=spore:proto,distance=0..,tag=!nunny] at @s run function infectcozy:zonas/revisar
