# (como y en el monticulo / tumor / colmena) #dentro = 1 si esta en alguna zona de infeccion
execute store result score #ex ic_ctrl run data get entity @s Pos[0]
execute store result score #ez ic_ctrl run data get entity @s Pos[2]
scoreboard players set #dentro ic_ctrl 0
# zona de la colmena (solo cuando la infeccion ya empezo)
execute if score #estado ic_ctrl matches 1 if score #rn_ok ic_ctrl matches 1 store result score #zx ic_ctrl run data get storage infectcozy:ctrl rn.x
execute if score #estado ic_ctrl matches 1 if score #rn_ok ic_ctrl matches 1 store result score #zz ic_ctrl run data get storage infectcozy:ctrl rn.z
execute if score #estado ic_ctrl matches 1 if score #rn_ok ic_ctrl matches 1 run function infectcozy:zonas/medir
# zonas marcadas por un admin
execute if score #dentro ic_ctrl matches 0 run data modify storage infectcozy:zonas tmp set from storage infectcozy:zonas lista
execute if score #dentro ic_ctrl matches 0 run function infectcozy:zonas/recorrer
execute if score #dentro ic_ctrl matches 0 run function infectcozy:zonas/fuera
