# alguien acaba de entrar a un servidor vacio: volver a cargar las zonas de la infeccion
execute if score #antes ic_ctrl matches 0 if score #estado ic_ctrl matches 1 run function inqui:chunkloader
# la corrupcion del mod siempre en 0 (el mod la vuelve a escribir desde su config)
scoreboard players set !finale corruption_rate 0
# punto donde cae (o cayo) el REDNIGHT: se calcula una sola vez
execute unless score #rn_ok ic_ctrl matches 1 run function infectcozy:rednight/calcular
# REDNIGHT pendiente de caer (espera a que su zona este cargada)
execute if score #rn_pend ic_ctrl matches 1 run function infectcozy:rednight/caer with storage infectcozy:ctrl rn
# en pausa no avanza ningun contador
execute if score #pausa ic_ctrl matches 1 run return 0
# fase 0: contar tiempo de juego hasta que caiga el REDNIGHT
execute if score #estado ic_ctrl matches 0 run scoreboard players add #tiempo ic_ctrl 1
execute if score #estado ic_ctrl matches 0 if score #tiempo ic_ctrl >= #espera ic_ctrl run function infectcozy:iniciar
# fase 1: la corrupcion sube muy lento, solo con jugadores conectados
execute if score #estado ic_ctrl matches 1 run scoreboard players add #progreso ic_ctrl 1
execute if score #estado ic_ctrl matches 1 if score #progreso ic_ctrl >= #paso ic_ctrl run function infectcozy:subir
