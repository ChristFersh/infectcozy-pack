# /function infectcozy:tp_colmena  -> te lleva al Proto Hivemind cargado mas cercano (la mente de la colmena)
execute unless entity @s[type=minecraft:player] run return 0
execute unless entity @e[type=spore:proto] run tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"No hay ningun Proto Hivemind cargado. Prueba ","color":"gray"},{"text":"/function infectcozy:tp_infeccion","color":"yellow"}]
execute unless entity @e[type=spore:proto] run return 0
execute at @e[type=spore:proto,sort=nearest,limit=1] positioned over motion_blocking_no_leaves run tp @s ~ ~1 ~
effect give @s minecraft:slow_falling 10 0 true
