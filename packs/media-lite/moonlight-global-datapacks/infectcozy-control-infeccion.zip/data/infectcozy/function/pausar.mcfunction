# /function infectcozy:pausar  -> congela la espera del REDNIGHT y la subida de corrupcion
scoreboard players set #pausa ic_ctrl 1
tellraw @a [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"El avance de la infeccion esta en pausa.","color":"yellow"}]
