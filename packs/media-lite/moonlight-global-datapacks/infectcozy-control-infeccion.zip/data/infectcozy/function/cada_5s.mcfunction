scoreboard players set #c5s ic_ctrl 0
execute unless entity @a run return 0
function infectcozy:novato/revisar
function infectcozy:zonas/limpiar
scoreboard players enable @a base
