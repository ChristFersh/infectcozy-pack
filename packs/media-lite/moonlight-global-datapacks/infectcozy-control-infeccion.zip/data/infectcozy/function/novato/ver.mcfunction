scoreboard players set @s novato 0
scoreboard players enable @s novato
execute unless entity @s[tag=ic_novato] run tellraw @s {"text":"No tienes protección de novato.","color":"gray"}
execute unless entity @s[tag=ic_novato] run return 0
scoreboard players operation #nv ic_ctrl = #novato_t ic_ctrl
scoreboard players operation #nv ic_ctrl -= @s ic_jugado
scoreboard players operation #nv ic_ctrl /= #1200 ic_ctrl
tellraw @s ["",{"text":"🛡 Protección de novato: ","color":"green"},{"score":{"name":"#nv","objective":"ic_ctrl"},"color":"white","bold":true},{"text":" minutos de juego restantes.","color":"green"}]
