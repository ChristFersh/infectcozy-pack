# (como el jugador) Decide una sola vez si arranca con proteccion de novato.
tag @s add ic_nov_ok
scoreboard players add @s ic_jugado 0
# Quien ya jugaba antes de esta version y tiene equipo, jefes o muchas bajas no es novato
execute if entity @s[advancements={infectcozy:mec/bienvenida=true}] if score @s ic_amz_n matches 2.. run return 0
execute if entity @s[advancements={infectcozy:mec/bienvenida=true}] if score @s ic_jefes matches 1.. run return 0
execute if entity @s[advancements={infectcozy:mec/bienvenida=true}] if score @s ic_infectados matches 30.. run return 0
tag @s add ic_novato
tellraw @s ["",{"text":"🛡 ","color":"green"},{"text":"Tienes protección de novato durante tus primeras horas de juego.","color":"green","bold":true}]
tellraw @s {"text":"La colmena todavía no te ve: sin efectos de la infección, sin campeones de la colmena y sin el Sueño. Los infectados comunes sí atacan. Escribe /trigger novato para ver cuánto te queda.","color":"gray"}
