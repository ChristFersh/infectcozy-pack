# Proteccion de novato (tag ic_novato): sin efectos de la infeccion, sin campeones de la colmena y sin el Sueno.
# Jugadores vistos por primera vez desde el rebalanceo
execute as @a[tag=!ic_nov_ok] run function infectcozy:novato/primera_vez
# Se acabo su tiempo de juego protegido
execute as @a[tag=ic_novato] if score @s ic_jugado >= #novato_t ic_ctrl run function infectcozy:novato/fin
scoreboard players enable @a novato
