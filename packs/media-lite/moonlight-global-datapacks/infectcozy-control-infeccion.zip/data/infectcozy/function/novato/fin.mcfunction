tag @s remove ic_novato
title @s times 10 70 20
title @s title {"text":"☣","color":"dark_red"}
title @s subtitle {"text":"la colmena ya sabe de ti","color":"red","italic":true}
tellraw @s ["",{"text":"☣ ","color":"dark_red"},{"text":"Tu protección de novato terminó.","color":"red","bold":true},{"text":" Desde ahora los efectos de la infección, los campeones de la colmena y el Sueño también vienen por ti.","color":"gray"}]
playsound minecraft:entity.elder_guardian.curse player @s ~ ~ ~ 0.6 0.8
