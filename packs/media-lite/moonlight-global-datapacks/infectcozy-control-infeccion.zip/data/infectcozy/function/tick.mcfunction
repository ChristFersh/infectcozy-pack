execute store result score #jugadores ic_ctrl if entity @a
execute if score #jugadores ic_ctrl matches 1.. run function infectcozy:con_jugadores
execute if score #jugadores ic_ctrl matches 0 if score #antes ic_ctrl matches 1.. run function infectcozy:servidor_vacio
scoreboard players operation #antes ic_ctrl = #jugadores ic_ctrl
# Sueno de la colmena: detectar entrada y salida
execute as @a at @s if dimension inqui:dream run tag @s add ic_en_sueno
# tiempo dentro del sueno: al cumplirse, despiertas solo
execute as @a[tag=ic_en_sueno] at @s if dimension inqui:dream run scoreboard players add @s ic_sueno_t 1
execute as @a[tag=ic_en_sueno] if score @s ic_sueno_t = #aviso_sueno ic_ctrl run title @s actionbar {"text":"Sientes que el sueno se desvanece...","color":"dark_purple","italic":true}
execute as @a[tag=ic_en_sueno] if score @s ic_sueno_t >= #dur_sueno ic_ctrl run function infectcozy:sueno/salir
execute as @a[tag=ic_en_sueno] at @s unless dimension inqui:dream run function infectcozy:sueno/despertar
# barra del sueno (se actualiza cada segundo)
execute store result score #gt ic_ctrl run time query gametime
scoreboard players operation #gt ic_ctrl %= #20 ic_ctrl
execute if score #gt ic_ctrl matches 0 as @a[tag=ic_en_sueno] at @s if dimension inqui:dream run function infectcozy:sueno/barra_calc
