# /function infectcozy:nuevo_punto  -> sortea otro punto para el REDNIGHT (solo antes de que caiga)
execute if score #estado ic_ctrl matches 1 run tellraw @s {"text":"El REDNIGHT ya cayo; su punto no se puede cambiar.","color":"red"}
execute if score #estado ic_ctrl matches 1 run return 0
scoreboard players set #rn_ok ic_ctrl 0
tellraw @s [{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Nuevo punto sorteado. Míralo con ","color":"gray"},{"text":"/function infectcozy:estado","color":"yellow"}]
