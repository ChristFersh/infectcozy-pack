# (como y en el jugador) marca o mueve su base protegida a donde esta parado
execute unless dimension minecraft:overworld run return run tellraw @s {"text":"Solo puedes marcar tu base en el mundo normal (Overworld).","color":"red"}
function infectcozy:infeccion/preparar
scoreboard players set #pdentro ic_ctrl 0
function infectcozy:infeccion/yo_en_zona
execute if score #pdentro ic_ctrl matches 1 run return run tellraw @s ["",{"text":"☣ ","color":"dark_red"},{"text":"No puedes marcar tu base dentro de la zona infectada.","color":"red"},{"text":" Sal de la zona o hazla retroceder primero.","color":"gray"}]
execute unless score @s ic_bid matches 1.. run scoreboard players add #bid ic_ctrl 1
execute unless score @s ic_bid matches 1.. run scoreboard players operation @s ic_bid = #bid ic_ctrl
scoreboard players operation #yo ic_ctrl = @s ic_bid
function infectcozy:infeccion/bases/sacar
data modify storage infectcozy:zona nb set value {id:0,x:0,y:0,z:0}
execute store result storage infectcozy:zona nb.id int 1 run scoreboard players get #yo ic_ctrl
execute store result storage infectcozy:zona nb.x int 1 run data get entity @s Pos[0]
execute store result storage infectcozy:zona nb.y int 1 run data get entity @s Pos[1]
execute store result storage infectcozy:zona nb.z int 1 run data get entity @s Pos[2]
data modify storage infectcozy:bases lista append from storage infectcozy:zona nb
tellraw @s ["",{"text":"🏠 ","color":"green"},{"text":"Base protegida en ","color":"green","bold":true},{"nbt":"nb.x","storage":"infectcozy:zona","color":"white"},{"text":" ","color":"gray"},{"nbt":"nb.y","storage":"infectcozy:zona","color":"white"},{"text":" ","color":"gray"},{"nbt":"nb.z","storage":"infectcozy:zona","color":"white"},{"text":" (radio ","color":"gray"},{"score":{"name":"#base_r","objective":"ic_ctrl"},"color":"white"},{"text":" bloques).","color":"gray"}]
tellraw @s {"text":"Los infectados no pueden entrar en ese radio, aunque la zona infectada llegue hasta aquí. Si ya tenías otra base, se movió a este lugar.","color":"gray"}
playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.8 1.2
