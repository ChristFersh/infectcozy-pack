# (como y en el jugador, en el Overworld) avisa al entrar o salir de la zona infectada
scoreboard players set #pdentro ic_ctrl 0
function infectcozy:infeccion/yo_en_zona
execute if score #pdentro ic_ctrl matches 1 unless entity @s[tag=ic_enzona] run function infectcozy:infeccion/entra
execute if score #pdentro ic_ctrl matches 0 if entity @s[tag=ic_enzona] run function infectcozy:infeccion/sale
