execute unless data storage infectcozy:zona ptmp[0] run return 0
execute if score #pdentro ic_ctrl matches 1 run return 0
data modify storage infectcozy:zona p.x set from storage infectcozy:zona ptmp[0].x
data modify storage infectcozy:zona p.z set from storage infectcozy:zona ptmp[0].z
function infectcozy:infeccion/yo_dentro with storage infectcozy:zona p
data remove storage infectcozy:zona ptmp[0]
function infectcozy:infeccion/yo_marcadas
