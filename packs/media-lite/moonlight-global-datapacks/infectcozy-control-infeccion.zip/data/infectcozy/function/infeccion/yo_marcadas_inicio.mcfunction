data modify storage infectcozy:zona ptmp set from storage infectcozy:zonas lista
function infectcozy:infeccion/yo_marcadas
