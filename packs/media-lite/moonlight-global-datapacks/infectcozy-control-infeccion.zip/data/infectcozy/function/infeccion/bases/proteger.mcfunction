# Cada segundo: ningun infectado puede estar dentro del radio de una base protegida
execute unless data storage infectcozy:bases lista[0] run return 0
data modify storage infectcozy:zona btmp set from storage infectcozy:bases lista
execute store result storage infectcozy:zona b.r int 1 run scoreboard players get #base_r ic_ctrl
# los monticulos se quitan un poco mas lejos (+20), porque esparcen la infeccion alrededor
scoreboard players operation #bro ic_ctrl = #base_r ic_ctrl
scoreboard players add #bro ic_ctrl 20
execute store result storage infectcozy:zona b.rm int 1 run scoreboard players get #bro ic_ctrl
scoreboard players operation #bro ic_ctrl *= #2 ic_ctrl
execute store result storage infectcozy:zona b.r2 int 1 run scoreboard players get #bro ic_ctrl
function infectcozy:infeccion/bases/recorrer
