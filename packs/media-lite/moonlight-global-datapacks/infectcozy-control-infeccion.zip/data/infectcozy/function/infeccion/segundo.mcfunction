# Cada segundo (con jugadores): zona infectada, bases protegidas, retroceso y avisos
scoreboard players set #c1s ic_ctrl 0
execute unless entity @a run return 0
function infectcozy:infeccion/preparar
function infectcozy:infeccion/nuevos
scoreboard players add #c10 ic_ctrl 1
execute if score #c10 ic_ctrl matches 10.. run function infectcozy:infeccion/alejados
function infectcozy:infeccion/bases/proteger
execute if entity @a[scores={ic_kproto=1..}] run function infectcozy:infeccion/retroceso
execute if entity @a[scores={ic_ktumor=1..}] run function infectcozy:infeccion/retroceso
execute as @a[gamemode=!spectator] at @s if dimension minecraft:overworld run function infectcozy:infeccion/aviso_jugador
