# Infectados que aparecieron desde el ultimo segundo (solo Overworld)
execute in minecraft:overworld as @e[type=#spore:fungus_entities,tag=!ic_zv,distance=0..] run tag @s add ic_zn
execute unless entity @e[tag=ic_zn] run return 0
# nunca se tocan: el infectado que deja un jugador al morir (puede llevar sus cosas)
tag @e[tag=ic_zn,type=spore:inf_player] add ic_zx
# la colmena (Proto Hivemind, Hivetumor y el monticulo primordial) la revisa zonas/limpiar con su propio aviso
tag @e[tag=ic_zn,type=spore:proto] add ic_zh
tag @e[tag=ic_zn,type=spore:hivetumor] add ic_zh
tag @e[tag=ic_zn,type=spore:mound,nbt={age:10}] add ic_zh
# dentro de la zona principal o de algun foco marcado -> ic_zd
data modify storage infectcozy:zona a set from storage infectcozy:zona m
data modify storage infectcozy:zona a.t set value "ic_zn"
execute if score #zon ic_ctrl matches 1 run function infectcozy:infeccion/dentro with storage infectcozy:zona a
execute if score #zmar ic_ctrl matches 1 run function infectcozy:infeccion/marcadas_inicio
# en las estructuras de Spore (laboratorios, iglesias, minas...) sus infectados se respetan
execute as @e[tag=ic_zn,tag=!ic_zd,tag=!ic_zx,tag=!ic_zh] at @s if predicate infectcozy:en_estructura_spore run tag @s add ic_zd
# el resto aparecio fuera de la zona: la infeccion no sale del suelo aqui
execute as @e[tag=ic_zn,tag=!ic_zd,tag=!ic_zx,tag=!ic_zh] at @s run function infectcozy:infeccion/hundir
tag @e[tag=ic_zn] add ic_zv
tag @e[tag=ic_zn] remove ic_zd
tag @e[tag=ic_zn] remove ic_zn
