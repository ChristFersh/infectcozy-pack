# (como el jugador) muestra su base protegida y su distancia a la zona infectada
execute if score #estado ic_ctrl matches 1 if dimension minecraft:overworld run function infectcozy:infeccion/mi_distancia
execute unless score @s ic_bid matches 1.. run return run function infectcozy:infeccion/bases/ayuda
scoreboard players operation #yo ic_ctrl = @s ic_bid
data modify storage infectcozy:zona st set from storage infectcozy:bases lista
data remove storage infectcozy:zona vb
function infectcozy:infeccion/bases/buscar_rec
execute unless data storage infectcozy:zona vb run return run function infectcozy:infeccion/bases/ayuda
tellraw @s ["",{"text":"🏠 ","color":"green"},{"text":"Tu base protegida: ","color":"green","bold":true},{"nbt":"vb.x","storage":"infectcozy:zona","color":"white"},{"text":" ","color":"gray"},{"nbt":"vb.y","storage":"infectcozy:zona","color":"white"},{"text":" ","color":"gray"},{"nbt":"vb.z","storage":"infectcozy:zona","color":"white"},{"text":" (radio ","color":"gray"},{"score":{"name":"#base_r","objective":"ic_ctrl"},"color":"white"},{"text":" bloques).","color":"gray"}]
tellraw @s {"text":"/trigger base → moverla a donde estás   ·   /trigger base set 2 → quitarla","color":"gray"}
