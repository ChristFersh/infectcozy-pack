# /function infectcozy:infeccion/velocidad {bloques:10}  -> bloques por hora de juego (con jugadores) que crece la zona; 0 = no crece
$scoreboard players set #zv ic_ctrl $(bloques)
execute if score #zv ic_ctrl matches ..0 run scoreboard players set #zona_paso ic_ctrl 2147483647
execute if score #zv ic_ctrl matches 1.. run scoreboard players operation #zona_paso ic_ctrl = #72000 ic_ctrl
execute if score #zv ic_ctrl matches 1.. run scoreboard players operation #zona_paso ic_ctrl /= #zv ic_ctrl
scoreboard players set #zona_t ic_ctrl 0
function infectcozy:infeccion/estado
