# /function infectcozy:infeccion/retroceso_ajustar {proto:25,tumor:10}  -> bloques que retrocede la zona por cada colmena destruida
$scoreboard players set #ret_proto ic_ctrl $(proto)
$scoreboard players set #ret_tumor ic_ctrl $(tumor)
function infectcozy:infeccion/estado
