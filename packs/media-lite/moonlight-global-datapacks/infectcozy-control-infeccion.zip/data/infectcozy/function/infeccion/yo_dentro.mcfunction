# (MACRO x z r, como y en el jugador)
$execute positioned $(x) ~ $(z) if entity @s[distance=..$(r)] run scoreboard players set #pdentro ic_ctrl 1
