# un paso de Newton: g = (g + n / g) / 2
scoreboard players operation #q ic_ctrl = #n ic_ctrl
scoreboard players operation #q ic_ctrl /= #g ic_ctrl
scoreboard players operation #g ic_ctrl += #q ic_ctrl
scoreboard players operation #g ic_ctrl /= #2 ic_ctrl
