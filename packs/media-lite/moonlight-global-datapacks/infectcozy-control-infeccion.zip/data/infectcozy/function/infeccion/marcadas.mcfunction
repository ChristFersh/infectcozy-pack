execute unless data storage infectcozy:zona tmp[0] run return 0
data modify storage infectcozy:zona a.x set from storage infectcozy:zona tmp[0].x
data modify storage infectcozy:zona a.z set from storage infectcozy:zona tmp[0].z
function infectcozy:infeccion/dentro with storage infectcozy:zona a
data remove storage infectcozy:zona tmp[0]
function infectcozy:infeccion/marcadas
