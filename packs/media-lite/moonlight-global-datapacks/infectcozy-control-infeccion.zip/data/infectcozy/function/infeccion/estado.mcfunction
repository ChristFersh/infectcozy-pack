# (desde estado) datos de la zona infectada
scoreboard players operation #bph ic_ctrl = #72000 ic_ctrl
scoreboard players operation #bph ic_ctrl /= #zona_paso ic_ctrl
tellraw @s ["",{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Zona infectada: radio ","color":"gray"},{"score":{"name":"#zona_r","objective":"ic_ctrl"},"color":"red","bold":true},{"text":" bloques alrededor de la colmena; crece ","color":"gray"},{"score":{"name":"#bph","objective":"ic_ctrl"},"color":"white"},{"text":" bloques por hora de juego.","color":"gray"}]
execute if entity @s[type=minecraft:player] if dimension minecraft:overworld run function infectcozy:infeccion/mi_distancia
execute store result score #nb ic_ctrl run data get storage infectcozy:bases lista
tellraw @s ["",{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Bases protegidas: ","color":"gray"},{"score":{"name":"#nb","objective":"ic_ctrl"},"color":"white"},{"text":" (radio ","color":"gray"},{"score":{"name":"#base_r","objective":"ic_ctrl"},"color":"white"},{"text":"). Matar un Proto Hivemind la hace retroceder ","color":"gray"},{"score":{"name":"#ret_proto","objective":"ic_ctrl"},"color":"white"},{"text":" bloques; una Hivetumor, ","color":"gray"},{"score":{"name":"#ret_tumor","objective":"ic_ctrl"},"color":"white"},{"text":".","color":"gray"}]
