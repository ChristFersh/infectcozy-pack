# (como el jugador) quita su base protegida
execute unless score @s ic_bid matches 1.. run return run tellraw @s {"text":"No tienes ninguna base protegida.","color":"gray"}
scoreboard players operation #yo ic_ctrl = @s ic_bid
function infectcozy:infeccion/bases/sacar
execute if score #sacadas ic_ctrl matches 0 run return run tellraw @s {"text":"No tienes ninguna base protegida.","color":"gray"}
tellraw @s ["",{"text":"🏠 ","color":"yellow"},{"text":"Quitaste la protección de tu base.","color":"yellow"}]
