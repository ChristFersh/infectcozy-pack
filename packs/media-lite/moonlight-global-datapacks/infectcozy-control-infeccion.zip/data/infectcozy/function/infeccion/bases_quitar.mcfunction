# /function infectcozy:infeccion/bases_quitar {id:3}  -> quita la base con ese id
$scoreboard players set #yo ic_ctrl $(id)
function infectcozy:infeccion/bases/sacar
tellraw @s ["",{"text":"🏠 Bases quitadas: ","color":"yellow"},{"score":{"name":"#sacadas","objective":"ic_ctrl"},"color":"white"}]
