# (como y en el infectado) se hunde en el vacio y desaparece sin soltar nada en la superficie
tp @s ~ -400 ~
kill @s
