# (como y en el jugador) /trigger base  -> 1 marcar aqui, 2 quitar, 3 ver
scoreboard players operation #bt ic_ctrl = @s base
scoreboard players set @s base 0
scoreboard players enable @s base
execute if score #bt ic_ctrl matches 1 run return run function infectcozy:infeccion/bases/marcar
execute if score #bt ic_ctrl matches 2 run return run function infectcozy:infeccion/bases/quitar_mia
function infectcozy:infeccion/bases/ver
