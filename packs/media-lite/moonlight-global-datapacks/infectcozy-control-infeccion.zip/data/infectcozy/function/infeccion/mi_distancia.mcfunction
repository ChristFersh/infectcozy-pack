# (como el jugador) distancia en horizontal a la frontera de la zona principal
execute store result score #px ic_ctrl run data get entity @s Pos[0]
execute store result score #pz ic_ctrl run data get entity @s Pos[2]
execute store result score #cx ic_ctrl run data get storage infectcozy:ctrl rn.x
execute store result score #cz ic_ctrl run data get storage infectcozy:ctrl rn.z
scoreboard players operation #px ic_ctrl -= #cx ic_ctrl
scoreboard players operation #pz ic_ctrl -= #cz ic_ctrl
execute if score #px ic_ctrl matches ..-1 run scoreboard players operation #px ic_ctrl *= #-1 ic_ctrl
execute if score #pz ic_ctrl matches ..-1 run scoreboard players operation #pz ic_ctrl *= #-1 ic_ctrl
execute if score #px ic_ctrl matches 30000.. run return run tellraw @s {"text":"Estás demasiado lejos de la colmena para medir la distancia.","color":"gray"}
execute if score #pz ic_ctrl matches 30000.. run return run tellraw @s {"text":"Estás demasiado lejos de la colmena para medir la distancia.","color":"gray"}
# raiz cuadrada entera de dx^2 + dz^2 (Newton, empezando desde |dx| + |dz|)
scoreboard players operation #g ic_ctrl = #px ic_ctrl
scoreboard players operation #g ic_ctrl += #pz ic_ctrl
scoreboard players operation #px ic_ctrl *= #px ic_ctrl
scoreboard players operation #pz ic_ctrl *= #pz ic_ctrl
scoreboard players operation #n ic_ctrl = #px ic_ctrl
scoreboard players operation #n ic_ctrl += #pz ic_ctrl
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
execute if score #g ic_ctrl matches 1.. run function infectcozy:infeccion/raiz
scoreboard players operation #fr ic_ctrl = #g ic_ctrl
scoreboard players operation #fr ic_ctrl -= #zona_r ic_ctrl
execute if score #fr ic_ctrl matches 1.. run tellraw @s ["",{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Estás a ","color":"gray"},{"score":{"name":"#fr","objective":"ic_ctrl"},"color":"green","bold":true},{"text":" bloques fuera de la frontera (a ","color":"gray"},{"score":{"name":"#g","objective":"ic_ctrl"},"color":"white"},{"text":" de la colmena).","color":"gray"}]
scoreboard players operation #fr ic_ctrl *= #-1 ic_ctrl
execute if score #fr ic_ctrl matches 0.. run tellraw @s ["",{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Estás dentro de la zona infectada, a ","color":"gray"},{"score":{"name":"#fr","objective":"ic_ctrl"},"color":"red","bold":true},{"text":" bloques de la frontera (a ","color":"gray"},{"score":{"name":"#g","objective":"ic_ctrl"},"color":"white"},{"text":" de la colmena).","color":"gray"}]
