# Guarda en storage el centro y los radios de la zona principal (los usan las funciones con $)
execute store result storage infectcozy:zona m.x int 1 run data get storage infectcozy:ctrl rn.x
execute store result storage infectcozy:zona m.z int 1 run data get storage infectcozy:ctrl rn.z
execute store result storage infectcozy:zona m.r int 1 run scoreboard players get #zona_r ic_ctrl
scoreboard players operation #zrm ic_ctrl = #zona_r ic_ctrl
scoreboard players operation #zrm ic_ctrl += #zona_margen ic_ctrl
execute store result storage infectcozy:zona m.rm int 1 run scoreboard players get #zrm ic_ctrl
# #zon = 1 si hay zona principal (la infeccion empezo y su punto existe)
scoreboard players set #zon ic_ctrl 0
execute if score #estado ic_ctrl matches 1 if score #rn_ok ic_ctrl matches 1 run scoreboard players set #zon ic_ctrl 1
# #zmar = 1 si un admin marco focos extra (/function infectcozy:zonas/marcar)
scoreboard players set #zmar ic_ctrl 0
execute if data storage infectcozy:zonas lista[0] run scoreboard players set #zmar ic_ctrl 1
