# (MACRO x z r t) etiqueta ic_zd a los que tienen la etiqueta t y estan a r bloques o menos (en horizontal) de x z
$execute as @e[tag=$(t),tag=!ic_zd] at @s positioned $(x) ~ $(z) if entity @s[distance=..$(r)] run tag @s add ic_zd
