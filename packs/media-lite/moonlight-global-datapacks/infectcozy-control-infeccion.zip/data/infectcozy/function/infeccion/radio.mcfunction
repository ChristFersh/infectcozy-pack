# /function infectcozy:infeccion/radio {r:250}  -> fija el radio de la zona infectada (en bloques)
$scoreboard players set #zona_r ic_ctrl $(r)
execute if score #zona_r ic_ctrl < #zona_min ic_ctrl run scoreboard players operation #zona_r ic_ctrl = #zona_min ic_ctrl
execute if score #zona_r ic_ctrl > #zona_max ic_ctrl run scoreboard players operation #zona_r ic_ctrl = #zona_max ic_ctrl
tellraw @s ["",{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Radio de la zona infectada: ","color":"gray"},{"score":{"name":"#zona_r","objective":"ic_ctrl"},"color":"white"},{"text":" bloques.","color":"gray"}]
