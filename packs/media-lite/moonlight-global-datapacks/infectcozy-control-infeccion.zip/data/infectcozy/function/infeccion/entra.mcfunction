tag @s add ic_enzona
title @s actionbar {"text":"☣ Entraste en la zona infectada","color":"red","bold":true}
playsound minecraft:ambient.cave master @s ~ ~ ~ 0.6 0.6
