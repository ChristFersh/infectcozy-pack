tag @s remove ic_enzona
title @s actionbar {"text":"Saliste de la zona infectada","color":"green"}
