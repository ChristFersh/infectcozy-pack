execute unless data storage infectcozy:zona st[0] run return 0
execute store result score #sid ic_ctrl run data get storage infectcozy:zona st[0].id
execute if score #sid ic_ctrl = #yo ic_ctrl run scoreboard players add #sacadas ic_ctrl 1
execute unless score #sid ic_ctrl = #yo ic_ctrl run data modify storage infectcozy:zona sq append from storage infectcozy:zona st[0]
data remove storage infectcozy:zona st[0]
function infectcozy:infeccion/bases/sacar_rec
