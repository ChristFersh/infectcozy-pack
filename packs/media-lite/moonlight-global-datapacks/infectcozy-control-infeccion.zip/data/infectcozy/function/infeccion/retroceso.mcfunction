# Un jugador mato un Proto Hivemind o una Hivetumor: la zona infectada retrocede
scoreboard players set #kp ic_ctrl 0
scoreboard players set #kt ic_ctrl 0
execute as @a[scores={ic_kproto=1..}] run scoreboard players operation #kp ic_ctrl += @s ic_kproto
execute as @a[scores={ic_ktumor=1..}] run scoreboard players operation #kt ic_ctrl += @s ic_ktumor
scoreboard players set @a ic_kproto 0
scoreboard players set @a ic_ktumor 0
scoreboard players operation #kp ic_ctrl *= #ret_proto ic_ctrl
scoreboard players operation #kt ic_ctrl *= #ret_tumor ic_ctrl
scoreboard players operation #kp ic_ctrl += #kt ic_ctrl
execute unless score #kp ic_ctrl matches 1.. run return 0
scoreboard players operation #zona_r ic_ctrl -= #kp ic_ctrl
execute if score #zona_r ic_ctrl < #zona_min ic_ctrl run scoreboard players operation #zona_r ic_ctrl = #zona_min ic_ctrl
tellraw @a ["",{"text":"☣ ","color":"dark_green"},{"text":"La colmena pierde fuerza: ","color":"green","bold":true},{"text":"la zona infectada retrocede ","color":"gray"},{"score":{"name":"#kp","objective":"ic_ctrl"},"color":"white"},{"text":" bloques (radio actual: ","color":"gray"},{"score":{"name":"#zona_r","objective":"ic_ctrl"},"color":"white"},{"text":").","color":"gray"}]
execute as @a at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.8 0.7
