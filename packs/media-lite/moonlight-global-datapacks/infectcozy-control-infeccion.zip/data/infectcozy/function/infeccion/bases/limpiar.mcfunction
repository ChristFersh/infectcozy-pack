# (MACRO x y z r rm r2) quita a los infectados dentro del radio (en horizontal) de una base
$execute in minecraft:overworld positioned $(x) $(y) $(z) as @e[type=#spore:fungus_entities,tag=!ic_zx,distance=..$(r2)] at @s positioned $(x) ~ $(z) if entity @s[distance=..$(r)] at @s run function infectcozy:infeccion/hundir_aviso
$execute in minecraft:overworld positioned $(x) $(y) $(z) as @e[type=spore:mound,distance=..$(r2)] at @s positioned $(x) ~ $(z) if entity @s[distance=..$(rm)] at @s run function infectcozy:infeccion/hundir_aviso
