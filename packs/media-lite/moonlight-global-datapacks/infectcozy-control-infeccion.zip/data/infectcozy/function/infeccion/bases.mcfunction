# /function infectcozy:infeccion/bases  -> lista de bases protegidas (id = numero de base del jugador)
execute store result score #nb ic_ctrl run data get storage infectcozy:bases lista
tellraw @s ["",{"text":"🏠 Bases protegidas: ","color":"green"},{"score":{"name":"#nb","objective":"ic_ctrl"},"color":"white"},{"text":" (radio ","color":"gray"},{"score":{"name":"#base_r","objective":"ic_ctrl"},"color":"white"},{"text":")","color":"gray"}]
tellraw @s {"nbt":"lista","storage":"infectcozy:bases","color":"white"}
tag @s add ic_pregunta
execute as @a[scores={ic_bid=1..}] run tellraw @a[tag=ic_pregunta] ["",{"text":" · ","color":"gray"},{"selector":"@s","color":"white"},{"text":" = id ","color":"gray"},{"score":{"name":"@s","objective":"ic_bid"},"color":"white"}]
tag @s remove ic_pregunta
tellraw @s {"text":"Quitar una: /function infectcozy:infeccion/bases_quitar {id:N}","color":"gray"}
