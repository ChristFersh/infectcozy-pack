# Repite "dentro" con cada foco marcado por un admin (usa a.r y a.t ya preparados)
data modify storage infectcozy:zona tmp set from storage infectcozy:zonas lista
function infectcozy:infeccion/marcadas
