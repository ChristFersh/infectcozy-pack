# Quita de la lista las bases con id = #yo (deja en #sacadas cuantas quito)
data modify storage infectcozy:zona st set from storage infectcozy:bases lista
data modify storage infectcozy:zona sq set value []
scoreboard players set #sacadas ic_ctrl 0
function infectcozy:infeccion/bases/sacar_rec
data modify storage infectcozy:bases lista set from storage infectcozy:zona sq
