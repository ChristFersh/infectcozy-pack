# Cada 10 s: los infectados que se alejaron de la zona mas del margen (#zona_margen) desaparecen
scoreboard players set #c10 ic_ctrl 0
execute in minecraft:overworld as @e[type=#spore:fungus_entities,tag=ic_zv,tag=!ic_zx,tag=!ic_zh,distance=0..] run tag @s add ic_zc
execute unless entity @e[tag=ic_zc] run return 0
data modify storage infectcozy:zona a set from storage infectcozy:zona m
data modify storage infectcozy:zona a.r set from storage infectcozy:zona m.rm
data modify storage infectcozy:zona a.t set value "ic_zc"
execute if score #zon ic_ctrl matches 1 run function infectcozy:infeccion/dentro with storage infectcozy:zona a
execute if score #zmar ic_ctrl matches 1 run function infectcozy:infeccion/marcadas_inicio
execute as @e[tag=ic_zc,tag=!ic_zd] at @s if predicate infectcozy:en_estructura_spore run tag @s add ic_zd
execute as @e[tag=ic_zc,tag=!ic_zd] at @s run function infectcozy:infeccion/hundir_aviso
tag @e[tag=ic_zc] remove ic_zd
tag @e[tag=ic_zc] remove ic_zc
