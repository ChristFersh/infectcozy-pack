tellraw @s ["",{"text":"🏠 Bases protegidas","color":"green","bold":true}]
tellraw @s {"text":"/trigger base → marca tu base donde estás parado (fuera de la zona infectada).","color":"gray"}
tellraw @s {"text":"/trigger base set 2 → quita la protección   ·   /trigger base set 3 → ver tu base y la distancia a la infección.","color":"gray"}
