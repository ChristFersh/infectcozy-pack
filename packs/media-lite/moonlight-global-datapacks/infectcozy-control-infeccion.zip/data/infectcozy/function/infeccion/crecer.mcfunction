# la zona infectada crece 1 bloque (hasta #zona_max)
scoreboard players set #zona_t ic_ctrl 0
execute if score #zona_r ic_ctrl < #zona_max ic_ctrl run scoreboard players add #zona_r ic_ctrl 1
