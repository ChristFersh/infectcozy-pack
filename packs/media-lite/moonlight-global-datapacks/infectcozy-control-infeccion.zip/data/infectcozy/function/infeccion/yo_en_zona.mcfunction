# (como y en el jugador) #pdentro = 1 si esta dentro de la zona principal o de algun foco marcado
# (necesita infectcozy:infeccion/preparar antes)
data modify storage infectcozy:zona p set from storage infectcozy:zona m
execute if score #zon ic_ctrl matches 1 run function infectcozy:infeccion/yo_dentro with storage infectcozy:zona p
execute if score #pdentro ic_ctrl matches 0 if score #zmar ic_ctrl matches 1 run function infectcozy:infeccion/yo_marcadas_inicio
