# (como y en el infectado) igual que hundir, pero se ve y se oye
particle minecraft:large_smoke ~ ~1 ~ 0.4 0.6 0.4 0.02 12
playsound minecraft:entity.warden.dig hostile @a[distance=..24] ~ ~ ~ 0.5 1.6
function infectcozy:infeccion/hundir
