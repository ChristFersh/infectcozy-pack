# /function infectcozy:infeccion/bases_radio {r:48}  -> radio de proteccion de las bases
$scoreboard players set #base_r ic_ctrl $(r)
execute if score #base_r ic_ctrl matches ..0 run scoreboard players set #base_r ic_ctrl 1
tellraw @s ["",{"text":"[Infect Cozy] ","color":"dark_red"},{"text":"Radio de las bases protegidas: ","color":"gray"},{"score":{"name":"#base_r","objective":"ic_ctrl"},"color":"white"},{"text":" bloques.","color":"gray"}]
