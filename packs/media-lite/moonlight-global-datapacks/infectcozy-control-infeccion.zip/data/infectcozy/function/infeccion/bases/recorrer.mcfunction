execute unless data storage infectcozy:zona btmp[0] run return 0
data modify storage infectcozy:zona b.x set from storage infectcozy:zona btmp[0].x
data modify storage infectcozy:zona b.y set from storage infectcozy:zona btmp[0].y
data modify storage infectcozy:zona b.z set from storage infectcozy:zona btmp[0].z
function infectcozy:infeccion/bases/limpiar with storage infectcozy:zona b
data remove storage infectcozy:zona btmp[0]
function infectcozy:infeccion/bases/recorrer
