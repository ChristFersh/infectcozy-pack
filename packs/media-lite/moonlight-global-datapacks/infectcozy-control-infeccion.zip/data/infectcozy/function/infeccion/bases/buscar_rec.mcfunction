execute unless data storage infectcozy:zona st[0] run return 0
execute store result score #sid ic_ctrl run data get storage infectcozy:zona st[0].id
execute if score #sid ic_ctrl = #yo ic_ctrl run return run data modify storage infectcozy:zona vb set from storage infectcozy:zona st[0]
data remove storage infectcozy:zona st[0]
function infectcozy:infeccion/bases/buscar_rec
