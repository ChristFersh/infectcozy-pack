# se cumplio el tiempo: el REDNIGHT caera cerca del spawn (nunca encima) en cuanto su zona este cargada
scoreboard players set #estado ic_ctrl 1
scoreboard players set #progreso ic_ctrl 0
scoreboard players set #rn_try ic_ctrl 0
scoreboard players set #rn_pend ic_ctrl 1
# la zona infectada nace chica alrededor del punto y crece desde ahi
scoreboard players set #zona_r ic_ctrl 64
scoreboard players set #zona_t ic_ctrl 0
# cargar la zona del punto para que pueda caer
function inqui:chunkloader
