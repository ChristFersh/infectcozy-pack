# se cumplio el tiempo: el REDNIGHT caera cerca del spawn (nunca encima) en cuanto su zona este cargada
scoreboard players set #estado ic_ctrl 1
scoreboard players set #progreso ic_ctrl 0
scoreboard players set #rn_try ic_ctrl 0
scoreboard players set #rn_pend ic_ctrl 1
function inqui:chunkloader
