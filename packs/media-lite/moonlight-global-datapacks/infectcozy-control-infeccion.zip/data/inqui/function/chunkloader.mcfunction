#chunkload for protos
schedule function inqui:chunkloader 300s
forceload remove all
# [Infect Cozy] sin jugadores conectados no se mantiene cargada ninguna zona de la infeccion
execute unless entity @a run return 0
#increased block replacement range
gamerule commandModificationBlockLimit 999999999
#remove some overspawners  [Infect Cozy] una sola pasada (las otras dos repetian la misma zona)
execute as @e[type=spore:proto,tag=!proto_nai] at @s run fill ~-100 ~-100 ~-100 ~100 ~100 ~100 spore:organite replace spore:overgrown_spawner
# first layer proto
execute as @e[type=spore:proto,tag=!proto_nai] at @s run forceload add ~-100 ~-100 ~100 ~100
# [Infect Cozy] sin la segunda capa: solo se mantiene cargado el centro de la colmena (200x200 bloques, antes 400x400)
#water  [Infect Cozy] dentro de la zona cargada (fill falla si parte de la zona no esta cargada)
execute as @e[type=spore:proto,tag=!proto_nai] at @s run fill ~100 62 ~100 ~-100 62 ~-100 spore:crusted_bile replace water
# first layer red  [Infect Cozy] alrededor del REDNIGHT, no del spawn
execute if score #estado ic_ctrl matches 1 if score #rn_ok ic_ctrl matches 1 run function infectcozy:rednight/forzar with storage infectcozy:ctrl rn
