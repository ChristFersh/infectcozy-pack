# [Infect Cozy] copia de inqui:20min: hiper-infectados de la colmena segun la corrupcion
#   colmena: 1 de cada tipo desde 70, 2 desde 140 | tumores: desde 140
schedule function inqui:20min 1200s
#proto vervas
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:inquisitor ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:inquisitor ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:brot ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:brot ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:wendigo ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:wendigo ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:ogre ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:ogre ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:hollen ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:hollen ~ ~ ~ {PersistenceRequired:1b}
#child spawns
execute if score !finale proto matches 140.. as @e[type=spore:hivetumor] at @s run summon spore:inquisitor ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:hivetumor] at @s run summon spore:brot ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:hivetumor] at @s run summon spore:wendigo ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:hivetumor] at @s run summon spore:ogre ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:hivetumor] at @s run summon spore:hollen ~ ~ ~ {PersistenceRequired:1b}
#proto spread
execute as @e[type=spore:proto,tag=!proto_nai] at @s run effect give @e[ type= #inqui:hyper , distance=..5 ] minecraft:slowness 10 1 true
execute as @e[type=spore:proto,tag=!proto_nai] at @s run effect give @e[ type= #inqui:hyper , distance=..5 ] minecraft:weakness 10 1 true
execute as @e[type=spore:proto,tag=!proto_nai] at @s run spreadplayers ~ ~ 15 175 false @e[type= #inqui:hyper, distance=..20]
#child spread
execute as @e[type=spore:hivetumor] at @s run effect give @e[ type= #inqui:hyper , distance=..5 ] minecraft:slowness 20 2 true
execute as @e[type=spore:hivetumor] at @s run effect give @e[ type= #inqui:hyper , distance=..5 ] minecraft:weakness 20 2 true
execute as @e[type=spore:hivetumor] at @s run spreadplayers ~ ~ 5 75 false @e[type= #inqui:hyper, distance=..20]
#bosses check
execute if score !finale finalitas matches 1 if score !finale fames matches 0 unless entity @e[type=spore:inf_player,tag=trinity] run function inqui:lore/boss1
execute if score !finale finalitas matches 1 if score !finale fames matches 1 if score !finale impotentia matches 0 unless entity @e[type=spore:inf_player,tag=trinity] run function inqui:lore/boss2
execute if score !finale finalitas matches 1 if score !finale impotentia matches 1 if score !finale desperatio matches 0 unless entity @e[type=spore:inf_player,tag=trinity] run function inqui:lore/boss3
execute if score !finale finalitas matches 1 if score !finale desperatio matches 1 if score !finale odium matches 0 unless entity @e[type=spore:inf_player,tag=trinity] run function inqui:lore/boss4
