# [Infect Cozy] copia de inqui:8min: evolucionados de la colmena segun la corrupcion
#   colmena: 1 de cada tipo siempre, 2 desde 70, 3 desde 140 | tumores: desde 70
schedule function inqui:8min 600s
#yeah i know, they are 10 mins instead of 8, but who cares XDDDD
#red strong
execute as @e[type=spore:proto,tag=nunny] as @s run effect give @e[ type= spore:proto ] minecraft:health_boost infinite 255 true
#proto vervas
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:braiomil ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:braiomil ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:braiomil ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:knight ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:knight ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:knight ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:griefer ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:griefer ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:griefer ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:busser ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:busser ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:busser ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:scavenger ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:scavenger ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:scavenger ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:jagd ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:jagd ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:jagd ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:thorn ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:thorn ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:thorn ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:stalker ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:stalker ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:stalker ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:protector ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:protector ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:protector ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:nuclea ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:nuclea ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:nuclea ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:brute ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:brute ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:brute ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:inebriater ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:inebriater ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:inebriater ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:naiad ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:naiad ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:naiad ~ ~ ~ {PersistenceRequired:1b}
execute as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:bloater ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:bloater ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 140.. as @e[type=spore:proto,tag=!proto_nai] at @s run summon spore:bloater ~ ~ ~ {PersistenceRequired:1b}
#child spawns
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:braiomil ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:knight ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:griefer ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:busser ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:scavenger ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:jagd ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:thorn ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:stalker ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:protector ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:nuclea ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:brute ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:inebriater ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:naiad ~ ~ ~ {PersistenceRequired:1b}
execute if score !finale proto matches 70.. as @e[type=spore:hivetumor] at @s run summon spore:bloater ~ ~ ~ {PersistenceRequired:1b}
#proto spread
execute as @e[type=spore:proto,tag=!proto_nai] at @s run effect give @e[ type= #inqui:evolved , distance=..5 ] minecraft:slowness 10 1 true
execute as @e[type=spore:proto,tag=!proto_nai] at @s run effect give @e[ type= #inqui:evolved , distance=..5 ] minecraft:weakness 10 1 true
execute as @e[type=spore:proto,tag=!proto_nai] at @s run spreadplayers ~ ~ 10 175 false @e[type= #inqui:evolved, distance=..20]
#child spread
execute as @e[type=spore:hivetumor] at @s run effect give @e[ type= #inqui:evolved , distance=..5 ] minecraft:slowness 20 2 true
execute as @e[type=spore:hivetumor] at @s run effect give @e[ type= #inqui:evolved , distance=..5 ] minecraft:weakness 20 2 true
execute as @e[type=spore:hivetumor] at @s run spreadplayers ~ ~ 5 75 false @e[type= #inqui:evolved, distance=..20]
