# [Infect Cozy] copia de inqui:defense_mini: el tumor aparece en la superficie, no 15 bloques abajo
execute as @e[type=spore:proto,tag=nunny] at @s if entity @p[distance=..45] run playsound spore:tumor_ambient neutral @a ~ ~ ~ 2 0.1 1
execute as @e[type=spore:proto,tag=nunny] at @s if entity @p[distance=..45] positioned ~3 ~ ~3 positioned over motion_blocking_no_leaves run summon spore:hivetumor ~ ~ ~
