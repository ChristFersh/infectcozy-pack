# [Infect Cozy] Spore Inquisition ponia 750: se reaparecia muy lejos y podia caer dentro de la infeccion
gamerule spawnRadius 48
