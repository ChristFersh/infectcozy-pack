# [Infect Cozy] ordalias desactivadas: ya no aparecen infectados debajo del jugador
tag @e[tag=ordeal_runner] remove ordeal_runner
