# [Infect Cozy] copia de inqui:capullo SIN la invocacion automatica de REDNIGHT y los Apostoles.
# El REDNIGHT lo invoca infectcozy:iniciar cuando se cumple el tiempo de juego configurado.
#creates the scoreboard proto for the proto modifiers
scoreboard objectives add capullo dummy "capullin start"
scoreboard players add !capullo capullo 1
# [Infect Cozy] quitado: Spore Inquisition activaba el respawn inmediato (sin pantalla de muerte)
gamerule doImmediateRespawn false
kill @e[ type= spore:mound , nbt={age:5}]

execute as @e[type=spore:mound,nbt={age:10}] run scoreboard objectives add rednight dummy "yapper"
execute as @e[type=spore:mound,nbt={age:10}] unless score @s rednight matches 0.. run scoreboard players set @s rednight 6
execute if score !capullo capullo matches 1 run schedule function inqui:calls/start1 5s
#bosses scoreboards
scoreboard objectives add fames dummy
scoreboard objectives add impotentia dummy
scoreboard objectives add odium dummy
scoreboard objectives add desperatio dummy

#misc scoreboards
scoreboard objectives add rage dummy
scoreboard objectives add overcharged_calamity dummy "overcharged calamity thing"
scoreboard objectives add trinity dummy
scoreboard objectives add dream dummy
scoreboard objectives add webon dummy
scoreboard objectives add no_ordeal dummy
scoreboard objectives add raids dummy
scoreboard objectives add judment dummy "weak"
#entity functions
function inqui:calls/maid_removal
function inqui:calls/guard_removal
function inqui:calls/snowman_removal

#teams
team add peace
team add dragon_boss
#spore-inquisition config bridge objectives (seeded by the Java mod's ScoreboardSync; the defaults
#below are a fallback so the datapack still behaves if a value was never written).
scoreboard objectives add corruption_rate dummy
scoreboard objectives add auto_finalitas dummy
scoreboard objectives add fin_lock dummy
scoreboard objectives add offer1 dummy
scoreboard objectives add offer2 dummy
scoreboard objectives add offer3 dummy
scoreboard objectives add ord_thr1 dummy
scoreboard objectives add ord_thr2 dummy
scoreboard objectives add ord_thr3 dummy
scoreboard objectives add ord_thr4 dummy
execute unless score !finale corruption_rate = !finale corruption_rate run scoreboard players set !finale corruption_rate 1
execute unless score !finale auto_finalitas = !finale auto_finalitas run scoreboard players set !finale auto_finalitas 1
execute unless score !finale fin_lock = !finale fin_lock run scoreboard players set !finale fin_lock 0
execute unless score !finale offer1 = !finale offer1 run scoreboard players set !finale offer1 25
execute unless score !finale offer2 = !finale offer2 run scoreboard players set !finale offer2 50
execute unless score !finale offer3 = !finale offer3 run scoreboard players set !finale offer3 100
execute unless score !finale ord_thr1 = !finale ord_thr1 run scoreboard players set !finale ord_thr1 70
execute unless score !finale ord_thr2 = !finale ord_thr2 run scoreboard players set !finale ord_thr2 140
execute unless score !finale ord_thr3 = !finale ord_thr3 run scoreboard players set !finale ord_thr3 210
execute unless score !finale ord_thr4 = !finale ord_thr4 run scoreboard players set !finale ord_thr4 280

#V2
scoreboard objectives add inf_pla_boss dummy "final raid thing"
# 1728000 and 3456000
scoreboard players add !capullo capullo 1
