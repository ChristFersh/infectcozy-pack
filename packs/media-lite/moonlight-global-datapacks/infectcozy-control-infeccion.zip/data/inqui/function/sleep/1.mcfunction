# [Infect Cozy] reemplaza inqui:sleep/1
# El Sueno solo ocurre con un 10% de probabilidad cada vez que un infectado mata al jugador.
# Los novatos nunca caen en el Sueno
execute if entity @s[tag=ic_novato] run return run advancement revoke @s only inqui:bad_1
execute store result score @s ic_dado run random value 1..100
execute unless score !finale dream matches 1 if score @s ic_dado <= #prob_sueno ic_ctrl run function infectcozy:sueno/iniciar
# si no toco el sueno, se reinicia el logro para que la proxima muerte vuelva a tirar el dado
execute unless score @s ic_dado <= #prob_sueno ic_ctrl run advancement revoke @s only inqui:bad_1
execute if score !finale dream matches 1 run advancement revoke @s only inqui:bad_1
