# [Infect Cozy] copia de inqui:20sec_calls/v2: los ayudantes del FIXER aparecen en la superficie
execute positioned over motion_blocking_no_leaves run summon spore:verva ~ ~ ~
execute positioned over motion_blocking_no_leaves run summon spore:verva ~ ~ ~
spreadplayers ~ ~ 5 10 false @e[type=spore:verva, distance=..20]
