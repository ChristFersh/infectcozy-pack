tellraw @a [{"text":"✦ ","color":"dark_red"},{"selector":"@s","color":"yellow"},{"text":" llego a Infect Cozy por primera vez.","color":"gray"}]
title @s times 20 80 20
title @s title {"text":"Infect Cozy","color":"dark_red","bold":true}
title @s subtitle {"text":"sobrevive... y no te dejes infectar","color":"gray","italic":true}
give @s minecraft:stone_sword
give @s minecraft:stone_pickaxe
give @s minecraft:stone_axe
give @s minecraft:bread 16
give @s minecraft:torch 32
give @s minecraft:red_bed
give @s patchouli:guide_book[patchouli:book="infectcozy:guia"]
