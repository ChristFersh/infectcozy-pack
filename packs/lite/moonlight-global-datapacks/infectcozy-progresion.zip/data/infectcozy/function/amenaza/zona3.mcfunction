scoreboard players set #amz_l ic_tmp 3
execute as @e[distance=..64,tag=!ic_amz,type=!#infectcozy:amenaza_ignorar,tag=!apostle,tag=!inf_pla_boss] at @s run function infectcozy:amenaza/mob
