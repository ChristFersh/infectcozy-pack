# poder de hechizo (Spell Engine) x2 cuenta como ataque
scoreboard players set #s ic_tmp 0
execute store result score #b ic_tmp run attribute @s spell_power:arcane get 1
execute if score #b ic_tmp > #s ic_tmp run scoreboard players operation #s ic_tmp = #b ic_tmp
execute store result score #b ic_tmp run attribute @s spell_power:fire get 1
execute if score #b ic_tmp > #s ic_tmp run scoreboard players operation #s ic_tmp = #b ic_tmp
execute store result score #b ic_tmp run attribute @s spell_power:frost get 1
execute if score #b ic_tmp > #s ic_tmp run scoreboard players operation #s ic_tmp = #b ic_tmp
execute store result score #b ic_tmp run attribute @s spell_power:healing get 1
execute if score #b ic_tmp > #s ic_tmp run scoreboard players operation #s ic_tmp = #b ic_tmp
execute store result score #b ic_tmp run attribute @s spell_power:lightning get 1
execute if score #b ic_tmp > #s ic_tmp run scoreboard players operation #s ic_tmp = #b ic_tmp
execute store result score #b ic_tmp run attribute @s spell_power:soul get 1
execute if score #b ic_tmp > #s ic_tmp run scoreboard players operation #s ic_tmp = #b ic_tmp
scoreboard players operation #s ic_tmp *= #c2 ic_amz
execute if score #s ic_tmp > @s ic_amz_atk run scoreboard players operation @s ic_amz_atk = #s ic_tmp
