# nivel 4: +100 % vida, +40 % dano, +4 armadura
attribute @s minecraft:generic.max_health modifier add infectcozy:amenaza_vida 1.0 add_multiplied_base
attribute @s minecraft:generic.attack_damage modifier add infectcozy:amenaza_dano 0.4 add_multiplied_base
attribute @s minecraft:generic.armor modifier add infectcozy:amenaza_armadura 4 add_value
