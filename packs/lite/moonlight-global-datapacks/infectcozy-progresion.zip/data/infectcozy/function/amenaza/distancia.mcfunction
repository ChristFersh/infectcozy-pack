# dano de arco o ballesta (Ranged Weapon API)
execute store result score #b ic_tmp run attribute @s ranged_weapon:damage get 1
execute if score #b ic_tmp > @s ic_amz_atk run scoreboard players operation @s ic_amz_atk = #b ic_tmp
