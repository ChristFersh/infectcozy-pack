scoreboard players add #amz_t ic_amz 1
# cada segundo: enemigos nuevos cerca de jugadores
execute if score #amz_t ic_amz matches 20 run function infectcozy:amenaza/mobs
execute if score #amz_t ic_amz matches 40 run function infectcozy:amenaza/mobs
execute if score #amz_t ic_amz matches 60 run function infectcozy:amenaza/mobs
execute if score #amz_t ic_amz matches 80 run function infectcozy:amenaza/mobs
# cada 5 segundos: nivel de cada jugador
execute if score #amz_t ic_amz matches 100.. run function infectcozy:amenaza/jugadores
execute if score #amz_t ic_amz matches 100.. run function infectcozy:amenaza/mobs
execute if score #amz_t ic_amz matches 100.. run scoreboard players set #amz_t ic_amz 0
# /trigger amenaza  -> cualquier jugador ve su nivel
execute as @a[scores={amenaza=1..}] run function infectcozy:amenaza/ver
