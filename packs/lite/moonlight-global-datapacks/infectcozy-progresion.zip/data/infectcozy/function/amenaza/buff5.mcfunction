# nivel 5: +150 % vida, +60 % dano, +6 armadura
attribute @s minecraft:generic.max_health modifier add infectcozy:amenaza_vida 1.5 add_multiplied_base
attribute @s minecraft:generic.attack_damage modifier add infectcozy:amenaza_dano 0.6 add_multiplied_base
attribute @s minecraft:generic.armor modifier add infectcozy:amenaza_armadura 6 add_value
