title @s actionbar [{"text":"☣ Nivel de amenaza ","color":"dark_red"},{"score":{"name":"#n","objective":"ic_tmp"},"color":"red","bold":true},{"text":": los enemigos se adaptan a tu equipo","color":"gray"}]
playsound minecraft:entity.warden.heartbeat hostile @s ~ ~ ~ 1 0.6
