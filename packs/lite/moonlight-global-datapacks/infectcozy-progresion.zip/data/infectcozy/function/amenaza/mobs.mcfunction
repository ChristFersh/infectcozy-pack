execute unless score #amz_on ic_amz matches 1 run return 0
# del nivel mas alto al mas bajo: cada enemigo toma el nivel del jugador mas fuerte que tenga cerca
execute as @a[scores={ic_amz_n=5},gamemode=!creative,gamemode=!spectator] at @s run function infectcozy:amenaza/zona5
execute as @a[scores={ic_amz_n=4},gamemode=!creative,gamemode=!spectator] at @s run function infectcozy:amenaza/zona4
execute as @a[scores={ic_amz_n=3},gamemode=!creative,gamemode=!spectator] at @s run function infectcozy:amenaza/zona3
execute as @a[scores={ic_amz_n=2},gamemode=!creative,gamemode=!spectator] at @s run function infectcozy:amenaza/zona2
execute as @a[scores={ic_amz_n=..1},gamemode=!creative,gamemode=!spectator] at @s run function infectcozy:amenaza/zona1
