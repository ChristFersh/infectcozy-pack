# nivel 2: +25 % vida, +10 % dano
attribute @s minecraft:generic.max_health modifier add infectcozy:amenaza_vida 0.25 add_multiplied_base
attribute @s minecraft:generic.attack_damage modifier add infectcozy:amenaza_dano 0.1 add_multiplied_base
