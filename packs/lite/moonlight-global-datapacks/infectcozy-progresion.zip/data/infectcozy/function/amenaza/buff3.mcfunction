# nivel 3: +60 % vida, +25 % dano, +2 armadura
attribute @s minecraft:generic.max_health modifier add infectcozy:amenaza_vida 0.6 add_multiplied_base
attribute @s minecraft:generic.attack_damage modifier add infectcozy:amenaza_dano 0.25 add_multiplied_base
attribute @s minecraft:generic.armor modifier add infectcozy:amenaza_armadura 2 add_value
