scoreboard players enable @a amenaza
execute as @a[gamemode=!creative,gamemode=!spectator] run function infectcozy:amenaza/calcular
