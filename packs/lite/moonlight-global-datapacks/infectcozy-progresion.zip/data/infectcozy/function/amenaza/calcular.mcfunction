# infectcozy:amenaza/calcular  (como el jugador)
# Guarda lo MEJOR que ha llevado: armadura y ataque (cuerpo a cuerpo, hechizos o arco). Soltar el arma no baja el nivel.
execute store result score #a ic_tmp run attribute @s minecraft:generic.armor get 1
execute if score #a ic_tmp > @s ic_amz_arm run scoreboard players operation @s ic_amz_arm = #a ic_tmp
# ataque cuerpo a cuerpo (sin contar la pocion de fuerza)
scoreboard players set #a ic_tmp 0
execute unless predicate infectcozy:amenaza_fuerza store result score #a ic_tmp run attribute @s minecraft:generic.attack_damage get 1
execute if score #a ic_tmp > @s ic_amz_atk run scoreboard players operation @s ic_amz_atk = #a ic_tmp
# magos y arqueros (funciones aparte: si falta el mod, solo esas no cargan)
function infectcozy:amenaza/hechizo
function infectcozy:amenaza/distancia
# puntaje = armadura + ataque + 3 por cada jefe derrotado
scoreboard players operation #g ic_tmp = @s ic_amz_arm
scoreboard players operation #g ic_tmp += @s ic_amz_atk
scoreboard players add @s ic_jefes 0
scoreboard players operation #j ic_tmp = @s ic_jefes
scoreboard players operation #j ic_tmp *= #c3 ic_amz
scoreboard players operation #g ic_tmp += #j ic_tmp
scoreboard players operation @s ic_amz_g = #g ic_tmp
# niveles
scoreboard players set #n ic_tmp 1
execute if score #g ic_tmp matches 20.. run scoreboard players set #n ic_tmp 2
execute if score #g ic_tmp matches 32.. run scoreboard players set #n ic_tmp 3
execute if score #g ic_tmp matches 48.. run scoreboard players set #n ic_tmp 4
execute if score #g ic_tmp matches 75.. run scoreboard players set #n ic_tmp 5
scoreboard players add @s ic_amz_n 0
execute if score #n ic_tmp > @s ic_amz_n if score @s ic_amz_n matches 1.. run function infectcozy:amenaza/subio
scoreboard players operation @s ic_amz_n = #n ic_tmp
