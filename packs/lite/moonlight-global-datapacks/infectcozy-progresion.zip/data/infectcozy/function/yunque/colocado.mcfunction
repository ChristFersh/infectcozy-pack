advancement revoke @s only infectcozy:yunque/colocar
scoreboard players set #yq_p ic_tmp 0
scoreboard players set #yq_ok ic_tmp 0
# 1) el bloque que miras (lo acabas de poner); 2) si no, el yunque sin activar mas cercano (7x7x7)
execute anchored eyes positioned ^ ^ ^ anchored feet run function infectcozy:yunque/rayo
execute if score #yq_ok ic_tmp matches 0 run function infectcozy:yunque/buscar
execute if score #yq_ok ic_tmp matches 0 run loot give @s loot infectcozy:yunque/item
execute if score #yq_ok ic_tmp matches 0 run tellraw @s {"text":"No encontré dónde pusiste el Yunque del Abismo: te lo devuelvo. Colócalo mirándolo.","color":"red"}
