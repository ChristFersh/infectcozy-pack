item replace entity @s contents from entity @a[tag=ic_yq_yo,limit=1] weapon.mainhand
data modify entity @s item.components."minecraft:stored_enchantments".levels merge from storage infectcozy:yq b
item replace entity @a[tag=ic_yq_yo,limit=1] weapon.mainhand from entity @s contents
kill @s
