playsound minecraft:block.anvil.use block @a ~ ~ ~ 1 0.8
playsound minecraft:block.enchantment_table.use block @a ~ ~ ~ 1 0.7
playsound minecraft:entity.illusioner.cast_spell block @a ~ ~ ~ 0.6 0.6
particle minecraft:enchant ~ ~1.2 ~ 0.4 0.4 0.4 1.2 80
particle minecraft:reverse_portal ~ ~1 ~ 0.3 0.3 0.3 0.08 40
particle minecraft:witch ~ ~1.1 ~ 0.3 0.3 0.3 0 15
