# (como el jugador, en el yunque) mano secundaria = libro, mano principal = objeto
execute unless items entity @s weapon.offhand minecraft:enchanted_book run return run tellraw @s {"text":"Pon el libro encantado en la mano secundaria y el arma o armadura en la principal.","color":"yellow"}
execute if items entity @s weapon.mainhand minecraft:enchanted_book run return run function infectcozy:yunque/libros
scoreboard players set #yq_ok ic_tmp 0
execute if items entity @s weapon.mainhand *[minecraft:max_damage] run scoreboard players set #yq_ok ic_tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_filo:1b}] run scoreboard players set #yq_ok ic_tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_rompe:1b}] run scoreboard players set #yq_ok ic_tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_tridente:1b}] run scoreboard players set #yq_ok ic_tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_arco:1b}] run scoreboard players set #yq_ok ic_tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_amanecer:1b}] run scoreboard players set #yq_ok ic_tmp 1
execute if score #yq_ok ic_tmp matches 0 run return run tellraw @s {"text":"Ese objeto no se puede encantar aquí.","color":"red"}
data modify storage infectcozy:yq b set value {}
data modify storage infectcozy:yq b set from entity @s Inventory[{Slot:-106b}].components."minecraft:stored_enchantments".levels
data modify storage infectcozy:yq a set value {}
data modify storage infectcozy:yq a set from entity @s SelectedItem.components."minecraft:enchantments".levels
execute store result score #yq_n ic_tmp run data get storage infectcozy:yq b
execute if score #yq_n ic_tmp matches 0 run return run tellraw @s {"text":"Ese libro no tiene encantamientos.","color":"red"}
# Tridente del Abismo: nunca encantamientos de estado
scoreboard players set #yq_tri ic_tmp 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_tridente:1b}] run scoreboard players set #yq_tri ic_tmp 1
scoreboard players set #yq_deb ic_tmp 0
execute if data storage infectcozy:yq b."minecraft:fire_aspect" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."minecraft:flame" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."minecraft:bane_of_arthropods" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."tombstone:decrepitude" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."tombstone:frostbite" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."tombstone:incurable_wounds" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."tombstone:plague_bringer" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."spore:corrosive_potency" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."spore:cryogenic_aspect" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."spore:gastric_spewage" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."inqui:deep_freeze" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."inqui:soul_freeze" run scoreboard players set #yq_deb ic_tmp 1
execute if data storage infectcozy:yq b."nova_structures:wither_coated" run scoreboard players set #yq_deb ic_tmp 1
execute if score #yq_tri ic_tmp matches 1 if score #yq_deb ic_tmp matches 1 run return run tellraw @s {"text":"El Tridente del Abismo no acepta encantamientos de estado.","color":"red"}
# Multidisparo: solo ballestas (nivel I) y el Tridente del Abismo (I o II)
scoreboard players set #yq_ms ic_tmp 0
execute if data storage infectcozy:yq b."minecraft:multishot" run scoreboard players set #yq_ms ic_tmp 1
execute if score #yq_ms ic_tmp matches 1 if score #yq_tri ic_tmp matches 0 unless items entity @s weapon.mainhand minecraft:crossbow run return run tellraw @s {"text":"El multidisparo solo sirve en ballestas y en el Tridente del Abismo.","color":"red"}
execute if score #yq_ms ic_tmp matches 1 if score #yq_tri ic_tmp matches 0 if data storage infectcozy:yq b{"minecraft:multishot":2} run return run tellraw @s {"text":"El multidisparo II solo sirve en el Tridente del Abismo.","color":"red"}
scoreboard players set #yq_conf ic_tmp 0
function infectcozy:yunque/gen/conflictos
execute if score #yq_conf ic_tmp matches 1 run return run tellraw @s {"text":"Ese libro choca con un encantamiento que ya tiene el objeto.","color":"red"}
# Coste: 5 niveles y 8 lapislazuli por encantamiento; multidisparo en el tridente +30 niveles y +32 lapislazuli
scoreboard players operation #yq_lv ic_tmp = #yq_n ic_tmp
scoreboard players operation #yq_lv ic_tmp *= #c5 ic_enc
scoreboard players operation #yq_lp ic_tmp = #yq_n ic_tmp
scoreboard players operation #yq_lp ic_tmp *= #c8 ic_enc
execute if score #yq_ms ic_tmp matches 1 if score #yq_tri ic_tmp matches 1 run scoreboard players add #yq_lv ic_tmp 30
execute if score #yq_ms ic_tmp matches 1 if score #yq_tri ic_tmp matches 1 run scoreboard players add #yq_lp ic_tmp 32
function infectcozy:yunque/cobrar
execute if score #yq_pago ic_tmp matches 0 run return 0
function infectcozy:yunque/gen/combinar
execute if items entity @s weapon.mainhand minecraft:crossbow if data storage infectcozy:yq b."minecraft:multishot" run data modify storage infectcozy:yq b."minecraft:multishot" set value 1
tag @s add ic_yq_yo
execute summon minecraft:item_display run function infectcozy:yunque/mezclar
tag @s remove ic_yq_yo
item replace entity @s weapon.offhand with minecraft:air
function infectcozy:yunque/fx
