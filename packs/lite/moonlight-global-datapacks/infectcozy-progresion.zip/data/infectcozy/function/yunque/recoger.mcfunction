setblock ~ ~ ~ minecraft:air
function infectcozy:yunque/quitar
loot give @s loot infectcozy:yunque/item
playsound minecraft:block.anvil.break block @a ~ ~ ~ 0.8 0.8
