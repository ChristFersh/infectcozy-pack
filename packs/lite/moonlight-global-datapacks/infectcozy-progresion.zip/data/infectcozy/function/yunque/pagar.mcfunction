execute store result storage infectcozy:yq c.lv int 1 run scoreboard players get #yq_lv ic_tmp
execute store result storage infectcozy:yq c.lp int 1 run scoreboard players get #yq_lp ic_tmp
function infectcozy:yunque/pagar_m with storage infectcozy:yq c
