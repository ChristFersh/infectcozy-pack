scoreboard players set #yq_t ic_enc 0
execute as @e[type=minecraft:marker,tag=ic_yq] at @s run function infectcozy:yunque/revisar
# arsenal definitivo: coste de yunque 1000 y sin durabilidad (ni mesa de encantamientos ni yunque normal)
execute as @a run function infectcozy:yunque/arsenal
