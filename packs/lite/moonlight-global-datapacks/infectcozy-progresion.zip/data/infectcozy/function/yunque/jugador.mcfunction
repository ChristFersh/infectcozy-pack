# (como el jugador que hizo clic, en la posicion del yunque)
execute if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{flags:{is_sneaking:true}}} run return run function infectcozy:yunque/recoger
function infectcozy:yunque/aplicar
