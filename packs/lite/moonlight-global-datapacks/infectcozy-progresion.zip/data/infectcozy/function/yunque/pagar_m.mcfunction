$xp add @s -$(lv) levels
$clear @s minecraft:lapis_lazuli $(lp)
