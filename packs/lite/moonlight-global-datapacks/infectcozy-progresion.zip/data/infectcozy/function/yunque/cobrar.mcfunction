# #yq_lv niveles y #yq_lp lapislazuli (en creativo es gratis). Deja #yq_pago = 1 si se pudo pagar.
scoreboard players set #yq_pago ic_tmp 1
execute if entity @s[gamemode=creative] run return 0
execute store result score #yq_x ic_tmp run xp query @s levels
execute store result score #yq_y ic_tmp run clear @s minecraft:lapis_lazuli 0
execute if score #yq_x ic_tmp >= #yq_lv ic_tmp if score #yq_y ic_tmp >= #yq_lp ic_tmp run return run function infectcozy:yunque/pagar
scoreboard players set #yq_pago ic_tmp 0
tellraw @s [{"text":"Necesitas ","color":"red"},{"score":{"name":"#yq_lv","objective":"ic_tmp"},"color":"white"},{"text":" niveles y ","color":"red"},{"score":{"name":"#yq_lp","objective":"ic_tmp"},"color":"white"},{"text":" de lapislázuli.","color":"red"}]
playsound minecraft:block.anvil.land block @s ~ ~ ~ 0.5 0.5
