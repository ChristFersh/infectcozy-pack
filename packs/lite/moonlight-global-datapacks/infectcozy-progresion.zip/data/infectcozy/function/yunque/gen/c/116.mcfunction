# tombstone:spectral_conjurer (max 10)
execute store result score #lb ic_tmp run data get storage infectcozy:yq b."tombstone:spectral_conjurer"
execute store result score #la ic_tmp run data get storage infectcozy:yq a."tombstone:spectral_conjurer"
scoreboard players set #eq ic_tmp 0
execute if score #la ic_tmp = #lb ic_tmp run scoreboard players set #eq ic_tmp 1
execute if score #eq ic_tmp matches 1 if score #lb ic_tmp matches ..9 run scoreboard players add #lb ic_tmp 1
execute if score #eq ic_tmp matches 0 if score #la ic_tmp > #lb ic_tmp run scoreboard players operation #lb ic_tmp = #la ic_tmp
execute store result storage infectcozy:yq b."tombstone:spectral_conjurer" int 1 run scoreboard players get #lb ic_tmp
