scoreboard players set #yq_ok ic_tmp 1
summon minecraft:marker ~ ~ ~ {Tags:["ic_yq"]}
summon minecraft:interaction ~ ~ ~ {Tags:["ic_yq_i","ic_yq_off"],width:0.01f,height:0.01f,response:0b}
function infectcozy:yunque/displays
# brillo calido encima (bloque de luz invisible) y estallido de calor
execute if block ~ ~1 ~ minecraft:air run setblock ~ ~1 ~ minecraft:light[level=9]
particle minecraft:flame ~ ~1 ~ 0.35 0.2 0.35 0.05 30
particle minecraft:lava ~ ~1 ~ 0.3 0.1 0.3 0 8
particle minecraft:dust{color:[1.0,0.12,0.05],scale:1.4} ~ ~1.1 ~ 0.4 0.3 0.4 0 40
playsound minecraft:block.respawn_anchor.charge block @a ~ ~ ~ 1 0.7
playsound minecraft:item.firecharge.use block @a ~ ~ ~ 0.6 0.6
playsound minecraft:block.enchantment_table.use block @a ~ ~ ~ 1 0.6
