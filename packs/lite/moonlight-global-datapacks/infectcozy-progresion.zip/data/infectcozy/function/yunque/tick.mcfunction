# Clics en los yunques (cada tick) y comprobacion de los bloques y del arsenal (cada segundo)
# Estado de cada yunque (cada tick): si se rompio, devuelve el item; la zona de clic solo existe con un libro en la mano secundaria
execute as @e[type=minecraft:marker,tag=ic_yq] at @s run function infectcozy:yunque/estado
execute as @e[type=minecraft:interaction,tag=ic_yq_i] at @s if data entity @s interaction run function infectcozy:yunque/uso
execute as @e[type=minecraft:interaction,tag=ic_yq_i] if data entity @s attack run data remove entity @s attack
scoreboard players add #yq_t ic_enc 1
# calor constante (cada 4 ticks)
scoreboard players operation #yq_c ic_tmp = #yq_t ic_enc
scoreboard players operation #yq_c ic_tmp %= #c4 ic_enc
execute if score #yq_c ic_tmp matches 0 as @e[type=minecraft:marker,tag=ic_yq] at @s run function infectcozy:yunque/calor
execute if score #yq_t ic_enc matches 20.. run function infectcozy:yunque/segundo
# Animacion al encantar (el mod infectcozy_yunque marca al jugador con ic_yq_anim)
execute as @a[tag=ic_yq_anim] at @s run function infectcozy:yunque/animar_jugador
# Giro lento del nucleo flotante (un cuarto de vuelta cada 2 segundos)
scoreboard players add #yq_giro ic_tmp 1
execute if score #yq_giro ic_tmp matches 40.. run function infectcozy:yunque/girar
