execute if block ~ ~1 ~ minecraft:light run setblock ~ ~1 ~ minecraft:air
kill @e[type=minecraft:interaction,tag=ic_yq_i,distance=..0.6]
kill @e[type=minecraft:item_display,tag=ic_yq_fx,distance=..1.6]
kill @e[type=minecraft:marker,tag=ic_yq,distance=..0.6]
