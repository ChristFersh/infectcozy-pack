execute unless block ~ ~ ~ #infectcozy:yunque run return run function infectcozy:yunque/roto
# chispas, humo y lava una vez por segundo
particle minecraft:portal ~ ~1.3 ~ 0.3 0.3 0.3 0.4 4
particle minecraft:end_rod ~ ~1.45 ~ 0.05 0.05 0.05 0.005 1
execute if block ~ ~1 ~ minecraft:air run setblock ~ ~1 ~ minecraft:light[level=9]
