# Libro + libro: se combinan (dos de igual nivel suben uno). Multidisparo I + I = II.
data modify storage infectcozy:yq b set value {}
data modify storage infectcozy:yq b set from entity @s Inventory[{Slot:-106b}].components."minecraft:stored_enchantments".levels
data modify storage infectcozy:yq a set value {}
data modify storage infectcozy:yq a set from entity @s SelectedItem.components."minecraft:stored_enchantments".levels
execute store result score #yq_n ic_tmp run data get storage infectcozy:yq b
execute if score #yq_n ic_tmp matches 0 run return run tellraw @s {"text":"Ese libro no tiene encantamientos.","color":"red"}
scoreboard players set #yq_conf ic_tmp 0
function infectcozy:yunque/gen/conflictos
execute if score #yq_conf ic_tmp matches 1 run return run tellraw @s {"text":"Esos libros tienen encantamientos incompatibles.","color":"red"}
# coste: 3 niveles y 3 lapislazuli por encantamiento; multidisparo I + I: +10 niveles y +32 lapislazuli
scoreboard players operation #yq_lv ic_tmp = #yq_n ic_tmp
scoreboard players operation #yq_lv ic_tmp *= #c3 ic_enc
scoreboard players operation #yq_lp ic_tmp = #yq_n ic_tmp
scoreboard players operation #yq_lp ic_tmp *= #c3 ic_enc
scoreboard players set #yq_ms ic_tmp 0
execute if data storage infectcozy:yq b{"minecraft:multishot":1} if data storage infectcozy:yq a{"minecraft:multishot":1} run scoreboard players set #yq_ms ic_tmp 1
execute if score #yq_ms ic_tmp matches 1 run scoreboard players add #yq_lv ic_tmp 10
execute if score #yq_ms ic_tmp matches 1 run scoreboard players add #yq_lp ic_tmp 32
function infectcozy:yunque/cobrar
execute if score #yq_pago ic_tmp matches 0 run return 0
function infectcozy:yunque/gen/combinar
tag @s add ic_yq_yo
execute summon minecraft:item_display run function infectcozy:yunque/mezclar_libro
tag @s remove ic_yq_yo
item replace entity @s weapon.offhand with minecraft:air
function infectcozy:yunque/fx
