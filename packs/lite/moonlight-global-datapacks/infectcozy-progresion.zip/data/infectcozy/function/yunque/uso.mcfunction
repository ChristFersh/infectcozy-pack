data remove entity @s interaction
execute on target run function infectcozy:yunque/jugador
