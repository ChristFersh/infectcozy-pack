# (como un display temporal) arregla el objeto del hueco $(s) del jugador con ic_fix_yo
$item replace entity @s contents from entity @a[tag=ic_fix_yo,limit=1] $(s)
data remove entity @s item.components."!minecraft:max_damage"
data remove entity @s item.components."!minecraft:damage"
data modify entity @s item.components."minecraft:repair_cost" set value 1000
data modify entity @s item.components."minecraft:enchantments".levels."infectcozy:sello_abismo" set value 1
$item replace entity @a[tag=ic_fix_yo,limit=1] $(s) from entity @s contents
kill @s
