# (como el marcador del yunque, cada 4 ticks) chispas del abismo
particle minecraft:dust{color:[0.62,0.22,1.0],scale:0.7} ~ ~1.05 ~ 0.3 0.05 0.3 0 2
particle minecraft:reverse_portal ~ ~1.45 ~ 0.08 0.08 0.08 0.01 1
