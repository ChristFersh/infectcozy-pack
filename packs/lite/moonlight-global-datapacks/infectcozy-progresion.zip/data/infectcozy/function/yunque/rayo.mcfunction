scoreboard players add #yq_p ic_tmp 1
execute if block ~ ~ ~ #infectcozy:yunque align xyz positioned ~0.5 ~ ~0.5 unless entity @e[type=minecraft:marker,tag=ic_yq,distance=..0.5] run return run function infectcozy:yunque/crear
execute if score #yq_p ic_tmp matches ..70 positioned ^ ^ ^0.1 run function infectcozy:yunque/rayo
