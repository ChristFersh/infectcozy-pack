tag @s remove ic_yq_anim
execute as @e[type=minecraft:marker,tag=ic_yq,sort=nearest,limit=1,distance=..8] at @s run function infectcozy:yunque/animar
