# (como el marcador del Yunque del Abismo) animacion al aplicar un libro
# El nucleo sube, crece y da media vuelta; el cuerpo da un golpe seco
execute positioned ~ ~0.5 ~ as @e[type=minecraft:item_display,tag=ic_yq_core,distance=..0.6] run data merge entity @s {start_interpolation:0,interpolation_duration:6,transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.3f,0f],scale:[1.5f,1.5f,1.5f]}}
execute positioned ~ ~0.5 ~ as @e[type=minecraft:item_display,tag=ic_yq_body,distance=..0.6] run data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.02f,0f],scale:[1.04f,0.95f,1.04f]}}
execute positioned ~ ~0.5 ~ run tag @e[type=minecraft:item_display,tag=ic_yq_fx,distance=..0.6] add ic_yq_anim
# Particulas y sonido
particle minecraft:flash ~ ~1.5 ~ 0 0 0 0 1 force
particle minecraft:enchant ~ ~1.6 ~ 0.7 0.7 0.7 1.6 140 force
particle minecraft:reverse_portal ~ ~1.3 ~ 0.4 0.4 0.4 0.2 70 force
particle minecraft:end_rod ~ ~1.4 ~ 0.25 0.5 0.25 0.08 30 force
particle minecraft:witch ~ ~1.5 ~ 0.4 0.4 0.4 0.1 25 force
particle minecraft:dust{color:[0.72,0.25,1.0],scale:1.6} ~ ~1.1 ~ 0.55 0.3 0.55 0 45 force
particle minecraft:dust{color:[1.0,0.31,0.85],scale:1.2} ~ ~1.5 ~ 0.35 0.35 0.35 0 25 force
playsound minecraft:block.enchantment_table.use block @a ~ ~ ~ 1 0.8
playsound minecraft:block.anvil.use block @a ~ ~ ~ 0.6 1.25
playsound minecraft:block.amethyst_block.resonate block @a ~ ~ ~ 1.2 0.9
playsound minecraft:block.beacon.power_select block @a ~ ~ ~ 0.5 1.6
schedule function infectcozy:yunque/animar_fin 14t replace
