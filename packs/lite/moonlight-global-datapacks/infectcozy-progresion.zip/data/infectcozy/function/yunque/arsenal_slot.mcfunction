$execute summon minecraft:item_display run function infectcozy:yunque/arsenal_d {s:"$(s)"}
