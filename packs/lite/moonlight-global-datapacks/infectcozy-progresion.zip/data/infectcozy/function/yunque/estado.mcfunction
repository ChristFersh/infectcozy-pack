# (como el marcador del yunque, cada tick)
# Version anterior (yunque arcano de Iron's): se cambia por un yunque normal, que abre el menu de encantar.
execute if block ~ ~ ~ irons_spellbooks:arcane_anvil run setblock ~ ~ ~ minecraft:anvil
# Si el bloque ya no esta (pico, explosion, cayo...), devuelve el Yunque del Abismo enseguida.
execute unless block ~ ~ ~ #minecraft:anvil run return run function infectcozy:yunque/roto
# Marca diminuta dentro del bloque: el mod infectcozy_yunque la usa para saber que este yunque es el del Abismo.
execute unless entity @e[type=minecraft:interaction,tag=ic_yq_i,distance=..0.6] run summon minecraft:interaction ~ ~ ~ {Tags:["ic_yq_i","ic_yq_off"],width:0.01f,height:0.01f,response:0b}
execute as @e[type=minecraft:interaction,tag=ic_yq_i,tag=!ic_yq_off,distance=..0.6] run function infectcozy:yunque/desactivar
execute positioned ~ ~0.5 ~ unless entity @e[type=minecraft:item_display,tag=ic_yq_body,distance=..0.6] positioned ~ ~-0.5 ~ run function infectcozy:yunque/displays
