# el bloque desaparecio (explosion, caida...): el yunque vuelve a ser el item especial
execute as @e[type=minecraft:item,distance=..2] if items entity @s contents irons_spellbooks:arcane_anvil run kill @s
execute as @e[type=minecraft:item,distance=..2] if items entity @s contents #minecraft:anvil run kill @s
kill @e[type=minecraft:falling_block,distance=..3]
function infectcozy:yunque/quitar
loot spawn ~ ~0.5 ~ loot infectcozy:yunque/item
