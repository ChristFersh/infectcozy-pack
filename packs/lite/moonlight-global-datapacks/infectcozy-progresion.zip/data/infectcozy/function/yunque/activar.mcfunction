# (como la zona de clic del yunque) tamano completo: el clic derecho encanta
tag @s remove ic_yq_off
data merge entity @s {width:1.02f,height:1.02f}
