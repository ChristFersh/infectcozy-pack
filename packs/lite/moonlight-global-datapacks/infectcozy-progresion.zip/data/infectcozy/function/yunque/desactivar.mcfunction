# (como la zona de clic del yunque) casi sin tamano y dentro del bloque: los clics llegan al bloque
tag @s add ic_yq_off
data merge entity @s {width:0.01f,height:0.01f}
data remove entity @s interaction
data remove entity @s attack
