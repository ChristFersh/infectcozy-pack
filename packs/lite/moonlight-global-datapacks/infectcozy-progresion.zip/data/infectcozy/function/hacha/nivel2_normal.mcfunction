# infectcozy:hacha/nivel2_normal  (como la criatura) Inmovil: velocidad 0 al andar y volar, no salta y no la empujan.
# (Los atributos que no tenga, p. ej. flying_speed en una criatura que no vuela, fallan sin mas.)
attribute @s minecraft:generic.movement_speed modifier add infectcozy:hacha_inmovil -1 add_multiplied_total
attribute @s minecraft:generic.flying_speed modifier add infectcozy:hacha_inmovil -1 add_multiplied_total
attribute @s minecraft:generic.jump_strength modifier add infectcozy:hacha_inmovil -1 add_multiplied_total
attribute @s minecraft:generic.knockback_resistance modifier add infectcozy:hacha_inmovil 1 add_value
