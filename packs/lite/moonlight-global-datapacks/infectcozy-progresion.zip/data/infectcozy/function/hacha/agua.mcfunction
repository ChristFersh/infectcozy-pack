# infectcozy:hacha/agua  (como el hacha, en un punto del recorrido dentro del agua)
# Lanzada (si antes paso por fuera del agua: lanzada desde dentro del agua la atraviesa) o cayendo:
# busca la superficie (hasta 9 bloques arriba), la congela y se clava en el hielo.
execute if score #hh_modo ic_tmp matches 1 unless score @s ic_hh_seco matches 1 run return 0
scoreboard players set #hh_as ic_tmp 0
function infectcozy:hacha/agua_sup
