# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/escarcha_2  (como el marcador del centro de la zona) Escarcha repartida por el suelo, fase 2 de 4.
particle minecraft:dust{color:[0.9,0.98,1.0],scale:1.4} ~2.00 ~0.1 ~3.46 0.7 0.02 0.7 0 3
particle minecraft:snowflake ~2.00 ~0.3 ~3.46 0.6 0.1 0.6 0.005 1
particle minecraft:dust{color:[0.9,0.98,1.0],scale:1.4} ~-2.00 ~0.1 ~3.46 0.7 0.02 0.7 0 3
particle minecraft:dust{color:[0.9,0.98,1.0],scale:1.4} ~1.00 ~0.1 ~-1.73 0.7 0.02 0.7 0 3
particle minecraft:snowflake ~1.00 ~0.3 ~-1.73 0.6 0.1 0.6 0.005 1
particle minecraft:dust{color:[0.9,0.98,1.0],scale:1.4} ~3.00 ~0.1 ~1.73 0.7 0.02 0.7 0 3
particle minecraft:dust{color:[0.9,0.98,1.0],scale:1.4} ~2.00 ~0.1 ~0.00 0.7 0.02 0.7 0 3
particle minecraft:snowflake ~2.00 ~0.3 ~0.00 0.6 0.1 0.6 0.005 1
