# infectcozy:hacha/llegar  (como el hacha junto a su dueno; el dueno tiene ic_hh_d y el hacha ic_hh_yo)
# El display SOLO se borra cuando se ha comprobado que el hacha ya esta en el inventario o en el suelo como item.
execute unless items entity @s contents * run return run kill @s
scoreboard players set #hh_ok ic_tmp 0
scoreboard players set #hh_es ic_tmp 0
execute if items entity @s contents *[minecraft:custom_data~{ic_rompe:1b}] run scoreboard players set #hh_es ic_tmp 1
execute if score #hh_es ic_tmp matches 1 as @a[tag=ic_hh_d,limit=1] at @s run function infectcozy:hacha/entregar
execute if score #hh_es ic_tmp matches 0 as @a[tag=ic_hh_d,limit=1] at @s run function infectcozy:hacha/soltar_pies
execute if score #hh_ok ic_tmp matches 1.. run kill @s
