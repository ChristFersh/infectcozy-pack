# infectcozy:hacha/caida  (estado 5, como el hacha) Cae 1 bloque por tick. Se mira el punto 0.55 por debajo (donde entra el filo).
scoreboard players add @s ic_hh_t 1
execute if score @s ic_hh_t matches 200.. run return run function infectcozy:hacha/volver_iniciar
scoreboard players set #hh_n ic_tmp 0
scoreboard players set #hh_max ic_tmp 4
scoreboard players set #hh_modo ic_tmp 2
scoreboard players set #hh_hit ic_tmp 0
execute rotated ~ 90 positioned ~ ~-0.55 ~ positioned ^ ^ ^0.25 run function infectcozy:hacha/punto
