# infectcozy:hacha/punto  (como el hacha; posicion = siguiente punto del recorrido, rotacion = direccion del recorrido)
# #hh_modo: 1 = vuelo (golpea criaturas y crea zona al clavarse), 2 = caida vertical (ni golpea ni crea zona).
scoreboard players add #hh_n ic_tmp 1
execute unless loaded ~ ~ ~ run return run function infectcozy:hacha/fuera
# 1 = atravesable, 2 = solido, 0 = fuera del mundo ("if block" falla en las dos formas)
scoreboard players set #hh_lib ic_tmp 0
execute if block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_lib ic_tmp 1
execute unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_lib ic_tmp 2
execute if score #hh_lib ic_tmp matches 0 run return run function infectcozy:hacha/fuera
execute if score #hh_lib ic_tmp matches 2 run return run function infectcozy:hacha/bloque
execute if score #hh_modo ic_tmp matches 1 run function infectcozy:hacha/estela
execute if score #hh_modo ic_tmp matches 1 positioned ~-0.5 ~-0.5 ~-0.5 as @e[dx=0,dy=0,dz=0,type=!#infectcozy:arco_ignorar] run function infectcozy:hacha/candidato
execute if score #hh_hit ic_tmp matches 1 run return run function infectcozy:hacha/criatura
# Agua: lanzada (si ya paso por fuera del agua) o cayendo, se clava en la superficie y la congela
execute if score #hh_modo ic_tmp matches 1 unless block ~ ~ ~ minecraft:water run scoreboard players set @s ic_hh_seco 1
scoreboard players set #hh_ag ic_tmp 0
execute if block ~ ~ ~ minecraft:water run function infectcozy:hacha/agua
execute if score #hh_ag ic_tmp matches 1 run return 0
execute if score #hh_n ic_tmp >= #hh_max ic_tmp if score #hh_modo ic_tmp matches 1 run return run tp @s ~ ~ ~ ~ ~
execute if score #hh_n ic_tmp >= #hh_max ic_tmp run return run tp @s ~ ~0.55 ~ ~ 0
execute positioned ^ ^ ^0.25 run function infectcozy:hacha/punto
