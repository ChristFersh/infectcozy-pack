# infectcozy:hacha/hielo_romper  (como una pieza del hielo de la criatura, en su posicion) Cuenta la pieza y la rompe.
scoreboard players add #hh_nh ic_tmp 1
function infectcozy:hacha/fx_romper
