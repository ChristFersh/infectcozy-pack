# infectcozy:hacha/esperar  (como el hacha que vuelve pero su dueno esta desconectado o muerto) Espera flotando.
execute if score #hh_r20 ic_tmp matches 0 run particle minecraft:snowflake ~ ~ ~ 0.2 0.2 0.2 0.01 4
