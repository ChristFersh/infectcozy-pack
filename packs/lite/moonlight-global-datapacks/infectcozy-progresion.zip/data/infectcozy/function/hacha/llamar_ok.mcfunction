# infectcozy:hacha/llamar_ok  (como el jugador que quiere llamar a su hacha) Devuelve 1 si puede.
# Espera de 2 s desde el ultimo lanzamiento: asi mantener Q no lanza y llama el hacha sin parar.
execute unless score @s ic_hh_lt matches 1.. run return 1
execute store result score #hh_ahora ic_tmp run time query gametime
scoreboard players operation #hh_esp ic_tmp = #hh_ahora ic_tmp
scoreboard players operation #hh_esp ic_tmp -= @s ic_hh_lt
execute if score #hh_esp ic_tmp matches 40.. run return 1
execute if score #hh_esp ic_tmp matches ..-1 run return 1
scoreboard players set #hh_rest ic_tmp 59
scoreboard players operation #hh_rest ic_tmp -= #hh_esp ic_tmp
scoreboard players operation #hh_rest ic_tmp /= #hh20 ic_tmp
title @s actionbar [{"text":"El Rompemundos aún no puede volver: ","color":"gray"},{"score":{"name":"#hh_rest","objective":"ic_tmp"},"color":"aqua"},{"text":" s","color":"aqua"}]
return 0
