# infectcozy:hacha/zona_quitar  (como el hacha que deja su bloque) Rompe los cristales y quita el marcador de su zona.
# Las criaturas de dentro pierden los efectos solas en ~1 s (su arriendo deja de renovarse).
scoreboard players operation #hh_u ic_tmp = @s ic_hh_uid
execute as @e[tag=ic_hh_zfx,distance=..16] if score @s ic_hh_uid = #hh_u ic_tmp at @s run function infectcozy:hacha/fx_romper
playsound minecraft:block.glass.break neutral @a ~ ~ ~ 1 1.2
