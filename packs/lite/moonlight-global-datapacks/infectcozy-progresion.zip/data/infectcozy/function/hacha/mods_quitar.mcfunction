# infectcozy:hacha/mods_quitar  (como la criatura) Quita TODOS los modificadores del hacha (los que no tenga fallan sin mas).
attribute @s minecraft:generic.armor modifier remove infectcozy:hacha_hielo
attribute @s minecraft:generic.armor modifier remove infectcozy:hacha_zona
attribute @s minecraft:generic.movement_speed modifier remove infectcozy:hacha_inmovil
attribute @s minecraft:generic.movement_speed modifier remove infectcozy:hacha_lento
attribute @s minecraft:generic.flying_speed modifier remove infectcozy:hacha_inmovil
attribute @s minecraft:generic.flying_speed modifier remove infectcozy:hacha_lento
attribute @s minecraft:generic.jump_strength modifier remove infectcozy:hacha_inmovil
attribute @s minecraft:generic.knockback_resistance modifier remove infectcozy:hacha_inmovil
tag @s remove ic_hh_a30
tag @s remove ic_hh_a30l
tag @s remove ic_hh_a15
