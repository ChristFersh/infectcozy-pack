# infectcozy:hacha/hielo_asignar  (como una pieza de hielo recien invocada)
scoreboard players operation @s ic_hh_mid = #hh_m ic_tmp
scoreboard players set @s ic_hh_l 4
tag @s remove ic_hh_nfx
