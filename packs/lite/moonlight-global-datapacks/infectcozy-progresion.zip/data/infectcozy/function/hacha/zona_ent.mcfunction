# infectcozy:hacha/zona_ent  (como una entidad dentro de la zona) Arriendo de "zona helada" de 25 ticks (se renueva cada 5):
# lentitud II, armadura -15 %, escarcha y temblor mientras este dentro, y ~1 s mas al salir o al irse el hacha.
execute on owner if entity @s[type=minecraft:player] run return 0
execute on passengers if entity @s[type=minecraft:player] run return 0
scoreboard players set #hh_viv ic_tmp 0
execute store success score #hh_viv ic_tmp run attribute @s minecraft:generic.armor base get
execute unless score #hh_viv ic_tmp matches 1 run return 0
scoreboard players set @s ic_hh_t15 25
tag @s add ic_hh_deb
# Estado elegido del hacha (uno solo), cada segundo
execute if score #hh_r20 ic_tmp matches 0 if score #enc_c ic_tmp matches 1.. run function infectcozy:encanto/suelo
