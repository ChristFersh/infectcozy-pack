# infectcozy:hacha/en_criatura  (estado 2, como el hacha montada en la criatura golpeada)
# Mientras siga clavada, la criatura sigue afectada (arriendo ic_hh_t30 renovado cada tick): paralizada los primeros 6 s
# y ralentizada despues, con armadura -30 % todo el tiempo (ver debuff / paralisis_check).
# Si la criatura murio o desaparecio (ya no esta montada o @e no la ve viva), el hacha cae al suelo ahi, sin zona.
scoreboard players set #hh_mont ic_tmp 0
execute on vehicle run tag @s add ic_hh_vv
execute if entity @e[tag=ic_hh_vv,distance=..48,limit=1] run scoreboard players set #hh_mont ic_tmp 1
execute on vehicle run tag @s remove ic_hh_vv
execute if score #hh_mont ic_tmp matches 0 run return run function infectcozy:hacha/caer_iniciar
# Gira con la criatura
execute on vehicle rotated as @s as @e[type=minecraft:item_display,tag=ic_hh_yo,distance=..48,limit=1] run tp @s ~ ~ ~ ~ 0
# Renueva el arriendo de la criatura y, mientras este paralizada, su bloque de hielo (lo sigue y lo rehace si falta)
execute on vehicle at @s run function infectcozy:hacha/hielo_mantener
# Encantamientos de estado del hacha (fuego, plaga, congelacion...): se renuevan cada segundo mientras siga clavada
execute if score #hh_r20 ic_tmp matches 10 run function infectcozy:hacha/encantos
