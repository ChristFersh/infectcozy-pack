# infectcozy:hacha/zfx_asignar  (como un efecto de zona recien invocado: marcador o cristal) Lo liga al hacha (#hh_u).
scoreboard players operation @s ic_hh_uid = #hh_u ic_tmp
scoreboard players set @s ic_hh_l 4
tag @s remove ic_hh_nfx
