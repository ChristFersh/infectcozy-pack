# infectcozy:hacha/temblor_on  (como la criatura) Temblor de congelacion vanilla: TicksFrozen >= 140.
# Baja 2 por tick, asi que 900 dura ~19 s; se refresca cada 15 s (temblor_tick) y se pone a 0 al acabar (temblor_fin).
# Un data merge recarga la entidad entera: por eso se hace pocas veces y nunca en #infectcozy:hacha_sin_temblor.
data merge entity @s {TicksFrozen:900}
tag @s add ic_hh_tf
scoreboard players set @s ic_hh_tfc 0
