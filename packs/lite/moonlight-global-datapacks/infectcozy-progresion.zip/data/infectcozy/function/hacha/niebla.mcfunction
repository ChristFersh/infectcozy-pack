# infectcozy:hacha/niebla  (generado; como el marcador del centro de la zona, en el suelo)
# Niebla de las tumbas de Corail Tombstone: cada tombstone:smoke_cloud es un emisor que suelta niebla blanca
# durante 10 s alrededor de su punto. 9 emisores cubren el radio 5: uno en el centro y 8 a 3.3 bloques.

execute if score #hh_r200 ic_tmp matches 0 run particle tombstone:smoke_cloud ~ ~0.3 ~ 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 22 run particle tombstone:smoke_cloud ~3.3 ~0.3 ~ 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 44 run particle tombstone:smoke_cloud ~2.33 ~0.3 ~2.33 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 66 run particle tombstone:smoke_cloud ~ ~0.3 ~3.3 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 88 run particle tombstone:smoke_cloud ~-2.33 ~0.3 ~2.33 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 110 run particle tombstone:smoke_cloud ~-3.3 ~0.3 ~ 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 132 run particle tombstone:smoke_cloud ~-2.33 ~0.3 ~-2.33 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 154 run particle tombstone:smoke_cloud ~ ~0.3 ~-3.3 0 0 0 0 1
execute if score #hh_r200 ic_tmp matches 176 run particle tombstone:smoke_cloud ~2.33 ~0.3 ~-2.33 0 0 0 0 1
