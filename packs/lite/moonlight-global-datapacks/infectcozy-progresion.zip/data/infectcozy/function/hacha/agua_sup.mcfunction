# (subiendo por el agua) La superficie es el ultimo bloque de agua con algo atravesable encima.
scoreboard players add #hh_as ic_tmp 1
execute if score #hh_as ic_tmp matches 10.. run return 0
execute if block ~ ~1 ~ minecraft:water positioned ~ ~1 ~ run return run function infectcozy:hacha/agua_sup
execute unless block ~ ~1 ~ #infectcozy:laser_pasa run return 0
# Corriente (no es agua quieta): no se congela, la atraviesa
execute unless block ~ ~ ~ minecraft:water[level=0] run return 0
function infectcozy:hacha/agua_clavar
