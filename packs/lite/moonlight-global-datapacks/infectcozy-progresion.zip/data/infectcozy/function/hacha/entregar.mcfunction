# infectcozy:hacha/entregar  (como el dueno, en su posicion) El hacha vuelve al hueco donde esta el item de retorno.
# Orden: mano principal, barra 0-8, inventario 0-26, mano secundaria, cursor; si no hay item de retorno, a la mano
# principal si esta vacia; si no, al suelo a sus pies (solo el puede recogerla).
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"weapon.mainhand"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.0 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.0"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.1 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.1"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.2 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.2"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.3 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.3"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.4 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.4"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.5 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.5"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.6 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.6"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.7 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.7"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s hotbar.8 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"hotbar.8"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.0 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.0"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.1 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.1"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.2 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.2"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.3 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.3"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.4 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.4"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.5 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.5"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.6 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.6"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.7 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.7"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.8 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.8"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.9 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.9"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.10 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.10"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.11 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.11"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.12 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.12"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.13 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.13"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.14 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.14"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.15 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.15"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.16 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.16"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.17 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.17"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.18 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.18"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.19 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.19"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.20 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.20"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.21 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.21"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.22 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.22"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.23 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.23"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.24 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.24"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.25 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.25"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s inventory.26 *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"inventory.26"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s weapon.offhand *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"weapon.offhand"}
execute if score #hh_ok ic_tmp matches 0 if items entity @s player.cursor *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/poner {s:"player.cursor"}
execute if score #hh_ok ic_tmp matches 0 unless items entity @s weapon.mainhand * run function infectcozy:hacha/poner {s:"weapon.mainhand"}
execute if score #hh_ok ic_tmp matches 0 run function infectcozy:hacha/soltar_pies
execute if score #hh_ok ic_tmp matches 1 run playsound minecraft:item.trident.return player @a ~ ~ ~ 1 1.3
execute if score #hh_ok ic_tmp matches 1 run playsound minecraft:item.armor.equip_netherite player @s ~ ~ ~ 0.8 1.2
execute if score #hh_ok ic_tmp matches 1 run particle minecraft:snowflake ~ ~1.2 ~ 0.4 0.4 0.4 0.05 15
