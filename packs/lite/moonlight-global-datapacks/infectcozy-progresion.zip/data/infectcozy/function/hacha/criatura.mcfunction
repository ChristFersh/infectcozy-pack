# infectcozy:hacha/criatura  (como el hacha, en el punto del impacto) Golpe directo: dano, congelacion y el hacha se queda clavada.
tag @e[tag=ic_hh_c,distance=..24,sort=nearest,limit=1] add ic_hh_b
tag @e[tag=ic_hh_c,distance=..24] remove ic_hh_c
tp @s ~ ~ ~ ~ 0
scoreboard players set #hh_vivo ic_tmp 0
scoreboard players set #hh_mnt ic_tmp 0
execute as @e[tag=ic_hh_b,distance=..24,limit=1] at @s run function infectcozy:hacha/golpe
# Impacto (la congelacion y sus efectos van en golpe, solo si sigue viva)
particle minecraft:crit ~ ~ ~ 0.4 0.4 0.4 0.4 15
particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~ ~ 0.4 0.5 0.4 0 20
playsound minecraft:item.trident.hit player @a ~ ~ ~ 1.2 0.7
# golpe monta el display en la criatura si sigue viva (asi la sigue solo). Si murio o no se pudo montar: cae ahi, sin zona
execute if score #hh_mnt ic_tmp matches 0 run return run function infectcozy:hacha/caer_iniciar
scoreboard players set @s ic_hh_est 2
scoreboard players set @s ic_hh_t 0
function infectcozy:hacha/pose_criatura
