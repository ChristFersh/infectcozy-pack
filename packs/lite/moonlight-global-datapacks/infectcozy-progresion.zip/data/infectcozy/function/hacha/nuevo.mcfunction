# infectcozy:hacha/nuevo  (como el item_display recien invocado, en los ojos del lanzador y con su rotacion)
tp @s ~ ~ ~ ~ ~
# Copia exacta del item (todos sus componentes) y comprobacion antes de borrar el item del suelo
item replace entity @s contents from entity @e[type=minecraft:item,tag=ic_hh_it,distance=..8,limit=1] contents
execute unless items entity @s contents *[minecraft:custom_data~{ic_rompe:1b}] run return run kill @s
tag @s add ic_hh
function infectcozy:hacha/uid_nuevo
function infectcozy:hacha/pose_vuelo
scoreboard players operation @s ic_hh_dueno = #hh_d ic_tmp
scoreboard players set @s ic_hh_est 1
scoreboard players set @s ic_hh_t 0
scoreboard players set @s ic_hh_z 0
scoreboard players set @s ic_hh_sup 1
scoreboard players set @s ic_hh_g 0
scoreboard players set @s ic_hh_sin 0
scoreboard players set #hh_ok ic_tmp 1
