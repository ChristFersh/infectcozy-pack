# infectcozy:hacha/fx_barrer  (como un efecto visual del hacha, cada 5 ticks) Sin arriendo renovado durante ~1 s: se borra.
scoreboard players remove @s ic_hh_l 1
execute if score @s ic_hh_l matches ..0 at @s run function infectcozy:hacha/fx_romper
