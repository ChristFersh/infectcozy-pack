# infectcozy:hacha/mid_nuevo  (como la criatura) Id para ligar su bloque de hielo (una sola pieza de hielo aunque tenga varias hachas).
scoreboard players add #sig ic_hh_mid 1
scoreboard players operation @s ic_hh_mid = #sig ic_hh_mid
