# infectcozy:hacha/llamar  (como el jugador) Todas sus hachas cargadas vuelven. Deja en #hh_n cuantas hachas suyas hay.
scoreboard players set #hh_n ic_tmp 0
execute unless score @s ic_id matches 1.. run return 0
scoreboard players operation #hh_llama ic_tmp = @s ic_id
execute as @e[type=minecraft:item_display,tag=ic_hh] if score @s ic_hh_dueno = #hh_llama ic_tmp run function infectcozy:hacha/llamada
execute if score #hh_n ic_tmp matches 1.. run title @s actionbar {"text":"¡Vuelve, Rompemundos!","color":"aqua"}
