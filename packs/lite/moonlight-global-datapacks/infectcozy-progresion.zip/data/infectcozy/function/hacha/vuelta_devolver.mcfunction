# infectcozy:hacha/vuelta_devolver  (como el item de retorno soltado antes de tiempo) Vuelve a la mano, o al inventario.
execute as @a[tag=ic_hh_llama,limit=1] unless items entity @s weapon.mainhand * run tag @s add ic_hh_dev
execute if entity @a[tag=ic_hh_dev] run item replace entity @a[tag=ic_hh_dev,limit=1] weapon.mainhand from entity @s contents
execute unless entity @a[tag=ic_hh_dev] run data merge entity @s {PickupDelay:0s}
execute unless entity @a[tag=ic_hh_dev] run tp @s @a[tag=ic_hh_llama,limit=1]
execute if entity @a[tag=ic_hh_dev] run kill @s
tag @a[tag=ic_hh_dev] remove ic_hh_dev
tag @a[tag=ic_hh_llama] remove ic_hh_llama
