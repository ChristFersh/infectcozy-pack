# infectcozy:hacha/agua_clavar  (como el hacha, en el bloque de agua de la superficie)
scoreboard players set #hh_ag ic_tmp 1
# Hielo al instante en radio 5 y el hacha clavada en el, como en el suelo (el filo entra 0.25)
execute align y positioned ~ ~1 ~ run function infectcozy:hacha/agua_hielo
execute align y positioned ~ ~1 ~ run function infectcozy:hacha/agua_fx
execute align y positioned ~ ~1.55 ~ rotated ~ 0 run tp @s ~ ~ ~ ~ ~
scoreboard players set @s ic_hh_sup 1
function infectcozy:hacha/pose
scoreboard players set @s ic_hh_est 3
scoreboard players set @s ic_hh_t 0
# Su habilidad: si la lanzaste, o si cayo de una criatura que murio
scoreboard players set #hh_zi ic_tmp 0
execute if score #hh_modo ic_tmp matches 1 run scoreboard players set #hh_zi ic_tmp 1
execute if score @s ic_hh_zn matches 1.. run scoreboard players set #hh_zi ic_tmp 1
scoreboard players set @s ic_hh_zn 0
execute if score #hh_zi ic_tmp matches 1 at @s run function infectcozy:hacha/zona_inicio
