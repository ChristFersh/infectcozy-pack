# infectcozy:hacha/caer_iniciar  (como el hacha) La criatura murio o desaparecio, o rompieron el bloque: cae recta y se clava en el suelo.
# De una criatura que murio cae y su habilidad se activa donde aterrice (ic_hh_zn); si se cae de un bloque con zona, la zona se rehace donde aterrice (ic_hh_z sigue a 1).
execute if score @s ic_hh_est matches 2 run scoreboard players set @s ic_hh_zn 1
execute if score @s ic_hh_est matches 2 run function infectcozy:hacha/soltar_criatura
execute if score @s ic_hh_est matches 3 if score @s ic_hh_z matches 1.. at @s run function infectcozy:hacha/zona_quitar
ride @s dismount
scoreboard players set @s ic_hh_est 5
scoreboard players set @s ic_hh_t 0
scoreboard players set @s ic_hh_sup 1
execute at @s run tp @s ~ ~ ~ ~ 0
function infectcozy:hacha/pose
