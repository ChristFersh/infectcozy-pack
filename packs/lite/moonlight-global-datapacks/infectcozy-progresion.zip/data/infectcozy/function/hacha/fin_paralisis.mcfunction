# infectcozy:hacha/fin_paralisis  (como la criatura, en su posicion) Se acaba la paralisis: se rompe el bloque de hielo,
# se quita el temblor y empiezan 4 s (80 ticks) en los que ninguna clavada nueva la vuelve a paralizar.
# Si el hacha sigue clavada, desde este tick queda ralentizada (nivel2l) con la armadura -30 %.
tag @s remove ic_hh_par
scoreboard players reset @s ic_hh_pf
scoreboard players operation @s ic_hh_cd = #hh_now ic_tmp
scoreboard players add @s ic_hh_cd 80
scoreboard players set #hh_m ic_tmp 0
execute if score @s ic_hh_mid matches 1.. run scoreboard players operation #hh_m ic_tmp = @s ic_hh_mid
scoreboard players set #hh_nh ic_tmp 0
execute if score #hh_m ic_tmp matches 1.. as @e[type=minecraft:block_display,tag=ic_hh_hielo,distance=..32] if score @s ic_hh_mid = #hh_m ic_tmp at @s run function infectcozy:hacha/hielo_romper
execute if score #hh_nh ic_tmp matches 1.. run particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~1 ~ 0.5 0.7 0.5 0 40
execute if score #hh_nh ic_tmp matches 1.. run particle minecraft:block{block_state:{Name:"minecraft:packed_ice"}} ~ ~0.6 ~ 0.5 0.4 0.5 0 15
execute if score #hh_nh ic_tmp matches 1.. run particle minecraft:snowflake ~ ~1 ~ 0.5 0.7 0.5 0.1 20
execute if score #hh_nh ic_tmp matches 1.. run playsound minecraft:block.glass.break neutral @a ~ ~ ~ 1.2 0.9
execute if score #hh_nh ic_tmp matches 1.. run playsound minecraft:block.amethyst_cluster.break neutral @a ~ ~ ~ 0.8 1.2
execute if entity @s[tag=ic_hh_tf] run function infectcozy:hacha/temblor_fin
