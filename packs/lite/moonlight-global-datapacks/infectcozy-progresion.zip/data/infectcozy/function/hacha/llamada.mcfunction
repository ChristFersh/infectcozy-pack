# infectcozy:hacha/llamada  (como una de las hachas del jugador que llama)
scoreboard players add #hh_n ic_tmp 1
execute unless score @s ic_hh_est matches 4 run function infectcozy:hacha/volver_iniciar
