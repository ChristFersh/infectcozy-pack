# infectcozy:hacha/nivel2  (como la criatura) Paralizada por un hacha clavada (primeros 6 s): armadura -30 % y sin poder moverse.
# Jefes (#c:bosses): en vez de inmovilizarlos del todo, -60 % de velocidad (andar y volar) para no romper sus ataques.
execute if entity @s[tag=ic_hh_a30] run return 0
function infectcozy:hacha/mods_quitar
attribute @s minecraft:generic.armor modifier add infectcozy:hacha_hielo -0.3 add_multiplied_total
execute if entity @s[type=#c:bosses] run function infectcozy:hacha/nivel2_jefe
execute unless entity @s[type=#c:bosses] run function infectcozy:hacha/nivel2_normal
tag @s add ic_hh_a30
