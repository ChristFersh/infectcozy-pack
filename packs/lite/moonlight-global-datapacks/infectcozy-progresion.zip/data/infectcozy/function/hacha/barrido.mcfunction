# infectcozy:hacha/barrido  (cada segundo) Red de seguridad por si algo se salto la limpieza normal:
# criaturas con tags del hacha pero sin ic_hh_deb vuelven al ciclo normal (que las limpia al no tener arriendo),
# y una muestra aleatoria de 40 criaturas sin ic_hh_deb se revisa por si tuviera modificadores del hacha.
execute as @e[tag=ic_hh_a30,tag=!ic_hh_deb] run tag @s add ic_hh_deb
execute as @e[tag=ic_hh_a15,tag=!ic_hh_deb] run tag @s add ic_hh_deb
execute as @e[tag=ic_hh_a30l,tag=!ic_hh_deb] run tag @s add ic_hh_deb
execute as @e[tag=ic_hh_par,tag=!ic_hh_deb] run tag @s add ic_hh_deb
execute as @e[tag=ic_hh_tf,tag=!ic_hh_deb] run tag @s add ic_hh_deb
execute as @e[type=!#infectcozy:arco_ignorar,tag=!ic_hh_deb,sort=random,limit=40] run function infectcozy:hacha/huerfano_mob
