# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/anillo_c  (como el marcador del centro de la zona, en el suelo) 6 de los 18 puntos del borde (radio 5).
particle minecraft:dust{color:[0.55,0.9,1.0],scale:1.6} ~3.83 ~0.12 ~3.21 0.08 0.04 0.08 0 2
particle minecraft:snowflake ~3.83 ~0.35 ~3.21 0.15 0.15 0.15 0.01 1
particle minecraft:dust{color:[0.55,0.9,1.0],scale:1.6} ~-0.87 ~0.12 ~4.92 0.08 0.04 0.08 0 2
particle minecraft:dust{color:[0.55,0.9,1.0],scale:1.6} ~-4.70 ~0.12 ~1.71 0.08 0.04 0.08 0 2
particle minecraft:dust{color:[0.55,0.9,1.0],scale:1.6} ~-3.83 ~0.12 ~-3.21 0.08 0.04 0.08 0 2
particle minecraft:snowflake ~-3.83 ~0.35 ~-3.21 0.15 0.15 0.15 0.01 1
particle minecraft:dust{color:[0.55,0.9,1.0],scale:1.6} ~0.87 ~0.12 ~-4.92 0.08 0.04 0.08 0 2
particle minecraft:dust{color:[0.55,0.9,1.0],scale:1.6} ~4.70 ~0.12 ~-1.71 0.08 0.04 0.08 0 2
