# infectcozy:hacha/lanzar  (como el jugador que solto el hacha; el item del suelo tiene el tag ic_hh_it)
execute unless score @s ic_id matches 1.. run scoreboard players add #siguiente ic_id 1
execute unless score @s ic_id matches 1.. run scoreboard players operation @s ic_id = #siguiente ic_id
scoreboard players operation #hh_d ic_tmp = @s ic_id
scoreboard players set #hh_ok ic_tmp 0
# El proyectil sale de los ojos con la rotacion de la mirada (nuevo lo verifica y pone #hh_ok = 1)
execute anchored eyes positioned ^ ^ ^ summon minecraft:item_display run function infectcozy:hacha/nuevo
# Si el hacha no llego al display, el item se queda en el suelo tal cual: nunca se pierde
execute if score #hh_ok ic_tmp matches 0 run return fail
kill @e[type=minecraft:item,tag=ic_hh_it,distance=..8,limit=1]
function infectcozy:hacha/dar_retorno
execute store result score @s ic_hh_lt run time query gametime
playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 0.6
playsound minecraft:block.amethyst_block.chime player @a ~ ~ ~ 1 1.6
execute anchored eyes positioned ^ ^ ^1.2 run particle minecraft:snowflake ~ ~ ~ 0.25 0.25 0.25 0.06 14
execute anchored eyes positioned ^ ^ ^1.2 run particle minecraft:dust{color:[0.5,0.9,1.0],scale:1.4} ~ ~ ~ 0.3 0.3 0.3 0 10
execute anchored eyes positioned ^ ^ ^1.2 run particle eeeabsmobs:guardian_spark ~ ~ ~ 0.05 0.05 0.05 0.12 10
execute anchored eyes positioned ^ ^ ^1.2 run particle minecraft:cloud ~ ~ ~ 0.2 0.2 0.2 0.03 10
playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 0.8 0.7
