# infectcozy:hacha/en_bloque  (estado 3, como el hacha) Clavada en un bloque: la zona helada dura mientras siga aqui.
execute if score @s ic_hh_z matches 1.. run function infectcozy:hacha/zona
execute unless score @s ic_hh_z matches 1.. if score #hh_r20 ic_tmp matches 0 run particle minecraft:snowflake ~ ~ ~ 0.2 0.2 0.2 0.01 2
# Nieve que se va acumulando alrededor mientras siga clavada
scoreboard players add @s ic_hh_t 1
execute if score #hh_r5 ic_tmp matches 3 run function infectcozy:hacha/nieve
# Si rompen el bloque donde esta clavada, cae
execute if score #hh_r5 ic_tmp matches 0 run function infectcozy:hacha/ancla
