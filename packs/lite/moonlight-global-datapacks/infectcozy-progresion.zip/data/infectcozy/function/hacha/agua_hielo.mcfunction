# infectcozy:hacha/agua_hielo  (a ras de suelo: la capa de agua de justo debajo y la siguiente)
# Solo el agua quieta (fuentes) se congela, para no tocar corrientes de granjas; en un circulo de radio 5.
# Mientras siga la zona el hielo se renueva cada segundo; despues se derrite solo con la luz del dia.
fill ~-2 ~-2 ~-5 ~2 ~-1 ~-5 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-2 ~-2 ~-5 ~2 ~-1 ~-5 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-3 ~-2 ~-4 ~3 ~-1 ~-4 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-3 ~-2 ~-4 ~3 ~-1 ~-4 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-4 ~-2 ~-3 ~4 ~-1 ~-3 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-4 ~-2 ~-3 ~4 ~-1 ~-3 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-5 ~-2 ~-2 ~5 ~-1 ~-2 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-5 ~-2 ~-2 ~5 ~-1 ~-2 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-5 ~-2 ~-1 ~5 ~-1 ~-1 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-5 ~-2 ~-1 ~5 ~-1 ~-1 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-5 ~-2 ~0 ~5 ~-1 ~0 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-5 ~-2 ~0 ~5 ~-1 ~0 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-5 ~-2 ~1 ~5 ~-1 ~1 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-5 ~-2 ~1 ~5 ~-1 ~1 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-5 ~-2 ~2 ~5 ~-1 ~2 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-5 ~-2 ~2 ~5 ~-1 ~2 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-4 ~-2 ~3 ~4 ~-1 ~3 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-4 ~-2 ~3 ~4 ~-1 ~3 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-3 ~-2 ~4 ~3 ~-1 ~4 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-3 ~-2 ~4 ~3 ~-1 ~4 minecraft:frosted_ice replace minecraft:frosted_ice
fill ~-2 ~-2 ~5 ~2 ~-1 ~5 minecraft:frosted_ice replace minecraft:water[level=0]
fill ~-2 ~-2 ~5 ~2 ~-1 ~5 minecraft:frosted_ice replace minecraft:frosted_ice
