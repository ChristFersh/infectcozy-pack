# infectcozy:hacha/estado  (como el hacha) Un solo estado por tick.
execute if score @s ic_hh_est matches 1 run return run function infectcozy:hacha/vuelo
execute if score @s ic_hh_est matches 2 run return run function infectcozy:hacha/en_criatura
execute if score @s ic_hh_est matches 3 run return run function infectcozy:hacha/en_bloque
execute if score @s ic_hh_est matches 4 run return run function infectcozy:hacha/vuelta
execute if score @s ic_hh_est matches 5 run return run function infectcozy:hacha/caida
# Estado desconocido (no deberia pasar): que vuelva con su dueno
function infectcozy:hacha/volver_iniciar
