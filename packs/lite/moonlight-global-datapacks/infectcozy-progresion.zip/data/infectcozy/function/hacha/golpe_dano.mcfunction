# MACRO (como la criatura golpeada por el Rompemundos): $(d) = 24 + Filo
$execute if entity @a[tag=ic_hh_d,limit=1] store success score #hh_ok ic_tmp run damage @s $(d) minecraft:player_attack by @a[tag=ic_hh_d,limit=1]
$execute unless entity @a[tag=ic_hh_d,limit=1] store success score #hh_ok ic_tmp run damage @s $(d) minecraft:generic
