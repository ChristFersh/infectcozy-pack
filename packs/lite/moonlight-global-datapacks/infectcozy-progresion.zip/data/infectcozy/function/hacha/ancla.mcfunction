# infectcozy:hacha/ancla  (como el hacha clavada) Comprueba que el bloque donde entra el filo sigue siendo solido.
scoreboard players set #hh_lib ic_tmp 0
execute if score @s ic_hh_sup matches 1 positioned ~ ~-0.8 ~ unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_lib ic_tmp 1
execute if score @s ic_hh_sup matches 2 positioned ^ ^ ^0.8 unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_lib ic_tmp 1
execute if score @s ic_hh_sup matches 3 positioned ~ ~0.8 ~ unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_lib ic_tmp 1
execute if score #hh_lib ic_tmp matches 0 run function infectcozy:hacha/caer_iniciar
