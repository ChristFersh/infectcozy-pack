# infectcozy:hacha/zona_suelo  (bajando desde el hacha en pasos de 0.25) Pone el marcador del centro de la zona encima del suelo.
scoreboard players add #hh_b ic_tmp 1
execute unless block ~ ~-0.3 ~ #infectcozy:laser_pasa align y run return run summon minecraft:marker ~ ~ ~ {Tags:["ic_hh_fx","ic_hh_zfx","ic_hh_zc","ic_hh_nfx"]}
execute if score #hh_b ic_tmp matches 22.. run return run summon minecraft:marker ~ ~ ~ {Tags:["ic_hh_fx","ic_hh_zfx","ic_hh_zc","ic_hh_nfx"]}
execute positioned ~ ~-0.25 ~ run function infectcozy:hacha/zona_suelo
