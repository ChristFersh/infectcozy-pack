# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/pose_criatura  (como el display) Clavada en lo alto de una criatura (el display va montado en ella).
data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.887f,0f,0f,0.4617f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,0.4287f,-0.4462f]}}
