# infectcozy:hacha/estela  (en un punto del recorrido del hacha, ida y vuelta)
# Polvo cian y chispas de energia como el rayo del Arco de la Maldicion Eterna (eeeabsmobs:guardian_spark) en cada punto,
# humo blanco en cada punto y, alternando, copos, polvo blanco y nubecitas de humo.
particle minecraft:dust{color:[0.45,0.88,1.0],scale:1.3} ~ ~ ~ 0.05 0.05 0.05 0 1
particle eeeabsmobs:guardian_spark ~ ~ ~ 0.03 0.03 0.03 0 2
particle minecraft:white_smoke ~ ~ ~ 0.06 0.06 0.06 0.01 1
execute if score #hh_n ic_tmp matches 2 run particle minecraft:snowflake ~ ~ ~ 0.1 0.1 0.1 0.01 1
execute if score #hh_n ic_tmp matches 3 run particle minecraft:cloud ~ ~ ~ 0.08 0.08 0.08 0.01 1
execute if score #hh_n ic_tmp matches 4 run particle minecraft:dust{color:[0.95,1.0,1.0],scale:1.0} ~ ~ ~ 0.1 0.1 0.1 0 1
execute if score #hh_n ic_tmp matches 6 run particle minecraft:snowflake ~ ~ ~ 0.1 0.1 0.1 0.01 1
execute if score #hh_n ic_tmp matches 6 run particle minecraft:cloud ~ ~ ~ 0.08 0.08 0.08 0.01 1
