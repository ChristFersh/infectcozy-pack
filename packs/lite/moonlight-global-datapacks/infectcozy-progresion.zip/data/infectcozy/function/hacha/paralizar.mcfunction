# infectcozy:hacha/paralizar  (como la criatura recien golpeada, sin paralisis ni enfriamiento activos; nunca jefes)
# Paralisis de 6 s (120 ticks) desde esta clavada; otra hacha clavada durante ella no la alarga.
tag @s add ic_hh_par
scoreboard players operation @s ic_hh_pf = #hh_now ic_tmp
scoreboard players add @s ic_hh_pf 120
