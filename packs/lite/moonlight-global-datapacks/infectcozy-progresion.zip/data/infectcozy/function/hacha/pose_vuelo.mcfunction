# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/pose_vuelo  (como el display) Pose inicial del lanzamiento (hacha vertical).
data merge entity @s {item_display:"thirdperson_righthand",billboard:"fixed",teleport_duration:1,interpolation_duration:1,view_range:1.5f,shadow_radius:0.0f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,-0.468f,0.1095f]}}
