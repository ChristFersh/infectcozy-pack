# infectcozy:hacha/nivel2l  (como la criatura) Hacha aun clavada pero pasada la paralisis (o en enfriamiento):
# armadura -30 % y ralentizada -40 % al andar y volar; puede saltar y sin resistencia extra al empuje.
execute if entity @s[tag=ic_hh_a30l] run return 0
function infectcozy:hacha/mods_quitar
attribute @s minecraft:generic.armor modifier add infectcozy:hacha_hielo -0.3 add_multiplied_total
attribute @s minecraft:generic.movement_speed modifier add infectcozy:hacha_lento -0.4 add_multiplied_total
attribute @s minecraft:generic.flying_speed modifier add infectcozy:hacha_lento -0.4 add_multiplied_total
tag @s add ic_hh_a30l
