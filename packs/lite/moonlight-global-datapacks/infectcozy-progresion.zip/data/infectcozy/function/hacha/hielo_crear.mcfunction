# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/hielo_crear  (como la criatura congelada, en sus pies; #hh_m = su ic_hh_mid)
# Mide su caja de colision con cubos de 1x1x1 (dx=0): alto en pasos de 0.25 y medio ancho en pasos de 0.125 (tope ~6 bloques).
scoreboard players set #hh_h ic_tmp 0
execute positioned ~-0.5 ~0.25 ~-0.5 run function infectcozy:hacha/medir_alto
scoreboard players set #hh_a ic_tmp 0
execute positioned ~0.125 ~0.1 ~-0.5 run function infectcozy:hacha/medir_ancho
# En centesimas: alto = (h+1)*25 + 5 ; ancho = (a+1)*25 + 10 ; t = -ancho/2 ; c = ancho/2 - 5 (esquinas de las esquirlas)
scoreboard players operation #hh_hc ic_tmp = #hh_h ic_tmp
scoreboard players add #hh_hc ic_tmp 1
scoreboard players operation #hh_hc ic_tmp *= #hh25 ic_tmp
scoreboard players add #hh_hc ic_tmp 5
scoreboard players operation #hh_wc ic_tmp = #hh_a ic_tmp
scoreboard players add #hh_wc ic_tmp 1
scoreboard players operation #hh_wc ic_tmp *= #hh25 ic_tmp
scoreboard players add #hh_wc ic_tmp 10
scoreboard players operation #hh_c ic_tmp = #hh_wc ic_tmp
scoreboard players operation #hh_c ic_tmp /= #hh2 ic_tmp
scoreboard players set #hh_tc ic_tmp 0
scoreboard players operation #hh_tc ic_tmp -= #hh_c ic_tmp
scoreboard players remove #hh_c ic_tmp 5
execute store result storage infectcozy:hacha hielo.w float 0.01 run scoreboard players get #hh_wc ic_tmp
execute store result storage infectcozy:hacha hielo.h float 0.01 run scoreboard players get #hh_hc ic_tmp
execute store result storage infectcozy:hacha hielo.t float 0.01 run scoreboard players get #hh_tc ic_tmp
scoreboard players operation #hh_e0x ic_tmp = #hh_c ic_tmp
scoreboard players remove #hh_e0x ic_tmp 14
execute store result storage infectcozy:hacha hielo.x0 float 0.01 run scoreboard players get #hh_e0x ic_tmp
scoreboard players operation #hh_e0z ic_tmp = #hh_c ic_tmp
scoreboard players remove #hh_e0z ic_tmp 14
execute store result storage infectcozy:hacha hielo.z0 float 0.01 run scoreboard players get #hh_e0z ic_tmp
scoreboard players set #hh_e1x ic_tmp 0
scoreboard players operation #hh_e1x ic_tmp -= #hh_c ic_tmp
scoreboard players remove #hh_e1x ic_tmp 15
execute store result storage infectcozy:hacha hielo.x1 float 0.01 run scoreboard players get #hh_e1x ic_tmp
scoreboard players operation #hh_e1z ic_tmp = #hh_c ic_tmp
scoreboard players remove #hh_e1z ic_tmp 15
execute store result storage infectcozy:hacha hielo.z1 float 0.01 run scoreboard players get #hh_e1z ic_tmp
scoreboard players operation #hh_e2x ic_tmp = #hh_c ic_tmp
scoreboard players remove #hh_e2x ic_tmp 15
execute store result storage infectcozy:hacha hielo.x2 float 0.01 run scoreboard players get #hh_e2x ic_tmp
scoreboard players set #hh_e2z ic_tmp 0
scoreboard players operation #hh_e2z ic_tmp -= #hh_c ic_tmp
scoreboard players remove #hh_e2z ic_tmp 15
execute store result storage infectcozy:hacha hielo.z2 float 0.01 run scoreboard players get #hh_e2z ic_tmp
scoreboard players set #hh_e3x ic_tmp 0
scoreboard players operation #hh_e3x ic_tmp -= #hh_c ic_tmp
scoreboard players remove #hh_e3x ic_tmp 13
execute store result storage infectcozy:hacha hielo.x3 float 0.01 run scoreboard players get #hh_e3x ic_tmp
scoreboard players set #hh_e3z ic_tmp 0
scoreboard players operation #hh_e3z ic_tmp -= #hh_c ic_tmp
scoreboard players remove #hh_e3z ic_tmp 13
execute store result storage infectcozy:hacha hielo.z3 float 0.01 run scoreboard players get #hh_e3z ic_tmp
# Tamano para las particulas de escarcha: 1 pequena (alto <= 1.3), 2 normal, 3 grande (alto >= 2.56)
scoreboard players set @s ic_hh_tam 2
execute if score #hh_hc ic_tmp matches ..130 run scoreboard players set @s ic_hh_tam 1
execute if score #hh_hc ic_tmp matches 256.. run scoreboard players set @s ic_hh_tam 3
function infectcozy:hacha/hielo_summon with storage infectcozy:hacha hielo
execute as @e[type=minecraft:block_display,tag=ic_hh_nfx,distance=..2] run function infectcozy:hacha/hielo_asignar
