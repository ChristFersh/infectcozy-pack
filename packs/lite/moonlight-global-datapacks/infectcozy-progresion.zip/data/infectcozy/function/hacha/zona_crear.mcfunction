# infectcozy:hacha/zona_crear  (como el hacha, en su posicion) Marcador en el suelo bajo el hacha y 12 cristales de hielo alrededor.
scoreboard players operation #hh_u ic_tmp = @s ic_hh_uid
execute as @e[tag=ic_hh_zfx,distance=..16] if score @s ic_hh_uid = #hh_u ic_tmp run kill @s
scoreboard players set #hh_b ic_tmp 0
execute positioned ~ ~0.2 ~ run function infectcozy:hacha/zona_suelo
execute as @e[type=minecraft:marker,tag=ic_hh_nfx,distance=..8] at @s run function infectcozy:hacha/cristales
execute as @e[tag=ic_hh_nfx,distance=..16] run function infectcozy:hacha/zfx_asignar
