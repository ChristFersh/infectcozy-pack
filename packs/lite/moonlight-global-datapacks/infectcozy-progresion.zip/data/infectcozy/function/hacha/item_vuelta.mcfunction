# infectcozy:hacha/item_vuelta  (como un item de retorno en el suelo) El item de retorno nunca existe en el suelo: se borra.
# Si lo solto un jugador (Q), sus hachas vuelven: Q lanza y Q llama.
execute on origin if entity @s[type=minecraft:player] run tag @s add ic_hh_llama
# Recien lanzada: todavia no puede volver; el item de retorno vuelve a tu mano
scoreboard players set #hh_lok ic_tmp 1
execute as @a[tag=ic_hh_llama,limit=1] store result score #hh_lok ic_tmp run function infectcozy:hacha/llamar_ok
execute if entity @a[tag=ic_hh_llama,limit=1] if score #hh_lok ic_tmp matches 0 run return run function infectcozy:hacha/vuelta_devolver
execute as @a[tag=ic_hh_llama,limit=1] at @s run function infectcozy:hacha/llamar
execute if entity @a[tag=ic_hh_llama,limit=1] if score #hh_n ic_tmp matches 0 run title @a[tag=ic_hh_llama,limit=1] actionbar {"text":"No hay ningún Rompemundos tuyo cerca. Si quedó en una zona sin cargar, volverá solo al cargarse.","color":"gray"}
tag @a[tag=ic_hh_llama] remove ic_hh_llama
kill @s
