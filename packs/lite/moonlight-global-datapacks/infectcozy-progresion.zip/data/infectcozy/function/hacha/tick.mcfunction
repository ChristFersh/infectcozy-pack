# infectcozy:hacha/tick
# #hh_now = gametime (para la paralisis de 6 s y el enfriamiento de 4 s de cada criatura)
execute store result score #hh_now ic_tmp run time query gametime
scoreboard players add #hh_reloj ic_tmp 1
execute if score #hh_reloj ic_tmp matches 600000.. run scoreboard players set #hh_reloj ic_tmp 0
scoreboard players operation #hh_r2 ic_tmp = #hh_reloj ic_tmp
scoreboard players operation #hh_r2 ic_tmp %= #hh2 ic_tmp
scoreboard players operation #hh_r3 ic_tmp = #hh_reloj ic_tmp
scoreboard players operation #hh_r3 ic_tmp %= #hh3 ic_tmp
scoreboard players operation #hh_r4 ic_tmp = #hh_reloj ic_tmp
scoreboard players operation #hh_r4 ic_tmp %= #hh4 ic_tmp
scoreboard players operation #hh_r5 ic_tmp = #hh_reloj ic_tmp
scoreboard players operation #hh_r5 ic_tmp %= #hh5 ic_tmp
scoreboard players operation #hh_r20 ic_tmp = #hh_reloj ic_tmp
scoreboard players operation #hh_r20 ic_tmp %= #hh20 ic_tmp
scoreboard players operation #hh_r200 ic_tmp = #hh_reloj ic_tmp
scoreboard players operation #hh_r200 ic_tmp %= #hh200 ic_tmp
# 1) Items recien aparecidos (cada uno se revisa una sola vez): Rompemundos soltado con Q -> se lanza;
#    item de retorno soltado -> se borra y llama a las hachas.
execute as @e[type=minecraft:item,tag=!ic_hh_v] run function infectcozy:hacha/item
# 2) Clic derecho con el item de retorno
execute as @a[scores={ic_hh_uso=1..}] at @s run function infectcozy:hacha/uso
# 3) Hachas lanzadas (renuevan los arriendos de sus criaturas, hielo y zona)
execute as @e[type=minecraft:item_display,tag=ic_hh] at @s run function infectcozy:hacha/hacha
# 4) Criaturas congeladas o dentro de una zona: modificadores, escarcha y temblor; caducan solas
execute as @e[tag=ic_hh_deb] at @s run function infectcozy:hacha/debuff
# 5) Barrido de efectos visuales (cada 5 ticks): lo que nadie renovo se borra
execute if score #hh_r5 ic_tmp matches 2 as @e[tag=ic_hh_fx] run function infectcozy:hacha/fx_barrer
# 6) Barrido de huerfanos: modificadores/tags de criaturas sin arriendo (muestra de 40 cada segundo) y tags temporales
execute if score #hh_r20 ic_tmp matches 7 run function infectcozy:hacha/barrido
execute if score #hh_r200 ic_tmp matches 107 run function infectcozy:hacha/limpiar_tags
