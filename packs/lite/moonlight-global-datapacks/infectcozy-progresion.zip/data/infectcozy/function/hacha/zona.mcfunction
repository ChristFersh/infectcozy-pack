# infectcozy:hacha/zona  (como el hacha clavada con zona, en su posicion) Busca su marcador (centro de la zona, en el suelo)
# y lo hace funcionar; si no existe (recien clavada, lo borraron, se cayo el hacha...), rehace la zona.
scoreboard players operation #hh_u ic_tmp = @s ic_hh_uid
scoreboard players add @s ic_hh_ec 0
scoreboard players add @s ic_hh_el 0
scoreboard players operation #enc_c ic_tmp = @s ic_hh_ec
scoreboard players operation #el ic_tmp = @s ic_hh_el
scoreboard players set #hh_nz ic_tmp 0
execute as @e[type=minecraft:marker,tag=ic_hh_zc,distance=..8] if score @s ic_hh_uid = #hh_u ic_tmp at @s run function infectcozy:hacha/zona_tick
execute if score #hh_nz ic_tmp matches 0 run function infectcozy:hacha/zona_crear
