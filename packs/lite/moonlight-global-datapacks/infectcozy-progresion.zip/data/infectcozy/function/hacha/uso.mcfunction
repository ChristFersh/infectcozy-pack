# infectcozy:hacha/uso  (como un jugador que uso un palo con hongo distorsionado, en su posicion)
scoreboard players reset @s ic_hh_uso
execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{ic_hacha_vuelta:1b}] unless items entity @s weapon.offhand *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run return 0
execute store result score #hh_lok ic_tmp run function infectcozy:hacha/llamar_ok
execute if score #hh_lok ic_tmp matches 0 run return 0
function infectcozy:hacha/llamar
execute if score #hh_n ic_tmp matches 0 run function infectcozy:hacha/huerfano
