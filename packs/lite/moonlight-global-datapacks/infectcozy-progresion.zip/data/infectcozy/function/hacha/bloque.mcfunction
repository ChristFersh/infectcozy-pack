# infectcozy:hacha/bloque  (como el hacha, en el primer punto del recorrido dentro de un bloque solido)
# Vuelve al punto libre anterior y avanza de 0.05 en 0.05 hasta la superficie.
scoreboard players set #hh_f ic_tmp 0
execute positioned ^ ^ ^-0.25 run function infectcozy:hacha/fino
