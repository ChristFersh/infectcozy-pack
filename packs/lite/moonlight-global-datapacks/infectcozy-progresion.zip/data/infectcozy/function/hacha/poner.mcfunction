# infectcozy:hacha/poner  (MACRO, como el dueno)  $(s) = hueco del inventario.
# Copia el hacha del display al hueco y comprueba que de verdad esta ahi antes de dar el OK (#hh_ok = 1).
$item replace entity @s $(s) from entity @e[type=minecraft:item_display,tag=ic_hh_yo,limit=1] contents
$execute if items entity @s $(s) *[minecraft:custom_data~{ic_rompe:1b}] run scoreboard players set #hh_ok ic_tmp 1
