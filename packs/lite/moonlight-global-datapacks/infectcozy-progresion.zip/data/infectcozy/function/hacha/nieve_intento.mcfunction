# (como el hacha) Una columna al azar dentro del circulo de radio #nv_r
execute store result score #nv_x ic_tmp run random value 0..9999
scoreboard players operation #nv_x ic_tmp %= #nv_d ic_tmp
scoreboard players operation #nv_x ic_tmp -= #nv_r ic_tmp
execute store result score #nv_z ic_tmp run random value 0..9999
scoreboard players operation #nv_z ic_tmp %= #nv_d ic_tmp
scoreboard players operation #nv_z ic_tmp -= #nv_r ic_tmp
scoreboard players operation #nv_q ic_tmp = #nv_x ic_tmp
scoreboard players operation #nv_q ic_tmp *= #nv_x ic_tmp
scoreboard players operation #nv_t ic_tmp = #nv_z ic_tmp
scoreboard players operation #nv_t ic_tmp *= #nv_z ic_tmp
scoreboard players operation #nv_q ic_tmp += #nv_t ic_tmp
execute if score #nv_q ic_tmp > #nv_r2 ic_tmp run return 0
scoreboard players set #nv_cap ic_tmp 2
execute if score #nv_q ic_tmp matches ..12 run scoreboard players set #nv_cap ic_tmp 3
execute if score #nv_q ic_tmp matches ..4 run scoreboard players set #nv_cap ic_tmp 4
execute store result storage infectcozy:nieve x int 1 run scoreboard players get #nv_x ic_tmp
execute store result storage infectcozy:nieve z int 1 run scoreboard players get #nv_z ic_tmp
scoreboard players set #nv_b ic_tmp 0
scoreboard players set #nv_a ic_tmp 0
function infectcozy:hacha/nieve_pos with storage infectcozy:nieve
