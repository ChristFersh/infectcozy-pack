# infectcozy:hacha/volver_iniciar  (como el hacha) Empieza a volar hacia su dueno atravesando bloques (tambien si estaba clavada en una criatura).
# Antes suelta lo que tuviera: el hielo de la criatura (si no queda otra hacha en ella) o su zona helada.
execute if score @s ic_hh_est matches 2 run function infectcozy:hacha/soltar_criatura
execute if score @s ic_hh_est matches 3 if score @s ic_hh_z matches 1.. at @s run function infectcozy:hacha/zona_quitar
ride @s dismount
scoreboard players set @s ic_hh_est 4
scoreboard players set @s ic_hh_t 0
scoreboard players set @s ic_hh_z 0
scoreboard players set @s ic_hh_zn 0
scoreboard players set @s ic_hh_sin 0
execute at @s run playsound minecraft:item.trident.return player @a ~ ~ ~ 1 0.8
execute at @s run particle minecraft:snowflake ~ ~ ~ 0.3 0.3 0.3 0.05 12
