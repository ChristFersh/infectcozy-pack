playsound minecraft:block.glass.break player @a ~ ~ ~ 1.2 0.5
playsound minecraft:block.powder_snow.place player @a ~ ~ ~ 1.2 0.5
playsound minecraft:entity.player.hurt_freeze player @a ~ ~ ~ 1 0.6
particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~0.1 ~ 2.5 0.1 2.5 0 80
particle minecraft:snowflake ~ ~0.3 ~ 3 0.2 3 0.05 60
particle minecraft:splash ~ ~0.2 ~ 2 0.1 2 0 60
