# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/giro  (como el display) Un paso del giro en vuelo: 45 grados por tick, interpolado en 1 tick.
scoreboard players add @s ic_hh_g 1
execute if score @s ic_hh_g matches 8.. run scoreboard players set @s ic_hh_g 0
execute if score @s ic_hh_g matches 0 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,-0.468f,0.1095f]}}
execute if score @s ic_hh_g matches 1 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.3827f,0f,0f,0.9239f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,-0.4084f,-0.2535f]}}
execute if score @s ic_hh_g matches 2 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.7071f,0f,0f,0.7071f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,-0.1095f,-0.468f]}}
execute if score @s ic_hh_g matches 3 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.9239f,0f,0f,0.3827f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,0.2535f,-0.4084f]}}
execute if score @s ic_hh_g matches 4 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[1f,0f,0f,0f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,0.468f,-0.1095f]}}
execute if score @s ic_hh_g matches 5 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.9239f,0f,0f,-0.3827f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,0.4084f,0.2535f]}}
execute if score @s ic_hh_g matches 6 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.7071f,0f,0f,-0.7071f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,0.1095f,0.468f]}}
execute if score @s ic_hh_g matches 7 run return run data merge entity @s {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.3827f,0f,0f,-0.9239f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,-0.2535f,0.4084f]}}
