# infectcozy:hacha/nivel2_jefe  (como un jefe) Lentitud fuerte en vez de inmovilizar: -60 % al andar y al volar.
attribute @s minecraft:generic.movement_speed modifier add infectcozy:hacha_inmovil -0.6 add_multiplied_total
attribute @s minecraft:generic.flying_speed modifier add infectcozy:hacha_inmovil -0.6 add_multiplied_total
