# infectcozy:hacha/zona_tick  (como el marcador del centro de la zona, en el suelo; cada tick mientras el hacha siga clavada)
# Si por lo que sea hubiera dos marcadores de la misma hacha, sobra el segundo.
execute if score #hh_nz ic_tmp matches 1.. run return run kill @s
scoreboard players add #hh_nz ic_tmp 1
scoreboard players set @s ic_hh_l 4
# Anillo del borde (radio 5) y suelo escarchado repartido por toda la zona
execute if score #hh_r3 ic_tmp matches 0 run function infectcozy:hacha/anillo_a
execute if score #hh_r3 ic_tmp matches 1 run function infectcozy:hacha/anillo_b
execute if score #hh_r3 ic_tmp matches 2 run function infectcozy:hacha/anillo_c
execute if score #hh_r4 ic_tmp matches 0 run function infectcozy:hacha/escarcha_0
execute if score #hh_r4 ic_tmp matches 1 run function infectcozy:hacha/escarcha_1
execute if score #hh_r4 ic_tmp matches 2 run function infectcozy:hacha/escarcha_2
execute if score #hh_r4 ic_tmp matches 3 run function infectcozy:hacha/escarcha_3
# Niebla blanca de las tumbas (Corail Tombstone) que se mantiene en toda la zona
function infectcozy:hacha/niebla
execute if score #hh_r5 ic_tmp matches 1 run particle minecraft:snowflake ~ ~0.8 ~ 2.4 0.5 2.4 0.01 6
execute if score #hh_r20 ic_tmp matches 4 run particle minecraft:end_rod ~ ~0.5 ~ 2.5 0.2 2.5 0.01 3
execute if score #hh_r20 ic_tmp matches 0 run playsound minecraft:block.powder_snow.step neutral @a ~ ~ ~ 0.5 0.6
# Efectos a las criaturas y arriendo de los cristales, cada 5 ticks
execute if score #hh_r5 ic_tmp matches 0 run function infectcozy:hacha/zona_efecto
# El agua a ras de suelo se congela y sigue helada mientras dure la zona (despues se derrite sola)
execute if score #hh_r20 ic_tmp matches 13 run function infectcozy:hacha/agua_hielo
