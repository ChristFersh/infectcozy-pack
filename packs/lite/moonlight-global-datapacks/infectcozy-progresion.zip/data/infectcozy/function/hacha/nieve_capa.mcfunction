execute if score #nv_cap ic_tmp matches 2.. if block ~ ~ ~ minecraft:snow[layers=1] run return run setblock ~ ~ ~ minecraft:snow[layers=2]
execute if score #nv_cap ic_tmp matches 3.. if block ~ ~ ~ minecraft:snow[layers=2] run return run setblock ~ ~ ~ minecraft:snow[layers=3]
execute if score #nv_cap ic_tmp matches 4.. if block ~ ~ ~ minecraft:snow[layers=3] run return run setblock ~ ~ ~ minecraft:snow[layers=4]
