# infectcozy:hacha/soltar_pies  (como el dueno, en su posicion) No hay hueco: el hacha queda como item a sus pies.
# Solo el dueno puede recogerla (Owner), sin espera (PickupDelay 0), no desaparece (Age -32768), no se destruye
# (Invulnerable) y no cae al vacio (NoGravity). Si la copia falla se borra el item de relleno y el display sigue vivo.
summon minecraft:item ~ ~0.3 ~ {Item:{id:"minecraft:structure_void",count:1},PickupDelay:0s,Age:-32768s,Invulnerable:1b,NoGravity:1b,Motion:[0.0d,0.0d,0.0d],Tags:["ic_hh_v","ic_hh_suelta"]}
data modify entity @e[type=minecraft:item,tag=ic_hh_suelta,distance=..3,limit=1] Owner set from entity @s UUID
item replace entity @e[type=minecraft:item,tag=ic_hh_suelta,distance=..3,limit=1] contents from entity @e[type=minecraft:item_display,tag=ic_hh_yo,limit=1] contents
execute if items entity @e[type=minecraft:item,tag=ic_hh_suelta,distance=..3,limit=1] contents * unless items entity @e[type=minecraft:item,tag=ic_hh_suelta,distance=..3,limit=1] contents minecraft:structure_void run scoreboard players set #hh_ok ic_tmp 2
execute if score #hh_ok ic_tmp matches 0 run kill @e[type=minecraft:item,tag=ic_hh_suelta,distance=..3]
tag @e[type=minecraft:item,tag=ic_hh_suelta,distance=..3] remove ic_hh_suelta
execute if score #hh_ok ic_tmp matches 2 run clear @s minecraft:warped_fungus_on_a_stick[minecraft:custom_data~{ic_hacha_vuelta:1b}] 1
execute if score #hh_ok ic_tmp matches 2 run title @s actionbar {"text":"No había hueco: el Rompemundos quedó a tus pies (solo tú puedes recogerlo).","color":"aqua"}
execute if score #hh_ok ic_tmp matches 2 run playsound minecraft:item.trident.hit_ground player @a ~ ~ ~ 0.8 1.2
