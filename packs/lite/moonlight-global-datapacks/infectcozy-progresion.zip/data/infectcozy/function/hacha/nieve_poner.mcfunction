setblock ~ ~ ~ minecraft:snow
particle minecraft:snowflake ~ ~0.3 ~ 0.3 0.1 0.3 0.01 2
