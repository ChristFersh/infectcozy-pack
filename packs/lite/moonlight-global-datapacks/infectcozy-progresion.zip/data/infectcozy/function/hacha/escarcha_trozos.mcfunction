# infectcozy:hacha/escarcha_trozos  (como la criatura congelada) Trocitos de hielo que se desprenden y caen.
execute if score @s ic_hh_tam matches 3 run return run particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~2.5 ~ 1.2 0.8 1.2 0 6
execute if score @s ic_hh_tam matches 1 run return run particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~0.6 ~ 0.3 0.2 0.3 0 2
particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~1.4 ~ 0.4 0.4 0.4 0 3
particle minecraft:block{block_state:{Name:"minecraft:blue_ice"}} ~ ~1 ~ 0.35 0.5 0.35 0 1
