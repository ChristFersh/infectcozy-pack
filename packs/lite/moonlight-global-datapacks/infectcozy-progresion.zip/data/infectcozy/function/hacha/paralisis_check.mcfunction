# infectcozy:hacha/paralisis_check  (como una criatura paralizada) La paralisis acaba a los 6 s o cuando ya no le queda
# ninguna hacha clavada (arriendo ic_hh_t30 a 0).
execute unless score @s ic_hh_t30 matches 1.. run return run function infectcozy:hacha/fin_paralisis
execute if score #hh_now ic_tmp >= @s ic_hh_pf run function infectcozy:hacha/fin_paralisis
