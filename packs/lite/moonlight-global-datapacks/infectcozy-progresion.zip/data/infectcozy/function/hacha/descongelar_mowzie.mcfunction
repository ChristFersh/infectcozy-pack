# infectcozy:hacha/descongelar_mowzie  (como la criatura que se queda sin hachas clavadas) Le quita tambien el Congelado de
# Mowzie's si aun lo tenia (effect clear avisa al mod, que la suelta bien). En su propio archivo porque depende del mod.
effect clear @s mowziesmobs:frozen
