# infectcozy:hacha/hielo_mantener  (como la criatura con un hacha clavada, en sus pies) Lo llama cada hacha clavada en ella, cada tick.
# Renueva el arriendo de "hacha clavada" (1 s) y, mientras este paralizada, su bloque de hielo: lo lleva a sus pies y, si no existe (recien golpeada,
# cambio de dimension, lo borraron...), lo vuelve a crear midiendo su caja.
scoreboard players set @s ic_hh_t30 20
tag @s add ic_hh_deb
# Pasada la paralisis (6 s) ya no lleva bloque de hielo; los jefes lo llevan mientras siga clavada
execute unless entity @s[tag=ic_hh_par] unless entity @s[type=#c:bosses] run return 0
execute unless score @s ic_hh_mid matches 1.. run function infectcozy:hacha/mid_nuevo
scoreboard players operation #hh_m ic_tmp = @s ic_hh_mid
scoreboard players set #hh_nh ic_tmp 0
execute as @e[type=minecraft:block_display,tag=ic_hh_hielo,distance=..32] if score @s ic_hh_mid = #hh_m ic_tmp run function infectcozy:hacha/hielo_seguir
execute if score #hh_nh ic_tmp matches 0 run function infectcozy:hacha/hielo_nuevo
