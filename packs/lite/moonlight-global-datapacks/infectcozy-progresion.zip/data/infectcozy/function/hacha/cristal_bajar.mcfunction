# infectcozy:hacha/cristal_bajar  (bajando en pasos de 0.25 por un punto libre) Posa el cristal #hh_k encima del primer suelo (max. ~4 bloques).
scoreboard players add #hh_b ic_tmp 1
execute if score #hh_b ic_tmp matches 18.. run return 0
execute unless block ~ ~-0.3 ~ #infectcozy:laser_pasa align y run return run function infectcozy:hacha/cristal_poner
execute positioned ~ ~-0.25 ~ if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
