# infectcozy:hacha/vuelta  (estado 4, como el hacha en su posicion) Vuela hacia los ojos del dueno atravesando bloques.
# Dueno desconectado o muerto: espera flotando.
execute unless score #hh_dv ic_tmp matches 1 run return run function infectcozy:hacha/esperar
scoreboard players add @s ic_hh_t 1
# Dueno en otra dimension, a mas de 160 bloques o 10 s sin alcanzarlo: se entrega directamente
execute unless entity @a[tag=ic_hh_d,distance=..160,limit=1] run return run function infectcozy:hacha/llegar
execute if score @s ic_hh_t matches 200.. run return run function infectcozy:hacha/llegar
scoreboard players set #hh_cerca ic_tmp 0
execute as @a[tag=ic_hh_d,limit=1] at @s anchored eyes positioned ^ ^ ^ if entity @e[type=minecraft:item_display,tag=ic_hh_yo,distance=..1.6,limit=1] run scoreboard players set #hh_cerca ic_tmp 1
execute if score #hh_cerca ic_tmp matches 1 run return run function infectcozy:hacha/llegar
function infectcozy:hacha/giro
scoreboard players set #hh_n ic_tmp 2
function infectcozy:hacha/estela
particle minecraft:block{block_state:{Name:"minecraft:blue_ice"}} ~ ~ ~ 0.2 0.2 0.2 0 2
execute if score #hh_r3 ic_tmp matches 0 run particle minecraft:end_rod ~ ~ ~ 0.15 0.15 0.15 0.01 1
execute if score @s ic_hh_g matches 0 run playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 0.4 1.7
# Velocidad: 1.4 bloques/tick (primeros 15 ticks), 2 (hasta 35) y 3 despues, para alcanzar a quien corre o vuela
scoreboard players set #hh_paso ic_tmp 3
execute if score @s ic_hh_t matches ..15 run scoreboard players set #hh_paso ic_tmp 1
execute if score @s ic_hh_t matches 16..35 run scoreboard players set #hh_paso ic_tmp 2
# Nunca se mete en una zona sin cargar: si el siguiente punto no esta cargado, se entrega directamente
execute if score #hh_paso ic_tmp matches 1 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^1.4 unless loaded ~ ~ ~ run return run function infectcozy:hacha/llegar
execute if score #hh_paso ic_tmp matches 2 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^2 unless loaded ~ ~ ~ run return run function infectcozy:hacha/llegar
execute if score #hh_paso ic_tmp matches 3 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^3 unless loaded ~ ~ ~ run return run function infectcozy:hacha/llegar
function infectcozy:hacha/estela_vuelta
execute if score #hh_paso ic_tmp matches 1 facing entity @a[tag=ic_hh_d,limit=1] eyes run tp @s ^ ^ ^1.4 ~ ~
execute if score #hh_paso ic_tmp matches 2 facing entity @a[tag=ic_hh_d,limit=1] eyes run tp @s ^ ^ ^2 ~ ~
execute if score #hh_paso ic_tmp matches 3 facing entity @a[tag=ic_hh_d,limit=1] eyes run tp @s ^ ^ ^3 ~ ~
scoreboard players set #hh_cerca ic_tmp 0
execute as @a[tag=ic_hh_d,limit=1] at @s anchored eyes positioned ^ ^ ^ if entity @e[type=minecraft:item_display,tag=ic_hh_yo,distance=..1.6,limit=1] run scoreboard players set #hh_cerca ic_tmp 1
execute if score #hh_cerca ic_tmp matches 1 run function infectcozy:hacha/llegar
