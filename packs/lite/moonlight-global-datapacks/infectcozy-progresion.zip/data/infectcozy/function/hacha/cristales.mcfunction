# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/cristales  (como el marcador del centro de la zona) Busca el suelo en cada punto y posa un cristal.
scoreboard players set #hh_k ic_tmp 0
scoreboard players set #hh_b ic_tmp 0
execute positioned ~2.80 ~1.25 ~-0.06 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 1
scoreboard players set #hh_b ic_tmp 0
execute positioned ~2.09 ~1.25 ~2.11 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 2
scoreboard players set #hh_b ic_tmp 0
execute positioned ~-0.12 ~1.25 ~1.50 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 3
scoreboard players set #hh_b ic_tmp 0
execute positioned ~-1.50 ~1.25 ~2.27 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 4
scoreboard players set #hh_b ic_tmp 0
execute positioned ~-3.50 ~1.25 ~0.09 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 5
scoreboard players set #hh_b ic_tmp 0
execute positioned ~-3.00 ~1.25 ~-2.49 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 6
scoreboard players set #hh_b ic_tmp 0
execute positioned ~-0.14 ~1.25 ~-1.57 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 7
scoreboard players set #hh_b ic_tmp 0
execute positioned ~1.12 ~1.25 ~-0.84 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 8
scoreboard players set #hh_b ic_tmp 0
execute positioned ~1.67 ~1.25 ~0.41 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 9
scoreboard players set #hh_b ic_tmp 0
execute positioned ~-0.49 ~1.25 ~0.93 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 10
scoreboard players set #hh_b ic_tmp 0
execute positioned ~-1.36 ~1.25 ~-0.60 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
scoreboard players set #hh_k ic_tmp 11
scoreboard players set #hh_b ic_tmp 0
execute positioned ~0.42 ~1.25 ~-1.10 if block ~ ~ ~ #infectcozy:laser_pasa run function infectcozy:hacha/cristal_bajar
