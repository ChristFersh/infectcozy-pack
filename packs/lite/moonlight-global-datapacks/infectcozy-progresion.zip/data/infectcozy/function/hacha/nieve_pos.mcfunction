$execute positioned ~$(x) ~3 ~$(z) run function infectcozy:hacha/nieve_col
