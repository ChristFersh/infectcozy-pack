# infectcozy:hacha/hacha  (como cada hacha lanzada, en su posicion)
# El dueno (si esta conectado) queda con el tag ic_hh_d y el hacha con ic_hh_yo mientras se procesa.
tag @a[tag=ic_hh_d] remove ic_hh_d
execute unless score @s ic_hh_uid matches 1.. run function infectcozy:hacha/uid_nuevo
scoreboard players operation #hh_d ic_tmp = @s ic_hh_dueno
execute as @a if score @s ic_id = #hh_d ic_tmp run tag @s add ic_hh_d
# #hh_dv = 1 si el dueno esta conectado y vivo (@e no selecciona jugadores muertos)
scoreboard players set #hh_dv ic_tmp 0
execute at @a[tag=ic_hh_d,limit=1] if entity @e[type=minecraft:player,tag=ic_hh_d,distance=..0.5,limit=1] run scoreboard players set #hh_dv ic_tmp 1
tag @s add ic_hh_yo
execute unless score @s ic_hh_est matches 4 run function infectcozy:hacha/vigilar
function infectcozy:hacha/estado
tag @s remove ic_hh_yo
tag @a[tag=ic_hh_d] remove ic_hh_d
