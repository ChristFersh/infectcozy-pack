# infectcozy:hacha/soltar_criatura  (como el hacha que deja una criatura: la llaman o la criatura muere; aun montada)
# Si no queda otra hacha clavada en ella, el hielo se rompe ya y la criatura se descongela en este mismo tick.
tag @s add ic_hh_sale
scoreboard players set #hh_otra ic_tmp 0
execute on vehicle on passengers if entity @s[type=minecraft:item_display,tag=ic_hh,tag=!ic_hh_sale] if score @s ic_hh_est matches 2 run scoreboard players set #hh_otra ic_tmp 1
tag @s remove ic_hh_sale
execute if score #hh_otra ic_tmp matches 0 on vehicle at @s run function infectcozy:hacha/descongelar
