# infectcozy:hacha/debuff  (como una criatura con ic_hh_deb, en su posicion; cada tick)
# Nunca se apilan: hacha clavada (paralizada los primeros 6 s o jefe > ralentizada despues) > zona helada > nada.
scoreboard players remove @s[scores={ic_hh_t30=1..}] ic_hh_t30 1
scoreboard players remove @s[scores={ic_hh_t15=1..}] ic_hh_t15 1
execute if entity @s[tag=ic_hh_par] run function infectcozy:hacha/paralisis_check
execute if score @s ic_hh_t30 matches 1.. if entity @s[type=#c:bosses] run return run function infectcozy:hacha/nivel2_tick
execute if score @s ic_hh_t30 matches 1.. if entity @s[tag=ic_hh_par] run return run function infectcozy:hacha/nivel2_tick
execute if score @s ic_hh_t30 matches 1.. run return run function infectcozy:hacha/nivel2l_tick
execute if score @s ic_hh_t15 matches 1.. run return run function infectcozy:hacha/nivel1_tick
function infectcozy:hacha/nivel0
