# infectcozy:hacha/limpiar_tags  Tags temporales que solo deberian existir dentro de un tick (al cargar y cada 10 s).
tag @a[tag=ic_hh_d] remove ic_hh_d
tag @a[tag=ic_hh_lz] remove ic_hh_lz
tag @a[tag=ic_hh_llama] remove ic_hh_llama
tag @e[tag=ic_hh_c] remove ic_hh_c
tag @e[tag=ic_hh_b] remove ic_hh_b
tag @e[tag=ic_hh_vv] remove ic_hh_vv
tag @e[type=minecraft:item_display,tag=ic_hh_yo] remove ic_hh_yo
tag @e[type=minecraft:item_display,tag=ic_hh_sale] remove ic_hh_sale
tag @e[type=minecraft:item,tag=ic_hh_it] remove ic_hh_it
tag @e[type=minecraft:item,tag=ic_hh_suelta] remove ic_hh_suelta
# Efectos recien invocados que no llegaron a recibir id: se borran
kill @e[tag=ic_hh_nfx]
