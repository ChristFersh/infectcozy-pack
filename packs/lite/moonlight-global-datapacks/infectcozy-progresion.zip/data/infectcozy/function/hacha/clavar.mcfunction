# infectcozy:hacha/clavar  (como el hacha, en el punto libre pegado a la superficie, con la direccion del recorrido)
# Decide si es suelo, pared o techo, coloca el hacha con el filo metido ~0.25 en el bloque y (en vuelo) crea la zona helada.
scoreboard players set #hh_pz ic_tmp 0
scoreboard players set #hh_ab ic_tmp 0
scoreboard players set #hh_ar ic_tmp 0
execute rotated ~ 0 positioned ^ ^ ^0.3 unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_pz ic_tmp 1
execute positioned ~ ~-0.3 ~ unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_ab ic_tmp 1
execute positioned ~ ~0.3 ~ unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_ar ic_tmp 1
scoreboard players set #hh_sup ic_tmp 0
execute if score #hh_modo ic_tmp matches 2 run scoreboard players set #hh_sup ic_tmp 1
execute if score #hh_sup ic_tmp matches 0 if score #hh_ab ic_tmp matches 1 if entity @s[x_rotation=0..90] run scoreboard players set #hh_sup ic_tmp 1
execute if score #hh_sup ic_tmp matches 0 if score #hh_ab ic_tmp matches 1 if score #hh_pz ic_tmp matches 0 run scoreboard players set #hh_sup ic_tmp 1
execute if score #hh_sup ic_tmp matches 0 if score #hh_pz ic_tmp matches 1 run scoreboard players set #hh_sup ic_tmp 2
execute if score #hh_sup ic_tmp matches 0 if score #hh_ar ic_tmp matches 1 run scoreboard players set #hh_sup ic_tmp 3
execute if score #hh_sup ic_tmp matches 0 run scoreboard players set #hh_sup ic_tmp 1
scoreboard players operation @s ic_hh_sup = #hh_sup ic_tmp
execute if score #hh_sup ic_tmp matches 1 positioned ~ ~0.55 ~ rotated ~ 0 run tp @s ~ ~ ~ ~ ~
execute if score #hh_sup ic_tmp matches 2 rotated ~ 0 positioned ^ ^ ^-0.55 run tp @s ~ ~ ~ ~ ~
execute if score #hh_sup ic_tmp matches 3 positioned ~ ~-0.55 ~ rotated ~ 0 run tp @s ~ ~ ~ ~ ~
function infectcozy:hacha/pose
scoreboard players set @s ic_hh_est 3
scoreboard players set @s ic_hh_t 0
execute if score #hh_modo ic_tmp matches 1 at @s run function infectcozy:hacha/zona_inicio
execute if score #hh_modo ic_tmp matches 2 if score @s ic_hh_zn matches 1.. at @s run function infectcozy:hacha/zona_inicio
scoreboard players set @s ic_hh_zn 0
execute if score #hh_modo ic_tmp matches 2 if score #hh_n ic_tmp matches 2.. at @s run playsound minecraft:item.trident.hit_ground player @a ~ ~ ~ 0.8 0.7
