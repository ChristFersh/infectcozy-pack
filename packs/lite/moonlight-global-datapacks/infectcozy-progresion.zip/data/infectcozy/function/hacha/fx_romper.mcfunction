# infectcozy:hacha/fx_romper  (como un efecto visual del hacha, en su posicion) Se rompe y desaparece.
execute if entity @s[type=minecraft:block_display] run particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~0.4 ~ 0.25 0.3 0.25 0 10
kill @s
