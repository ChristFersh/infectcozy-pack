# infectcozy:hacha/candidato  (como una entidad que toca el hacha) Solo cuentan seres vivos que no sean de jugadores.
execute on owner if entity @s[type=minecraft:player] run return 0
execute on passengers if entity @s[type=minecraft:player] run return 0
scoreboard players set #hh_viv ic_tmp 0
execute store success score #hh_viv ic_tmp run attribute @s minecraft:generic.armor base get
execute unless score #hh_viv ic_tmp matches 1 run return 0
tag @s add ic_hh_c
scoreboard players set #hh_hit ic_tmp 1
