# infectcozy:hacha/vigilar  (como el hacha que no esta volviendo)
# Si el dueno esta conectado y vivo pero lleva 1 s sin el item de retorno (lo guardo, murio, lo perdio...), el hacha vuelve sola.
# Dueno desconectado o muerto: el hacha espera donde esta.
execute unless score #hh_dv ic_tmp matches 1 run return run scoreboard players set @s ic_hh_sin 0
execute if items entity @a[tag=ic_hh_d,limit=1] container.* *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run return run scoreboard players set @s ic_hh_sin 0
execute if items entity @a[tag=ic_hh_d,limit=1] weapon.offhand *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run return run scoreboard players set @s ic_hh_sin 0
execute if items entity @a[tag=ic_hh_d,limit=1] player.cursor *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run return run scoreboard players set @s ic_hh_sin 0
scoreboard players add @s ic_hh_sin 1
execute if score @s ic_hh_sin matches 20.. run function infectcozy:hacha/volver_iniciar
