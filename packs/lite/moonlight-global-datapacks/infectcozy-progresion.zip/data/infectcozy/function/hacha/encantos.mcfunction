# infectcozy:hacha/encantos  (como el hacha clavada en una criatura) aplica a la criatura todos sus encantamientos de estado
data modify storage infectcozy:enc e set value {}
data modify storage infectcozy:enc e set from entity @s item.components."minecraft:enchantments".levels
execute on vehicle run function infectcozy:encanto/clavada
