# infectcozy:hacha/zona_inicio  (como el hacha recien clavada en un bloque al lanzarla) Estallido de hielo y zona helada.
scoreboard players set @s ic_hh_z 1
playsound minecraft:block.glass.break player @a ~ ~ ~ 1.5 0.6
playsound minecraft:item.trident.hit_ground player @a ~ ~ ~ 1.2 0.6
playsound minecraft:block.amethyst_cluster.break player @a ~ ~ ~ 1.2 0.5
playsound minecraft:block.powder_snow.place player @a ~ ~ ~ 1.2 0.6
playsound minecraft:entity.player.hurt_freeze player @a ~ ~ ~ 1 0.7
particle minecraft:snowflake ~ ~ ~ 2 0.4 2 0.15 90
particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~ ~ 1.2 0.3 1.2 0 60
particle minecraft:dust{color:[0.6,0.92,1.0],scale:2.0} ~ ~-0.3 ~ 2.5 0.1 2.5 0 50
particle minecraft:cloud ~ ~-0.3 ~ 1.5 0.1 1.5 0.05 20
# Estallido de humo blanco que se abre por toda la zona
particle minecraft:cloud ~ ~ ~ 0.4 0.1 0.4 0.3 70 force
particle minecraft:poof ~ ~ ~ 1.5 0.2 1.5 0.15 50 force
particle minecraft:white_smoke ~ ~ ~ 2.5 0.2 2.5 0.03 60 force
particle minecraft:dust{color:[0.95,0.97,1.0],scale:4.0} ~ ~-0.2 ~ 2.5 0.15 2.5 0 40 force
particle minecraft:explosion ~ ~ ~ 1.2 0.2 1.2 0 5
function infectcozy:hacha/zona_crear
# Solo 1 de sus encantamientos de estado (al azar) se suma al frio de la zona
data modify storage infectcozy:enc e set value {}
data modify storage infectcozy:enc e set from entity @s item.components."minecraft:enchantments".levels
function infectcozy:encanto/elegir
# La niebla arranca ya en toda la zona, desde el marcador del suelo
scoreboard players operation #hh_u ic_tmp = @s ic_hh_uid
execute as @e[type=minecraft:marker,tag=ic_hh_zc,distance=..8] if score @s ic_hh_uid = #hh_u ic_tmp at @s run function infectcozy:hacha/niebla_todo
execute as @e[type=minecraft:marker,tag=ic_hh_zc,distance=..8] if score @s ic_hh_uid = #hh_u ic_tmp at @s run function infectcozy:hacha/agua_hielo
