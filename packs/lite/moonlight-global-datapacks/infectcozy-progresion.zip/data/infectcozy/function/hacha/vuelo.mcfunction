# infectcozy:hacha/vuelo  (estado 1, como el hacha en su posicion) Avanza 1.5 bloques por tick en 6 subpasos de 0.25.
scoreboard players add @s ic_hh_t 1
# Mas de 6 s en el aire (se fue al vacio, etc.): vuelve con su dueno
execute if score @s ic_hh_t matches 120.. run return run function infectcozy:hacha/volver_iniciar
scoreboard players set #hh_n ic_tmp 0
scoreboard players set #hh_max ic_tmp 6
scoreboard players set #hh_modo ic_tmp 1
scoreboard players set #hh_hit ic_tmp 0
function infectcozy:hacha/giro
# Estela criogenica: polvo cian y blanco y copos en cada subpaso (punto -> estela), trocitos de hielo y algun destello
particle minecraft:block{block_state:{Name:"minecraft:blue_ice"}} ~ ~ ~ 0.2 0.2 0.2 0 2
execute if score #hh_r3 ic_tmp matches 0 run particle minecraft:end_rod ~ ~ ~ 0.15 0.15 0.15 0.01 1
execute if score @s ic_hh_g matches 0 run playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 0.5 1.5
# Gravedad (la inclinacion de la trayectoria aumenta): +0.3 grados/tick los primeros 24 bloques, +2 hasta ~40 bloques y +8 despues
execute if entity @s[x_rotation=80..90] rotated ~ 90 positioned ^ ^ ^0.25 run return run function infectcozy:hacha/punto
execute if score @s ic_hh_t matches ..16 rotated ~ ~0.3 positioned ^ ^ ^0.25 run return run function infectcozy:hacha/punto
execute if score @s ic_hh_t matches ..27 rotated ~ ~2 positioned ^ ^ ^0.25 run return run function infectcozy:hacha/punto
execute rotated ~ ~8 positioned ^ ^ ^0.25 run function infectcozy:hacha/punto
