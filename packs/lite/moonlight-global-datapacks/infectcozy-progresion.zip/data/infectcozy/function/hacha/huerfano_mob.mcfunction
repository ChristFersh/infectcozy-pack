# infectcozy:hacha/huerfano_mob  (como una entidad sin ic_hh_deb) Si tiene algun modificador del hacha, se le quitan todos.
scoreboard players set #hh_x ic_tmp 0
execute store success score #hh_x ic_tmp run attribute @s minecraft:generic.armor base get
execute unless score #hh_x ic_tmp matches 1 run return 0
scoreboard players set #hh_x ic_tmp 0
execute store success score #hh_x ic_tmp run attribute @s minecraft:generic.armor modifier value get infectcozy:hacha_hielo
execute if score #hh_x ic_tmp matches 1 run return run function infectcozy:hacha/mods_quitar
execute store success score #hh_x ic_tmp run attribute @s minecraft:generic.armor modifier value get infectcozy:hacha_zona
execute if score #hh_x ic_tmp matches 1 run return run function infectcozy:hacha/mods_quitar
execute store success score #hh_x ic_tmp run attribute @s minecraft:generic.movement_speed modifier value get infectcozy:hacha_inmovil
execute if score #hh_x ic_tmp matches 1 run return run function infectcozy:hacha/mods_quitar
execute store success score #hh_x ic_tmp run attribute @s minecraft:generic.movement_speed modifier value get infectcozy:hacha_lento
execute if score #hh_x ic_tmp matches 1 run return run function infectcozy:hacha/mods_quitar
