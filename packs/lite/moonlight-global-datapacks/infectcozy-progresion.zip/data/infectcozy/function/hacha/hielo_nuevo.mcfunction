# infectcozy:hacha/hielo_nuevo  (como la criatura, en sus pies) Borra restos sueltos de su hielo y lo crea de nuevo.
execute as @e[type=minecraft:block_display,tag=ic_hh_hielo,distance=..32] if score @s ic_hh_mid = #hh_m ic_tmp run kill @s
function infectcozy:hacha/hielo_crear
