# infectcozy:hacha/zona_efecto  (como el marcador del centro de la zona, en el suelo; #hh_u = id del hacha)
execute as @e[type=!#infectcozy:arco_ignorar,distance=..5] run function infectcozy:hacha/zona_ent
execute as @e[type=minecraft:block_display,tag=ic_hh_cristal,distance=..8] if score @s ic_hh_uid = #hh_u ic_tmp run scoreboard players set @s ic_hh_l 4
