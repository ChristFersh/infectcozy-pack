# infectcozy:hacha/item  (como una entidad item que aun no se habia revisado)
tag @s add ic_hh_v
# Filo del Juicio soltado con Q: vuelve a la mano y hace la Embestida (o la Sentencia, agachado)
execute if items entity @s contents *[minecraft:custom_data~{ic_filo:1b}] run return run function infectcozy:filo/soltado
execute if items entity @s contents *[minecraft:custom_data~{ic_rompe:1b}] run return run function infectcozy:hacha/item_hacha
execute if items entity @s contents *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run function infectcozy:hacha/item_vuelta
