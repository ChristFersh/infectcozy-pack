# infectcozy:hacha/item_hacha  (como el item del Rompemundos en el suelo)
# Solo es un lanzamiento si lo solto un jugador (Q o arrastrandolo fuera del inventario): "on origin" da ese jugador.
# Los items que caen al morir no tienen lanzador: se quedan como item normal.
execute on origin if entity @s[type=minecraft:player,gamemode=!spectator] run tag @s add ic_hh_lz
execute unless entity @a[tag=ic_hh_lz,limit=1] run return 0
tag @s add ic_hh_it
execute as @a[tag=ic_hh_lz,limit=1] at @s run function infectcozy:hacha/lanzar
tag @s remove ic_hh_it
tag @a[tag=ic_hh_lz] remove ic_hh_lz
