# infectcozy:hacha/descongelar  (como la criatura que se queda sin hachas clavadas, en su posicion)
# El arriendo baja a 1: el paso de criaturas de este mismo tick le quita modificadores y temblor (si no esta en una zona);
# el Congelado de Mowzie's y el hielo se quitan ya. Si estaba paralizada, al llegar el arriendo a 0 paralisis_check
# cierra la paralisis y arranca los 4 s de enfriamiento.
scoreboard players set @s[scores={ic_hh_t30=2..}] ic_hh_t30 1
function infectcozy:hacha/descongelar_mowzie
scoreboard players set #hh_m ic_tmp 0
execute if score @s ic_hh_mid matches 1.. run scoreboard players operation #hh_m ic_tmp = @s ic_hh_mid
scoreboard players set #hh_nh ic_tmp 0
execute if score #hh_m ic_tmp matches 1.. as @e[type=minecraft:block_display,tag=ic_hh_hielo,distance=..32] if score @s ic_hh_mid = #hh_m ic_tmp at @s run function infectcozy:hacha/hielo_romper
# Rotura del hielo solo si aun lo tenia (paralizada o jefe); si ya estaba solo ralentizada, un poco de escarcha
execute if score #hh_nh ic_tmp matches 1.. run particle minecraft:block{block_state:{Name:"minecraft:ice"}} ~ ~1 ~ 0.5 0.7 0.5 0 40
execute if score #hh_nh ic_tmp matches 1.. run playsound minecraft:block.glass.break neutral @a ~ ~ ~ 1.2 1.1
particle minecraft:snowflake ~ ~1 ~ 0.5 0.7 0.5 0.1 20
