# infectcozy:hacha/load  --  Rompemundos lanzable (mowziesmobs:wrought_axe con custom_data {ic_rompe:1b})
# Q: lanzar. Clic derecho con el item de retorno (o soltarlo con Q): el hacha vuelve.
# Clavada en una criatura: armadura -30 % mientras siga clavada; paralizada (hielo, temblor, no se mueve) solo los
# primeros 6 s de cada clavada y despues ralentizada (-40 %). 4 s de enfriamiento por criatura antes de otra paralisis.
# Clavada en el suelo: zona helada de radio 5 (lentitud II, armadura -15 %) mientras siga ahi.
# Compartidos: ic_tmp (temporales, aqui todos con prefijo #hh_), ic_id / #siguiente ic_id (id de jugador, igual que el arco), ic_robo.
scoreboard objectives add ic_tmp dummy
scoreboard objectives add ic_id dummy
scoreboard objectives add ic_robo dummy
# En cada hacha lanzada (item_display con tag ic_hh; lleva dentro el item real del hacha):
#  ic_hh_dueno : ic_id del jugador que la lanzo
#  ic_hh_uid   : id unico del hacha (sus efectos de zona llevan el mismo)  -- contador en #sig ic_hh_uid
#  ic_hh_est   : 1 volando, 2 clavada en una criatura (montada en ella), 3 clavada en un bloque, 4 volviendo, 5 cayendo
#  ic_hh_t     : ticks del vuelo / vuelta / caida actual
#  ic_hh_z     : 1 = esta hacha tiene zona helada (se clavo en un bloque al lanzarla)
#  ic_hh_sup   : superficie donde esta clavada (1 suelo, 2 pared, 3 techo)
#  ic_hh_g     : paso del giro (0-7)
#  ic_hh_sin   : ticks que lleva el dueno conectado y vivo sin el item de retorno (a los 20 vuelve sola)
scoreboard objectives add ic_hh_dueno dummy
scoreboard objectives add ic_hh_uid dummy
scoreboard objectives add ic_hh_est dummy
scoreboard objectives add ic_hh_t dummy
scoreboard objectives add ic_hh_z dummy
scoreboard objectives add ic_hh_sup dummy
scoreboard objectives add ic_hh_g dummy
scoreboard objectives add ic_hh_sin dummy
#  ic_hh_lt    : gametime del ultimo lanzamiento del jugador (2 s de espera antes de poder llamar el hacha)
scoreboard objectives add ic_hh_lt dummy
#  ic_hh_seco : 1 = en este vuelo ya paso por fuera del agua (al entrar en agua, se clava y la congela)
#  ic_hh_zn   : 1 = cayo de una criatura que murio: su habilidad se activa donde aterrice
scoreboard objectives add ic_hh_seco dummy
scoreboard objectives add ic_hh_zn dummy
# En jugadores: clic derecho con el palo con hongo distorsionado
scoreboard objectives add ic_hh_uso minecraft.used:minecraft.warped_fungus_on_a_stick
# En criaturas afectadas (tag ic_hh_deb). Son "arriendos": el hacha los renueva cada tick/5 ticks y, si nadie los
# renueva (el hacha se fue, desaparecio, se descargo...), caducan solos y se quita todo.
#  ic_hh_t30 : ticks de "hacha clavada" (armadura -30 %; paralizada o ralentizada segun ic_hh_pf; jefes: -60 % velocidad)
#  ic_hh_pf  : gametime en que acaba la paralisis actual (tag ic_hh_par mientras dura; 120 ticks desde la clavada)
#  ic_hh_cd  : gametime hasta el que no se puede volver a paralizar (acaba la paralisis + 80 ticks); no se borra
#  ic_hh_t15 : ticks de "dentro de una zona helada" (armadura -15 %, lentitud II)
#  ic_hh_mid : id de la criatura para su bloque de hielo  -- contador en #sig ic_hh_mid
#  ic_hh_tam : tamano medido (1 pequena, 2 normal, 3 grande) para las particulas
#  ic_hh_tfc : ticks desde el ultimo refresco del temblor de congelacion (TicksFrozen)
# Tags: ic_hh_a30 (paralizada o jefe) / ic_hh_a30l (ralentizada tras la paralisis) / ic_hh_a15 (zona): modificadores puestos;
#       ic_hh_par (paralizada); ic_hh_tf (tiene TicksFrozen puesto por el hacha)
scoreboard objectives add ic_hh_t30 dummy
scoreboard objectives add ic_hh_t15 dummy
scoreboard objectives add ic_hh_mid dummy
scoreboard objectives add ic_hh_tam dummy
scoreboard objectives add ic_hh_tfc dummy
scoreboard objectives add ic_hh_pf dummy
scoreboard objectives add ic_hh_cd dummy
# Efectos visuales con entidades (tag ic_hh_fx): bloques de hielo (ic_hh_hielo, ligados por ic_hh_mid),
# cristales de la zona (ic_hh_cristal) y el marcador del centro de la zona (marker ic_hh_zc), ligados por ic_hh_uid.
#  ic_hh_l : arriendo en "barridos" (cada 5 ticks se resta 1; a 0 se borra). Se renueva a 4 mientras sigan en uso.
scoreboard objectives add ic_hh_l dummy
scoreboard players set #hh2 ic_tmp 2
scoreboard players set #hh3 ic_tmp 3
scoreboard players set #hh4 ic_tmp 4
scoreboard players set #hh5 ic_tmp 5
scoreboard players set #hh20 ic_tmp 20
scoreboard players set #hh25 ic_tmp 25
scoreboard players set #hh200 ic_tmp 200
scoreboard players set #hh80 ic_tmp 80
function infectcozy:hacha/limpiar_tags
