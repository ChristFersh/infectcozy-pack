# infectcozy:hacha/nieve  (como el hacha clavada en un bloque, cada 5 ticks) La nieve se acumula alrededor con el tiempo:
# radio 1 al clavarse y +1 cada 4 s hasta 6; hasta 4 capas junto al hacha, 3 a media distancia y 2 en el borde.
scoreboard players operation #nv_r ic_tmp = @s ic_hh_t
scoreboard players operation #nv_r ic_tmp /= #hh80 ic_tmp
scoreboard players add #nv_r ic_tmp 1
execute if score #nv_r ic_tmp matches 7.. run scoreboard players set #nv_r ic_tmp 6
scoreboard players operation #nv_d ic_tmp = #nv_r ic_tmp
scoreboard players operation #nv_d ic_tmp += #nv_r ic_tmp
scoreboard players add #nv_d ic_tmp 1
scoreboard players operation #nv_r2 ic_tmp = #nv_r ic_tmp
scoreboard players operation #nv_r2 ic_tmp *= #nv_r ic_tmp
scoreboard players operation #nv_r2 ic_tmp += #nv_r ic_tmp
function infectcozy:hacha/nieve_intento
function infectcozy:hacha/nieve_intento
particle minecraft:snowflake ~ ~2 ~ 1.5 0.4 1.5 0.01 2
