# infectcozy:hacha/fuera  (como el hacha) El recorrido sale del mundo o entra en una zona sin cargar: vuelve con su dueno.
function infectcozy:hacha/volver_iniciar
