# infectcozy:hacha/huerfano  (como el jugador) Uso un item de retorno pero no hay ninguna hacha suya cargada: el item sobra.
# Si el hacha estaba en una zona sin cargar, al cargarse vera que su dueno no tiene item de retorno y volvera sola.
scoreboard players set #hh_m ic_tmp 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run scoreboard players set #hh_m ic_tmp 1
execute if score #hh_m ic_tmp matches 1 run item replace entity @s weapon.mainhand with minecraft:air
execute if score #hh_m ic_tmp matches 0 if items entity @s weapon.offhand *[minecraft:custom_data~{ic_hacha_vuelta:1b}] run item replace entity @s weapon.offhand with minecraft:air
title @s actionbar {"text":"No hay ningún Rompemundos tuyo cerca. Si quedó en una zona sin cargar, volverá solo al cargarse.","color":"gray"}
playsound minecraft:block.glass.break player @s ~ ~ ~ 0.4 1.8
