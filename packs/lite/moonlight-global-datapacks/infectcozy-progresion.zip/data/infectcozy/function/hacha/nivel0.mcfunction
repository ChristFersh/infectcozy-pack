# infectcozy:hacha/nivel0  (como la criatura) Ya no tiene hachas clavadas ni esta en ninguna zona: se le quita todo.
# (ic_hh_cd, el enfriamiento de la paralisis, se conserva: es un gametime y caduca solo.)
execute if entity @s[tag=ic_hh_a30] run function infectcozy:hacha/mods_quitar
execute if entity @s[tag=ic_hh_a15] run function infectcozy:hacha/mods_quitar
execute if entity @s[tag=ic_hh_a30l] run function infectcozy:hacha/mods_quitar
# El temblor se quita con un solo data merge (espera si aun tiene el Congelado de Mowzie's, como mucho 4 s)
execute if entity @s[tag=ic_hh_tf] run return run function infectcozy:hacha/temblor_fin
tag @s remove ic_hh_deb
scoreboard players reset @s ic_hh_t30
scoreboard players reset @s ic_hh_t15
scoreboard players reset @s ic_hh_tfc
scoreboard players reset @s ic_hh_tam
scoreboard players reset @s ic_hh_mid
