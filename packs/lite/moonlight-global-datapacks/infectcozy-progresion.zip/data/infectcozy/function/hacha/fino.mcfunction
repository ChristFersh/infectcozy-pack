# infectcozy:hacha/fino  (como el hacha, en un punto libre justo antes del bloque)
scoreboard players add #hh_f ic_tmp 1
scoreboard players set #hh_sig ic_tmp 1
execute positioned ^ ^ ^0.05 unless block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #hh_sig ic_tmp 0
execute if score #hh_sig ic_tmp matches 0 run return run function infectcozy:hacha/clavar
execute if score #hh_f ic_tmp matches 5.. run return run function infectcozy:hacha/clavar
execute positioned ^ ^ ^0.05 run function infectcozy:hacha/fino
