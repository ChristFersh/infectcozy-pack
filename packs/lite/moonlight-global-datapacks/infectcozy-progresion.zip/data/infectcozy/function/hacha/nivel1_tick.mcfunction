# infectcozy:hacha/nivel1_tick  (como la criatura dentro de una zona helada, en su posicion)
function infectcozy:hacha/nivel1
execute unless entity @s[tag=ic_hh_tf] unless entity @s[type=#infectcozy:hacha_sin_temblor] run function infectcozy:hacha/temblor_on
function infectcozy:hacha/temblor_tick
execute if score #hh_r5 ic_tmp matches 3 run particle minecraft:snowflake ~ ~1 ~ 0.3 0.5 0.3 0.01 2
execute if score #hh_r5 ic_tmp matches 3 run particle minecraft:dust{color:[0.9,0.98,1.0],scale:1.0} ~ ~0.6 ~ 0.3 0.4 0.3 0 2
