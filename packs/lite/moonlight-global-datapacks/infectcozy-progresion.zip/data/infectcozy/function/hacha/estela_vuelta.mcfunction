# infectcozy:hacha/estela_vuelta  (como el hacha que vuelve) Rellena la estela entre la posicion actual y la siguiente.
scoreboard players set #hh_n ic_tmp 4
execute if score #hh_paso ic_tmp matches 1 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^0.47 run function infectcozy:hacha/estela
execute if score #hh_paso ic_tmp matches 2 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^0.67 run function infectcozy:hacha/estela
execute if score #hh_paso ic_tmp matches 3 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^1 run function infectcozy:hacha/estela
scoreboard players set #hh_n ic_tmp 6
execute if score #hh_paso ic_tmp matches 1 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^0.93 run function infectcozy:hacha/estela
execute if score #hh_paso ic_tmp matches 2 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^1.33 run function infectcozy:hacha/estela
execute if score #hh_paso ic_tmp matches 3 facing entity @a[tag=ic_hh_d,limit=1] eyes positioned ^ ^ ^2 run function infectcozy:hacha/estela
