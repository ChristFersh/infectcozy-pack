# infectcozy:hacha/hielo_seguir  (como una pieza del hielo de la criatura; posicion = pies de la criatura)
tp @s ~ ~ ~ 0 0
scoreboard players set @s ic_hh_l 4
execute if entity @s[tag=ic_hh_cubo] run scoreboard players add #hh_nh ic_tmp 1
