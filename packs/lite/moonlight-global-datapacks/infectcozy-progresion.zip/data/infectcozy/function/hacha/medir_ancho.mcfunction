# infectcozy:hacha/medir_ancho  (como la criatura; posicion = esquina de un cubo 1x1x1 desplazado 0.125*(#hh_a+1) en X)
# Cuenta cuantos pasos de 0.125 hacia un lado sigue tocando su caja (medio ancho; tope 24 = 3 bloques).
execute unless entity @s[dx=0,dy=0,dz=0] run return 0
scoreboard players add #hh_a ic_tmp 1
execute if score #hh_a ic_tmp matches 24.. run return 0
execute positioned ~0.125 ~ ~ run function infectcozy:hacha/medir_ancho
