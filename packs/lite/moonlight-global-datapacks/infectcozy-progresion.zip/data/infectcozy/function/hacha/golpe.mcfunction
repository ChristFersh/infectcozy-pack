# infectcozy:hacha/golpe  (como la criatura golpeada, en su posicion; el dueno tiene ic_hh_d si esta conectado,
# el hacha tiene ic_hh_yo)
tag @s remove ic_hh_b
# 1) Hacha clavada: arriendo de 1 s que el hacha renueva cada tick (hielo_mantener); armadura -30 % mientras siga.
#    Paralisis de 6 s si no es jefe, no esta ya paralizada y no esta en enfriamiento (4 s tras su ultima paralisis);
#    si no, queda solo ralentizada. Los modificadores van antes del dano: cuenta con la armadura rebajada y no la empuja.
scoreboard players set @s ic_hh_t30 20
tag @s add ic_hh_deb
scoreboard players set #hh_para ic_tmp 0
execute unless entity @s[type=#c:bosses] unless entity @s[tag=ic_hh_par] unless score @s ic_hh_cd > #hh_now ic_tmp run scoreboard players set #hh_para ic_tmp 1
execute if score #hh_para ic_tmp matches 1 run function infectcozy:hacha/paralizar
execute if entity @s[type=#c:bosses] run function infectcozy:hacha/nivel2
execute if entity @s[tag=ic_hh_par] run function infectcozy:hacha/nivel2
execute unless entity @s[type=#c:bosses] unless entity @s[tag=ic_hh_par] run function infectcozy:hacha/nivel2l
# 2) 24 de dano atribuidos al dueno (muerte por jugador: botin, XP y logros de jefes)
scoreboard players set #hh_ok ic_tmp 0
#    (+ bono de Filo, Castigo, Perdicion y Empalamiento del hacha)
scoreboard players set #e_sh ic_tmp 0
scoreboard players set #e_sm ic_tmp 0
scoreboard players set #e_ba ic_tmp 0
scoreboard players set #e_im ic_tmp 0
execute as @e[type=minecraft:item_display,tag=ic_hh_yo,limit=1] run function infectcozy:encanto/niveles_item
function infectcozy:encanto/bono
scoreboard players operation #shd ic_tmp = #bono ic_tmp
scoreboard players add #shd ic_tmp 24
execute store result storage infectcozy:sh d int 1 run scoreboard players get #shd ic_tmp
function infectcozy:hacha/golpe_dano with storage infectcozy:sh
# 3) Robo de vida del set del Ultimo Amanecer (dano x10)
execute if score #hh_ok ic_tmp matches 1 if entity @a[tag=ic_hh_d,limit=1] run scoreboard players set #dano ic_robo 240
execute if score #hh_ok ic_tmp matches 1 as @a[tag=ic_hh_d,limit=1] at @s run function infectcozy:robo/golpe_directo
# 4) Si sigue viva: (paralisis nueva) temblor y Congelado de Mowzie's 4 s; (jefe) Congelado 2 s; bloque de hielo
#    si esta paralizada o es jefe; y el hacha se le queda clavada
scoreboard players set #hh_hp ic_tmp 0
execute store result score #hh_hp ic_tmp run data get entity @s Health 100
execute if score #hh_hp ic_tmp matches ..0 run return 0
scoreboard players set #hh_vivo ic_tmp 1
# (el temblor va antes del Congelado de Mowzie's porque data merge recarga la entidad; lista de excluidas en
#  #infectcozy:hacha_sin_temblor: jefes, inmunes al hielo y criaturas vanilla con "cerebro", que perderian su IA en curso)
execute if score #hh_para ic_tmp matches 1 unless entity @s[tag=ic_hh_tf] unless entity @s[type=#infectcozy:hacha_sin_temblor] run function infectcozy:hacha/temblor_on
execute if score #hh_para ic_tmp matches 1 run function infectcozy:hacha/congelar
execute if entity @s[type=#c:bosses] run function infectcozy:hacha/congelar
function infectcozy:hacha/hielo_mantener
execute if entity @s[type=#c:bosses] run scoreboard players set #hh_para ic_tmp 1
# Congelacion (paralisis nueva o jefe): sonidos y estallido de hielo
execute if score #hh_para ic_tmp matches 1 run playsound minecraft:block.glass.break neutral @a ~ ~ ~ 1.3 0.7
execute if score #hh_para ic_tmp matches 1 run playsound minecraft:entity.player.hurt_freeze neutral @a ~ ~ ~ 1.2 0.8
execute if score #hh_para ic_tmp matches 1 run playsound minecraft:block.powder_snow.place neutral @a ~ ~ ~ 1.2 0.7
execute if score #hh_para ic_tmp matches 1 run playsound minecraft:block.amethyst_cluster.break neutral @a ~ ~ ~ 1 0.6
execute if score #hh_para ic_tmp matches 1 run particle minecraft:snowflake ~ ~1 ~ 0.6 0.8 0.6 0.08 40
execute if score #hh_para ic_tmp matches 1 run particle minecraft:dust{color:[0.92,0.99,1.0],scale:1.8} ~ ~1 ~ 0.5 0.7 0.5 0 25
execute if score #hh_para ic_tmp matches 1 run particle minecraft:block{block_state:{Name:"minecraft:packed_ice"}} ~ ~1 ~ 0.5 0.7 0.5 0 25
execute if score #hh_para ic_tmp matches 1 run particle minecraft:end_rod ~ ~1 ~ 0.5 0.7 0.5 0.05 8
# Sin paralisis (ya paralizada o en enfriamiento): solo escarcha y el golpe helado
execute if score #hh_para ic_tmp matches 0 run playsound minecraft:entity.player.hurt_freeze neutral @a ~ ~ ~ 0.9 1.2
execute if score #hh_para ic_tmp matches 0 run particle minecraft:snowflake ~ ~1 ~ 0.5 0.7 0.5 0.06 15
execute if score #hh_para ic_tmp matches 0 run particle minecraft:dust{color:[0.92,0.99,1.0],scale:1.4} ~ ~1 ~ 0.4 0.6 0.4 0 10
execute store success score #hh_mnt ic_tmp run ride @e[type=minecraft:item_display,tag=ic_hh_yo,limit=1] mount @s
