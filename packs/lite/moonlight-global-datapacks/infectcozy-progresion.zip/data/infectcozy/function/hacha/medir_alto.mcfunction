# infectcozy:hacha/medir_alto  (como la criatura; posicion = esquina de un cubo 1x1x1 a 0.25*(#hh_h+1) sobre sus pies)
# Cuenta cuantos pasos de 0.25 hacia arriba sigue tocando su caja de colision (tope 24 = 6 bloques).
execute unless entity @s[dx=0,dy=0,dz=0] run return 0
scoreboard players add #hh_h ic_tmp 1
execute if score #hh_h ic_tmp matches 24.. run return 0
execute positioned ~ ~0.25 ~ run function infectcozy:hacha/medir_alto
