# infectcozy:hacha/nivel2_tick  (como la criatura paralizada, o un jefe con un hacha clavada, en su posicion)
function infectcozy:hacha/nivel2
# Temblor de congelacion vanilla (no en #infectcozy:hacha_sin_temblor: jefes, inmunes al hielo y criaturas con "cerebro" vanilla)
execute unless entity @s[tag=ic_hh_tf] unless entity @s[type=#infectcozy:hacha_sin_temblor] run function infectcozy:hacha/temblor_on
function infectcozy:hacha/temblor_tick
# Escarcha continua
execute if score #hh_r2 ic_tmp matches 0 run function infectcozy:hacha/escarcha_mob
execute if score #hh_r5 ic_tmp matches 1 run function infectcozy:hacha/escarcha_trozos
execute if score #hh_r20 ic_tmp matches 13 run playsound minecraft:block.powder_snow.step neutral @a ~ ~ ~ 0.45 1.4
