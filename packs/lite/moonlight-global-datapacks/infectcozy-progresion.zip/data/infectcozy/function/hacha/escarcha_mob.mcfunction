# infectcozy:hacha/escarcha_mob  (como la criatura congelada) Escarcha segun su tamano medido (1 pequena, 2 normal, 3 grande).
execute if score @s ic_hh_tam matches 1 run particle minecraft:snowflake ~ ~0.5 ~ 0.3 0.3 0.3 0.01 2
execute if score @s ic_hh_tam matches 1 run particle minecraft:dust{color:[0.92,0.99,1.0],scale:1.1} ~ ~0.4 ~ 0.3 0.3 0.3 0 2
execute if score @s ic_hh_tam matches 3 run particle minecraft:snowflake ~ ~2 ~ 1.2 1.2 1.2 0.01 5
execute if score @s ic_hh_tam matches 3 run particle minecraft:dust{color:[0.92,0.99,1.0],scale:1.6} ~ ~1.8 ~ 1.2 1.2 1.2 0 5
execute unless score @s ic_hh_tam matches 1 unless score @s ic_hh_tam matches 3 run particle minecraft:snowflake ~ ~1 ~ 0.4 0.6 0.4 0.01 3
execute unless score @s ic_hh_tam matches 1 unless score @s ic_hh_tam matches 3 run particle minecraft:dust{color:[0.92,0.99,1.0],scale:1.2} ~ ~0.9 ~ 0.4 0.6 0.4 0 3
