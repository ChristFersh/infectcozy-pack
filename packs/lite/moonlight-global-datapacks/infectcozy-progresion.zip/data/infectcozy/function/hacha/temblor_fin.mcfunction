# infectcozy:hacha/temblor_fin  (como la criatura) Quita el temblor. Depende de Mowzie's (en su propio archivo):
# mientras dure el efecto Congelado de Mowzie's no se recarga la entidad; se reintenta cada tick.
execute if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{effects:{"mowziesmobs:frozen":{}}}} run return 0
data merge entity @s {TicksFrozen:0}
tag @s remove ic_hh_tf
