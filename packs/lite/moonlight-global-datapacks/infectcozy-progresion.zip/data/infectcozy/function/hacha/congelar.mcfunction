# infectcozy:hacha/congelar  (como la criatura) Efecto "Congelado" de Mowzie's Mobs (no hace nada durante 4 s; 2 s los jefes;
# el fuego lo quita antes). Depende de Mowzie's: va en su propio archivo por si el mod faltara. No se reaplica si ya lo tiene.
execute if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{effects:{"mowziesmobs:frozen":{}}}} run return 0
execute if entity @s[type=#c:bosses] run return run effect give @s mowziesmobs:frozen 2 0 true
effect give @s mowziesmobs:frozen 4 0 true
