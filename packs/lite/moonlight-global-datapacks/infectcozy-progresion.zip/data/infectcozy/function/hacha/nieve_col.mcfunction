# (bajando por una columna) En la primera superficie: crece la nieve que haya o pone una capa encima de un bloque que la aguante.
# Si empieza dentro de un bloque (techo de una cueva) sigue bajando; una vez pasado aire, el primer bloque solido la corta.
scoreboard players add #nv_b ic_tmp 1
execute if score #nv_b ic_tmp matches 10.. run return 0
execute if block ~ ~ ~ minecraft:snow run return run function infectcozy:hacha/nieve_capa
execute if block ~ ~ ~ #infectcozy:nieve_cubre unless block ~ ~-1 ~ #infectcozy:laser_pasa unless block ~ ~-1 ~ #infectcozy:nieve_no unless block ~ ~-1 ~ #minecraft:slabs[type=bottom] unless block ~ ~-1 ~ #minecraft:stairs[half=bottom] run return run function infectcozy:hacha/nieve_poner
execute if block ~ ~ ~ #infectcozy:laser_pasa run scoreboard players set #nv_a ic_tmp 1
execute if score #nv_a ic_tmp matches 1 unless block ~ ~ ~ #infectcozy:laser_pasa run return 0
execute positioned ~ ~-1 ~ run function infectcozy:hacha/nieve_col
