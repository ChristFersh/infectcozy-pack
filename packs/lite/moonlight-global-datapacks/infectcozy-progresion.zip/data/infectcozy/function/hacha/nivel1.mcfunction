# infectcozy:hacha/nivel1  (como la criatura) Dentro de una zona helada: armadura -15 % y lentitud II (-30 % de velocidad).
execute if entity @s[tag=ic_hh_a15] run return 0
function infectcozy:hacha/mods_quitar
attribute @s minecraft:generic.armor modifier add infectcozy:hacha_zona -0.15 add_multiplied_total
attribute @s minecraft:generic.movement_speed modifier add infectcozy:hacha_lento -0.3 add_multiplied_total
attribute @s minecraft:generic.flying_speed modifier add infectcozy:hacha_lento -0.3 add_multiplied_total
tag @s add ic_hh_a15
