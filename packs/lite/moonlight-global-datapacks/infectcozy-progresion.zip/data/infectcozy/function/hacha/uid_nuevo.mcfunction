# infectcozy:hacha/uid_nuevo  (como el hacha) Id unico del hacha; sus efectos de zona (marcador y cristales) llevan el mismo.
scoreboard players add #sig ic_hh_uid 1
scoreboard players operation @s ic_hh_uid = #sig ic_hh_uid
