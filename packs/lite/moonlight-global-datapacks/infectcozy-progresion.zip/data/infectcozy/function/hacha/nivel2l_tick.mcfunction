# infectcozy:hacha/nivel2l_tick  (como la criatura ralentizada con un hacha clavada, en su posicion)
function infectcozy:hacha/nivel2l
# Ya descongelada: si el temblor no se pudo quitar al acabar la paralisis (tenia otro Congelado), se reintenta
execute if entity @s[tag=ic_hh_tf] run function infectcozy:hacha/temblor_fin
# Solo algo de escarcha encima, para que se vea que sigue afectada
execute if score #hh_r5 ic_tmp matches 2 run function infectcozy:hacha/escarcha_mob
