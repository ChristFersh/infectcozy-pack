# GENERADO por generar_poses.py (no editar a mano: cambia el .py y vuelve a ejecutarlo)
# infectcozy:hacha/pose  (como el display) Pose de hacha clavada segun @s ic_hh_sup: 1 suelo, 2 pared, 3 techo.
execute if score @s ic_hh_sup matches 1 run return run data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.887f,0f,0f,0.4617f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,0.1787f,-0.4462f]}}
execute if score @s ic_hh_sup matches 2 run return run data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.284f,0f,0f,0.9588f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,-0.4521f,-0.1631f]}}
execute if score @s ic_hh_sup matches 3 run return run data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.4772f,0f,0f,0.8788f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,-0.3467f,-0.3329f]}}
data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.887f,0f,0f,0.4617f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],translation:[0f,0.1787f,-0.4462f]}}
