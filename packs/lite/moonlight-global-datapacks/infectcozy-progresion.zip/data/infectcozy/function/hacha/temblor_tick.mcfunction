# infectcozy:hacha/temblor_tick  (como la criatura con temblor)
execute unless entity @s[tag=ic_hh_tf] run return 0
scoreboard players add @s ic_hh_tfc 1
execute if score @s ic_hh_tfc matches 300.. run function infectcozy:hacha/temblor_on
