# infectcozy:robo/melee  (as + at jugador con ic_robo_dmg > 0)
# Varios golpes en el mismo tick (p. ej. barrido de Better Combat) cuentan como un solo golpe.
scoreboard players operation #t_dmg ic_robo = @s ic_robo_dmg
scoreboard players set @s ic_robo_dmg 0
function infectcozy:robo/aplicar
