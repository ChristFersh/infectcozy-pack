# infectcozy:robo/aec  (MACRO)  $(d) = duracion en ticks x4 (la nube aplica d/4).
# Se invoca a la altura de los ojos del jugador: radio 0.1 y caja 0.2x0.5 dentro de su propio hitbox,
# asi no alcanza a otros jugadores ni a la montura. Age:4 -> aplica en su primer tick (tickCount 5,
# que es multiplo de 5), en este mismo tick de servidor; Duration:6 -> desaparece al tick siguiente.
$summon minecraft:area_effect_cloud ~ ~ ~ {Tags:["ic_robo_aec"],Radius:0.1f,Duration:6,WaitTime:0,Age:4,ReapplicationDelay:100,DurationOnUse:0,RadiusOnUse:0.0f,RadiusPerTick:0.0f,Particle:{type:"minecraft:block",block_state:{Name:"minecraft:air"}},potion_contents:{custom_effects:[{id:"minecraft:regeneration",amplifier:5b,duration:$(d),show_particles:0b,show_icon:0b}]}}
