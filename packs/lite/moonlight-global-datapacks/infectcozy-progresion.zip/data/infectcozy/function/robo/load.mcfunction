# infectcozy:robo/load
# Robo de vida del set completo "Ultimo Amanecer" (custom_data ic_amanecer:1b en las 4 piezas).
# ic_robo        : dummy. Fake players: #dano (entrada del hook del arco, dano x10),
#                  constantes #5 #10 #50 y temporales #t_*.
# ic_robo_dmg    : estadistica vanilla damage_dealt (dano x10 realmente quitado en Player.attack).
# ic_robo_resto  : decimas de curacion sobrantes por jugador (acarreo, siempre 0..9).
# ic_robo_fin    : gametime en el que termina la regeneracion de robo activa del jugador.
scoreboard objectives add ic_robo dummy
scoreboard objectives add ic_robo_dmg minecraft.custom:minecraft.damage_dealt
scoreboard objectives add ic_robo_resto dummy
scoreboard objectives add ic_robo_fin dummy
scoreboard players set #5 ic_robo 5
scoreboard players set #10 ic_robo 10
scoreboard players set #50 ic_robo 50
scoreboard players set #dano ic_robo 0
kill @e[type=minecraft:area_effect_cloud,tag=ic_robo_aec]
