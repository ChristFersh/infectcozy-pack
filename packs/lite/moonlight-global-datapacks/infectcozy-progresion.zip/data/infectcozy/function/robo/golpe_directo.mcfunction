# infectcozy:robo/golpe_directo  --  HOOK para el golpe directo del arco.
# Ejecutar COMO el jugador atacante, despues de poner el dano x10 en #dano ic_robo.
# Ejemplo: scoreboard players set #dano ic_robo 300
#          execute as @a[tag=ic_dueno,limit=1] run function infectcozy:robo/golpe_directo
scoreboard players operation #t_dmg ic_robo = #dano ic_robo
scoreboard players set #dano ic_robo 0
execute if entity @s[type=minecraft:player] at @s run function infectcozy:robo/aplicar
