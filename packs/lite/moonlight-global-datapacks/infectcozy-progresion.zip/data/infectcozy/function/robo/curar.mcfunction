# infectcozy:robo/curar  (as + at jugador). Entrada: #t_cura ic_robo = HP enteros a curar (1..5).
# Regeneracion nivel VI (amplifier 5): 50>>5 = 1 -> cura exactamente 1 HP por tick.
# N HP = N ticks. Si ya hay una regeneracion de robo en curso, se suman los ticks que le quedan.
execute store result score #t_now ic_robo run time query gametime
scoreboard players add @s ic_robo_fin 0
scoreboard players operation #t_tot ic_robo = @s ic_robo_fin
scoreboard players operation #t_tot ic_robo -= #t_now ic_robo
execute unless score #t_tot ic_robo matches 0..100 run scoreboard players set #t_tot ic_robo 0
scoreboard players operation #t_tot ic_robo += #t_cura ic_robo
scoreboard players operation @s ic_robo_fin = #t_now ic_robo
scoreboard players operation @s ic_robo_fin += #t_tot ic_robo
# La nube aplica 1/4 de la duracion: se le pasa ticks * 4.
execute store result storage infectcozy:robo aec.d int 4 run scoreboard players get #t_tot ic_robo
execute anchored eyes positioned ^ ^ ^ run function infectcozy:robo/aec with storage infectcozy:robo aec
# Feedback sutil
particle minecraft:heart ~ ~2.1 ~ 0.2 0.05 0.2 0 1
particle minecraft:dust{color:[0.72,0.04,0.08],scale:0.7} ~ ~1.1 ~ 0.25 0.35 0.25 0 5
playsound minecraft:entity.warden.heartbeat player @s ~ ~ ~ 0.45 1.6
