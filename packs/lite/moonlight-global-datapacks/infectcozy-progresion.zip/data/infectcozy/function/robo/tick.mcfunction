# infectcozy:robo/tick
# Solo trabaja con jugadores que hicieron dano cuerpo a cuerpo desde el tick anterior.
execute as @a[scores={ic_robo_dmg=1..}] at @s run function infectcozy:robo/melee
# Defensa: un valor negativo (no deberia pasar) nunca se reiniciaria.
scoreboard players set @a[scores={ic_robo_dmg=..-1}] ic_robo_dmg 0
