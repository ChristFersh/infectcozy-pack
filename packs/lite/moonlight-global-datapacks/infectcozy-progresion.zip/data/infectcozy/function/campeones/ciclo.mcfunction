# infectcozy:campeones/ciclo  -  cada minuto: la colmena puede coronar a uno de sus hijos cerca de cada jugador.
scoreboard players set #camp_reloj ic_camp 0
execute unless score #camp_on ic_camp matches 1 run return 0
execute unless score !finale proto matches 25.. run return 0
execute store result score #camp_c ic_camp run scoreboard players get !finale proto
# Escala con la corrupcion:  prob = % por jugador y minuto | base = rango minimo | sube = % de subir un rango | max = campeones de la colmena vivos a 64 bloques
scoreboard players set #camp_prob ic_camp 6
scoreboard players set #camp_base ic_camp 1
scoreboard players set #camp_sube ic_camp 30
scoreboard players set #camp_max ic_camp 1
execute if score #camp_c ic_camp matches 70.. run scoreboard players set #camp_prob ic_camp 10
execute if score #camp_c ic_camp matches 70.. run scoreboard players set #camp_base ic_camp 2
execute if score #camp_c ic_camp matches 70.. run scoreboard players set #camp_sube ic_camp 35
execute if score #camp_c ic_camp matches 70.. run scoreboard players set #camp_max ic_camp 2
execute if score #camp_c ic_camp matches 140.. run scoreboard players set #camp_prob ic_camp 14
execute if score #camp_c ic_camp matches 140.. run scoreboard players set #camp_base ic_camp 3
execute if score #camp_c ic_camp matches 210.. run scoreboard players set #camp_prob ic_camp 18
execute if score #camp_c ic_camp matches 210.. run scoreboard players set #camp_base ic_camp 4
execute if score #camp_c ic_camp matches 210.. run scoreboard players set #camp_sube ic_camp 15
execute if score #camp_c ic_camp matches 210.. run scoreboard players set #camp_max ic_camp 3
# Solo de noche (desde 140 de corrupcion, a cualquier hora)
execute store result score #camp_hora ic_camp run time query daytime
scoreboard players set #camp_ok ic_camp 0
execute if score #camp_hora ic_camp matches 13000..23000 run scoreboard players set #camp_ok ic_camp 1
execute if score #camp_c ic_camp matches 140.. run scoreboard players set #camp_ok ic_camp 1
execute if score #camp_ok ic_camp matches 0 run return 0
execute as @a[gamemode=!creative,gamemode=!spectator] at @s if dimension minecraft:overworld run function infectcozy:campeones/jugador
