# infectcozy:campeones/load  -  Campeones de la colmena
scoreboard objectives add ic_camp dummy
scoreboard objectives add ic_tmp dummy
scoreboard objectives add proto dummy
# Interruptor para admins: scoreboard players set #camp_on ic_camp 0  (apagar) / 1 (encender)
execute unless score #camp_on ic_camp matches 0..1 run scoreboard players set #camp_on ic_camp 1
scoreboard players add #camp_reloj ic_camp 0
