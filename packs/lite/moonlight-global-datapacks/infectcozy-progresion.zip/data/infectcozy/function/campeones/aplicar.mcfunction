# infectcozy:campeones/aplicar  (como el mob)  -  usa el comando del mod Champions
execute if score #camp_rank ic_camp matches ..1 run champions apply @s 1
execute if score #camp_rank ic_camp matches 2 run champions apply @s 2
execute if score #camp_rank ic_camp matches 3 run champions apply @s 3
execute if score #camp_rank ic_camp matches 4 run champions apply @s 4
execute if score #camp_rank ic_camp matches 5.. run champions apply @s 5
