# Un ciclo por minuto de juego
scoreboard players add #camp_reloj ic_camp 1
execute if score #camp_reloj ic_camp matches 1200.. run function infectcozy:campeones/ciclo
