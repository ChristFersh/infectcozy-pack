# infectcozy:campeones/jugador  (como y en el jugador)
execute store result score #camp_n ic_camp if entity @e[tag=ic_camp,distance=..64]
execute if score #camp_n ic_camp >= #camp_max ic_camp run return 0
execute store result score #camp_r ic_camp run random value 1..100
execute if score #camp_r ic_camp > #camp_prob ic_camp run return 0
execute as @e[type=#infectcozy:campeon_colmena,distance=10..40,tag=!ic_camp_x,sort=random,limit=1] at @s run function infectcozy:campeones/elegir
