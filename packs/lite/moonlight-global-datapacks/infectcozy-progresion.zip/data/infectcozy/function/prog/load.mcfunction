scoreboard objectives add ic_jefes dummy {"text":"Jefes derrotados","color":"gold"}
