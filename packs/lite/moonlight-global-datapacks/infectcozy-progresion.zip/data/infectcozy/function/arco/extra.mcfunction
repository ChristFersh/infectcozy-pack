# MACRO (como el blanco): dano extra del arco = Poder x3 + bono de Castigo/Perdicion/Empalamiento.
# Tipo flecha: cuenta armadura y Proteccion contra proyectiles. Va ANTES de los 20 de dano verdadero.
$damage @s $(d) minecraft:arrow by @a[tag=ic_dueno,limit=1]
