particle eeeabsmobs:guardian_spark ~ ~ ~ 0.03 0.03 0.03 0 2 force
