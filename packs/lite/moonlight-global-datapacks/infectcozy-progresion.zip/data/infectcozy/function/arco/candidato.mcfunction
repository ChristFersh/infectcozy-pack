# Se ejecuta como cada entidad cercana al rayo. Solo cuenta si esta viva (Health > 0) y no es mascota de un jugador.
execute on owner if entity @s[type=minecraft:player] run return 0
scoreboard players set #hp ic_tmp 0
execute store result score #hp ic_tmp run data get entity @s Health 100
execute unless score #hp ic_tmp matches 1.. run return 0
tag @s add ic_blanco_c
scoreboard players set #hit ic_tmp 1
