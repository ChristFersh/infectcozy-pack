# Respaldo si infectcozy:rayo_energia no existe: minecraft:sonic_boom tambien ignora armadura y encantamientos de proteccion.
scoreboard players set #ok ic_tmp 0
execute store success score #ok ic_tmp run damage @s 20 minecraft:sonic_boom by @a[tag=ic_dueno,limit=1]
