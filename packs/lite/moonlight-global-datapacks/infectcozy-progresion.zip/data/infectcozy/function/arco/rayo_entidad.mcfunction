# El rayo toco un ser vivo. Contexto: como el tirador, en el punto del rayo.
summon minecraft:marker ~ ~ ~ {Tags:["ic_rayo_fin"]}
tag @e[tag=ic_blanco_c,distance=..32,sort=nearest,limit=1] add ic_blanco
tag @e[tag=ic_blanco_c,distance=..32] remove ic_blanco_c
execute as @e[tag=ic_blanco,distance=..32,limit=1] at @s run function infectcozy:arco/golpe
tag @e[tag=ic_blanco,distance=..32] remove ic_blanco
