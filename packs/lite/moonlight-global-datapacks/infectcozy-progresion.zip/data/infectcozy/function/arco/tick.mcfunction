scoreboard players remove @a[scores={ic_arco_cd=1..}] ic_arco_cd 1
execute as @a[scores={ic_arco_uso=1..}] at @s run function infectcozy:arco/uso
execute as @e[type=minecraft:marker,tag=ic_fuego] at @s run function infectcozy:arco/fuego
scoreboard players add #limpieza ic_tmp 1
execute if score #limpieza ic_tmp matches 100.. run function infectcozy:arco/limpiar
