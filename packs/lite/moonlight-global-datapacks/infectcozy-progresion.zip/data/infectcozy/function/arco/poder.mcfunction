# infectcozy:arco/poder  (como el blanco) Poder I-V: +3 de dano por nivel (tipo flecha: cuenta armadura y Proteccion contra proyectiles).
# Va ANTES de los 20 de dano verdadero, que ignoran la invulnerabilidad de este golpe.
execute if score #pw ic_tmp matches 1 run damage @s 3 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 2 run damage @s 6 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 3 run damage @s 9 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 4 run damage @s 12 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 5 run damage @s 15 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 6 run damage @s 18 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 7 run damage @s 21 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 8 run damage @s 24 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 9 run damage @s 27 minecraft:arrow by @a[tag=ic_dueno,limit=1]
execute if score #pw ic_tmp matches 10.. run damage @s 30 minecraft:arrow by @a[tag=ic_dueno,limit=1]
