particle eeeabsmobs:guardian_spark ~ ~ ~ 0.05 0.05 0.05 0.12 8 force
