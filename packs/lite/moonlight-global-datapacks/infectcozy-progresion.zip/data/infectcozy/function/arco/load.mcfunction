scoreboard objectives add ic_arco_uso minecraft.used:cataclysm.wrath_of_the_desert
scoreboard objectives add ic_arco_vida dummy
scoreboard objectives add ic_arco_cd dummy
scoreboard objectives add ic_id dummy
scoreboard objectives add ic_tmp dummy
scoreboard objectives add ic_robo dummy
scoreboard players set #4 ic_tmp 4
function infectcozy:arco/limpiar
kill @e[type=minecraft:marker,tag=ic_v0]
kill @e[type=minecraft:marker,tag=ic_v1]
