tag @s add ic_disparando
execute as @e[type=cataclysm:cursed_sandstorm,distance=..8] if function infectcozy:arco/tormenta_mia run kill @s
tag @s remove ic_disparando
