# Boca del arco. Contexto: como el tirador, en la mano que sostiene el arco.
particle minecraft:electric_spark ~ ~ ~ 0.08 0.08 0.08 0.15 10 force
function infectcozy:arco/fx_boca
execute facing entity @e[type=minecraft:marker,tag=ic_rayo_fin,distance=..96,limit=1] feet run function infectcozy:arco/haz_paso
