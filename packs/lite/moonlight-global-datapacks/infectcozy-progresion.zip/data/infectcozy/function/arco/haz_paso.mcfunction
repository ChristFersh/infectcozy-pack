# Dibuja el haz visible (pasos de 0.25) desde la boca hasta la marca ic_rayo_fin.
scoreboard players add #dib ic_tmp 1
function infectcozy:arco/fx_haz
particle minecraft:electric_spark ~ ~ ~ 0 0 0 0 1 force
execute if score #dib ic_tmp matches 3.. run particle minecraft:dust{color:[0.3,0.85,1.0],scale:1.6} ~ ~ ~ 0.02 0.02 0.02 0 1 force
scoreboard players operation #par ic_tmp = #dib ic_tmp
scoreboard players operation #par ic_tmp %= #4 ic_tmp
execute if score #par ic_tmp matches 0 run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force
execute if entity @e[type=minecraft:marker,tag=ic_rayo_fin,distance=..0.3] run return 0
execute if score #dib ic_tmp matches 340.. run return 0
execute positioned ^ ^ ^0.25 run function infectcozy:arco/haz_paso
