scoreboard players operation #dueno ic_tmp = @s ic_id
execute as @a if score @s ic_id = #dueno ic_tmp run tag @s add ic_dueno
