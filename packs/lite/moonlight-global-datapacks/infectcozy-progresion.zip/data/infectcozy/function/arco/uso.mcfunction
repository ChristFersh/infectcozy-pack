scoreboard players reset @s ic_arco_uso
execute unless items entity @s weapon.mainhand *[custom_data~{ic_arco:1b}] unless items entity @s weapon.offhand *[custom_data~{ic_arco:1b}] run return fail
function infectcozy:arco/quitar_tormentas
execute if score @s ic_arco_cd matches 1.. run return run playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.6 1.8
scoreboard players set @s ic_arco_cd 20
function infectcozy:arco/disparar
