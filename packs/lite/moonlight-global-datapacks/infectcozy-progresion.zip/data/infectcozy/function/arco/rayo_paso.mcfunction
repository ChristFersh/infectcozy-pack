# Un paso del rayo. Contexto: como el tirador, en el punto actual del rayo, con la rotacion de su mirada.
scoreboard players add #pasos ic_tmp 1
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ #infectcozy:laser_pasa positioned ^ ^ ^-0.2 run return run function infectcozy:arco/suelo
execute positioned ~-0.5 ~-0.5 ~-0.5 as @e[dx=0,dy=0,dz=0,type=!#infectcozy:arco_ignorar,tag=!ic_disparando] run function infectcozy:arco/candidato
execute if score #hit ic_tmp matches 1.. run return run function infectcozy:arco/rayo_entidad
execute if score #pasos ic_tmp matches 320.. run return run function infectcozy:arco/rayo_fin
execute positioned ^ ^ ^0.25 run function infectcozy:arco/rayo_paso
