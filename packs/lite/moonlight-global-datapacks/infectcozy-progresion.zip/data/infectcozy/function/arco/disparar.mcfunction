# Disparo instantaneo (hitscan). Contexto: como el tirador, en su posicion y con su rotacion.
execute unless score @s ic_id matches 1.. run scoreboard players add #siguiente ic_id 1
execute unless score @s ic_id matches 1.. run scoreboard players operation @s ic_id = #siguiente ic_id
function infectcozy:arco/dueno
tag @s add ic_disparando
execute on vehicle run tag @s add ic_disparando
kill @e[type=minecraft:marker,tag=ic_rayo_fin,distance=..96]
scoreboard players set #pasos ic_tmp 0
scoreboard players set #hit ic_tmp 0
scoreboard players set #dib ic_tmp 0
scoreboard players set #4 ic_tmp 4
# 1) Rayo invisible desde los ojos (pasos de 0.25, max 80 bloques). Termina en suelo, rayo_entidad o rayo_fin (los tres dejan la marca ic_rayo_fin).
execute anchored eyes positioned ^ ^ ^0.25 anchored feet run function infectcozy:arco/rayo_paso
# 2) Haz visible desde la mano que sostiene el arco hasta el punto de impacto.
execute if items entity @s weapon.mainhand *[custom_data~{ic_arco:1b}] anchored eyes positioned ^-0.3 ^-0.2 ^0.6 anchored feet run function infectcozy:arco/boca
execute unless items entity @s weapon.mainhand *[custom_data~{ic_arco:1b}] anchored eyes positioned ^0.3 ^-0.2 ^0.6 anchored feet run function infectcozy:arco/boca
kill @e[type=minecraft:marker,tag=ic_rayo_fin,distance=..96]
execute anchored eyes positioned ^ ^ ^1.2 run particle minecraft:flash ~ ~ ~ 0 0 0 0 1 force @a[tag=!ic_disparando]
playsound eeeabsmobs:entity.relic_annihilator.shoot_laser player @a ~ ~ ~ 1.5 1.2
playsound minecraft:entity.illusioner.cast_spell player @a ~ ~ ~ 0.5 1.8
execute on vehicle run tag @s remove ic_disparando
tag @s remove ic_disparando
tag @a[tag=ic_dueno] remove ic_dueno
