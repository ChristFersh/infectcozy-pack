# Limpieza periodica (cada 100 ticks y al cargar): restos del sistema viejo de flechas y marcas perdidas.
scoreboard players set #limpieza ic_tmp 0
kill @e[type=minecraft:item_display,tag=ic_arco_m]
kill @e[type=minecraft:arrow,tag=ic_energia]
kill @e[type=minecraft:marker,tag=ic_rayo_fin]
tag @e[tag=ic_blanco_c] remove ic_blanco_c
tag @e[tag=ic_blanco] remove ic_blanco
tag @e[tag=ic_disparando] remove ic_disparando
tag @a[tag=ic_dueno] remove ic_dueno
