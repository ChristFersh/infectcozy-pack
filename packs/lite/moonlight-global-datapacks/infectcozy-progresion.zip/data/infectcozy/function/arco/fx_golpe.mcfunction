particle eeeabsmobs:guardian_spark ~ ~1 ~ 0.3 0.5 0.3 0.25 25 force
particle eeeabsmobs:volt_explosion_emitter ~ ~1 ~ 0.8 1 0 1 0 force
