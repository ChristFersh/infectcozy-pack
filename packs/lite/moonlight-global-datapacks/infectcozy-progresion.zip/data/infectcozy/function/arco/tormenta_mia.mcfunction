execute on origin if entity @s[tag=ic_disparando] run return 1
return 0
