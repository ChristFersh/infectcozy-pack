# 20 de dano verdadero (ignora armadura, resistencia e invulnerabilidad) (tipo propio infectcozy:rayo_energia), atribuido al tirador.
# Va en su propio archivo: si el tipo de dano no esta registrado (mundo sin reiniciar) solo falla esta funcion y golpe usa dano_alt.
scoreboard players set #ok ic_tmp 0
execute store success score #ok ic_tmp run damage @s 20 infectcozy:rayo_energia by @a[tag=ic_dueno,limit=1]
