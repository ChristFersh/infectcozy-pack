particle eeeabsmobs:volt_explosion_emitter ~ ~ ~ 2.5 3 0 1 0 force
particle eeeabsmobs:guardian_spark ~ ~ ~ 1.5 0.8 1.5 0.3 60 force
