scoreboard players add @s ic_arco_vida 1
execute if score @s ic_arco_vida matches 8.. run fill ~-3 ~-3 ~-3 ~3 ~3 ~3 minecraft:air replace #minecraft:fire
execute if score @s ic_arco_vida matches 8.. run kill @s
