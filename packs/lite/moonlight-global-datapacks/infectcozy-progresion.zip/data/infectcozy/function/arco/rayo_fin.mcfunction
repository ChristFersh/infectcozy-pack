# El rayo llego a su alcance maximo (80 bloques) sin tocar nada.
summon minecraft:marker ~ ~ ~ {Tags:["ic_rayo_fin"]}
particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.05 8 force
particle minecraft:electric_spark ~ ~ ~ 0.3 0.3 0.3 0.1 10 force
