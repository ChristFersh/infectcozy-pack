# El rayo choco con un bloque solido. Contexto: como el tirador, justo delante de la superficie.
summon minecraft:marker ~ ~ ~ {Tags:["ic_rayo_fin"]}
function infectcozy:arco/trueno
particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
particle minecraft:flash ~ ~ ~ 0 0 0 0 1 force
particle minecraft:electric_spark ~ ~ ~ 2 1 2 0.5 90 force
particle minecraft:dust{color:[0.3,0.85,1.0],scale:2.5} ~ ~ ~ 2.5 0.6 2.5 0 70 force
particle minecraft:end_rod ~ ~ ~ 1.5 0.5 1.5 0.2 30 force
function infectcozy:arco/fx_suelo
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 2 0.8
execute as @e[type=!#infectcozy:arco_ignorar,tag=!ic_disparando,distance=..5] run function infectcozy:arco/area
summon minecraft:marker ~ ~ ~ {Tags:["ic_fuego"]}
