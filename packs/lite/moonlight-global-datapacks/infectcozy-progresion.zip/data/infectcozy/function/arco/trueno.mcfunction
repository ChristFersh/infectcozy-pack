# Rayo del impacto. Si algun jugador esta dentro de la zona que golpea el rayo (x/z +-3, y -3..+9) no se invoca: solo suena.
execute positioned ~-3.5 ~-3.5 ~-3.5 if entity @a[gamemode=!spectator,dx=6,dy=12,dz=6] run return run playsound minecraft:entity.lightning_bolt.impact player @a ~3.5 ~3.5 ~3.5 1 1.3
summon minecraft:lightning_bolt ~ ~ ~
