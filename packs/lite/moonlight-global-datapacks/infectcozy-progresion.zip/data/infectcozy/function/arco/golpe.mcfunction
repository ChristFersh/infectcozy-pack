# Golpe directo. Contexto: como el blanco, en su posicion. El tirador tiene la etiqueta ic_dueno.
tag @s remove ic_blanco
# Encantamientos del arco (mano principal o secundaria): Poder = dano plano extra que SI cuenta la armadura
data modify storage infectcozy:enc e set value {}
execute as @a[tag=ic_dueno,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_arco:1b}] run data modify storage infectcozy:enc e set from entity @s SelectedItem.components."minecraft:enchantments".levels
execute as @a[tag=ic_dueno,limit=1] unless items entity @s weapon.mainhand *[minecraft:custom_data~{ic_arco:1b}] run data modify storage infectcozy:enc e set from entity @s Inventory[{Slot:-106b}].components."minecraft:enchantments".levels
scoreboard players set #pw ic_tmp 0
execute store result score #pw ic_tmp run data get storage infectcozy:enc e."minecraft:power"
scoreboard players set #e_sh ic_tmp 0
scoreboard players set #e_sm ic_tmp 0
scoreboard players set #e_ba ic_tmp 0
scoreboard players set #e_im ic_tmp 0
execute store result score #e_sm ic_tmp run data get storage infectcozy:enc e."minecraft:smite"
execute store result score #e_ba ic_tmp run data get storage infectcozy:enc e."minecraft:bane_of_arthropods"
execute store result score #e_im ic_tmp run data get storage infectcozy:enc e."minecraft:impaling"
function infectcozy:encanto/bono
scoreboard players set #c3s ic_tmp 3
scoreboard players operation #ax ic_tmp = #pw ic_tmp
scoreboard players operation #ax ic_tmp *= #c3s ic_tmp
scoreboard players operation #ax ic_tmp += #bono ic_tmp
execute if score #ax ic_tmp matches 1.. store result storage infectcozy:sh d int 1 run scoreboard players get #ax ic_tmp
execute if score #ax ic_tmp matches 1.. run function infectcozy:arco/extra with storage infectcozy:sh
scoreboard players set #ok ic_tmp -1
function infectcozy:arco/dano
execute if score #ok ic_tmp matches -1 run function infectcozy:arco/dano_alt
execute if score #ok ic_tmp matches 1 run scoreboard players set #dano ic_robo 200
execute if score #ok ic_tmp matches 1 as @a[tag=ic_dueno,limit=1] at @s run function infectcozy:robo/golpe_directo
function infectcozy:arco/trueno
particle minecraft:flash ~ ~1 ~ 0 0 0 0 1 force
particle minecraft:electric_spark ~ ~1 ~ 0.5 1 0.5 0.4 50 force
particle minecraft:dust{color:[0.3,0.85,1.0],scale:2.0} ~ ~1 ~ 0.5 0.8 0.5 0 30 force
function infectcozy:arco/fx_golpe
summon minecraft:marker ~ ~ ~ {Tags:["ic_fuego"]}
# Encantamientos de estado del arco (Llama, plaga, congelacion...)
function infectcozy:encanto/golpe
