# Respaldo: sonic_boom tambien ignora armadura.
scoreboard players set #tri_ok ic_tmp 0
execute if entity @a[tag=ic_dueno] run damage @s 500 minecraft:sonic_boom by @a[tag=ic_dueno,limit=1]
execute unless entity @a[tag=ic_dueno] run damage @s 500 minecraft:sonic_boom
