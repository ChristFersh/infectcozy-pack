# Respaldo con sonic_boom: tras el golpe de 500 hay invulnerabilidad, asi que 501 deja pasar solo 1 de dano.
execute if entity @a[tag=ic_dueno] run damage @s 501 minecraft:sonic_boom by @a[tag=ic_dueno,limit=1]
execute unless entity @a[tag=ic_dueno] run damage @s 501 minecraft:sonic_boom
