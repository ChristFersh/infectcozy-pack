# Como el tridente definitivo, en su posicion. Detecta el primer impacto (criatura o suelo).
execute if entity @s[nbt={DealtDamage:1b}] run return run function infectcozy:tridente/impacto_entidad
execute if entity @s[nbt={inGround:1b}] run return run function infectcozy:tridente/impacto_suelo
