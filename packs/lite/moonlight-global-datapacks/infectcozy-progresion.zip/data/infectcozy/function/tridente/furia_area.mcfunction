# Como cada criatura alcanzada por la onda de la Furia. Nunca a mascotas de jugadores.
execute on owner if entity @s[type=minecraft:player] run return 0
function infectcozy:tridente/furia500
