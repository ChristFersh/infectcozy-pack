# MACRO: $(d) = dano total del golpe. Como la criatura golpeada.
$damage @s $(d) minecraft:trident by @a[tag=ic_dueno,limit=1]
particle minecraft:nautilus ~ ~1 ~ 0.4 0.6 0.4 0.3 10 force
