# Tipo de dano propio (infectcozy:furia_abismo). Si el mundo no se reinicio y no existe, solo falla esta funcion.
scoreboard players set #tri_ok ic_tmp 0
execute if entity @a[tag=ic_dueno] run scoreboard players set #tri_ok ic_tmp 1
execute if score #tri_ok ic_tmp matches 1 run damage @s 500 infectcozy:furia_abismo by @a[tag=ic_dueno,limit=1]
execute if score #tri_ok ic_tmp matches 0 run damage @s 500 infectcozy:furia_abismo
