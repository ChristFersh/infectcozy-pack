# Como una copia clavada del Tridente del Abismo. Solo su lanzador la recoge acercandose.
execute unless entity @s[nbt={inGround:1b}] run return 0
particle minecraft:glow ~ ~0.3 ~ 0.15 0.15 0.15 0 1
scoreboard players set #tri_recogida ic_tmp 0
# Copia extra del Multidisparo: al recogerla puede absorberse y dar una carga (Multidisparo I: 50 %, II: 75 %)
execute if entity @s[tag=ic_tri_extra] on origin if entity @s[type=minecraft:player,distance=..2,gamemode=!spectator] run scoreboard players set #tri_recogida ic_tmp 2
execute if score #tri_recogida ic_tmp matches 2 run return run function infectcozy:tridente/recoger_extra
execute unless entity @s[tag=ic_tri_extra] on origin if entity @s[type=minecraft:player,distance=..2,gamemode=!spectator] run function infectcozy:tridente/recoger
execute if score #tri_recogida ic_tmp matches 1 run kill @s
