# Prepara el dano extra por Lanzas del abismo (8 + lanzas; el golpe del tridente ya hizo 8).
execute store result storage infectcozy:tri d int 1 run scoreboard players get #tri_dmg ic_tmp
function infectcozy:tridente/bonus with storage infectcozy:tri
