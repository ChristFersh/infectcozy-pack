# Al morir se pierden las cargas del abismo.
scoreboard players set @s ic_tri_muertes 0
execute if score @s ic_tri_lanzas matches 1.. run tellraw @s [{"text":"Perdiste tus ","color":"gray"},{"score":{"name":"@s","objective":"ic_tri_lanzas"},"color":"aqua"},{"text":" cargas del abismo.","color":"dark_aqua"}]
scoreboard players set @s ic_tri_lanzas 0
