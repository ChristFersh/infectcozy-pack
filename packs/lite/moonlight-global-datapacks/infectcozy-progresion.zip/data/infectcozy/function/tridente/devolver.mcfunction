# Como el tridente lanzado: copia su item completo (encantamientos, nombre...) y lo devuelve al lanzador.
summon minecraft:item_display ~ ~ ~ {Tags:["ic_tri_tmp"]}
data modify entity @e[type=minecraft:item_display,tag=ic_tri_tmp,limit=1] item set from entity @s item
execute as @a[tag=ic_tri_lanzador,limit=1] at @s run function infectcozy:tridente/devolver_jugador
kill @e[type=minecraft:item_display,tag=ic_tri_tmp]
