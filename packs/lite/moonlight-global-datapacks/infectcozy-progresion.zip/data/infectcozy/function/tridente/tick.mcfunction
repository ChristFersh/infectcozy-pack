execute as @e[type=minecraft:trident,tag=!ic_tri_v] at @s run function infectcozy:tridente/nuevo
execute as @e[type=minecraft:trident,tag=ic_tri,tag=!ic_tri_boom] at @s run function infectcozy:tridente/vuelo
execute as @e[type=minecraft:trident,tag=ic_tri,tag=ic_tri_boom] at @s run function infectcozy:tridente/copia
execute as @e[type=minecraft:trident,tag=ic_tri_copia] at @s run function infectcozy:tridente/copia
execute as @a[scores={ic_tri_muertes=1..}] run function infectcozy:tridente/muerte
