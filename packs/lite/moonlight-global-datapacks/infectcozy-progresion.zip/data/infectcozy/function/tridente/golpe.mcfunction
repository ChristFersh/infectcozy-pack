# Como la criatura acertada por el Tridente del Abismo (el lanzador tiene ic_dueno).
# Con Furia: 500 de dano verdadero. Sin Furia: +1 de dano por carga sobre los 8 del tridente.
execute on owner if entity @s[type=minecraft:player] run return 0
scoreboard players operation #tri_dmg ic_tmp = #tri_l ic_tmp
scoreboard players add #tri_dmg ic_tmp 8
scoreboard players operation #e_sh ic_tmp = #t_sh ic_tmp
scoreboard players operation #e_sm ic_tmp = #t_sm ic_tmp
scoreboard players operation #e_ba ic_tmp = #t_ba ic_tmp
scoreboard players operation #e_im ic_tmp = #t_im ic_tmp
function infectcozy:encanto/bono
scoreboard players operation #tri_dmg ic_tmp += #bono ic_tmp
scoreboard players operation #dano ic_robo = #tri_dmg ic_tmp
scoreboard players operation #dano ic_robo *= #c10 ic_tmp
execute if score #tri_crit ic_tmp matches 1 run function infectcozy:tridente/furia500
execute if score #tri_crit ic_tmp matches 1 run scoreboard players set #dano ic_robo 5000
execute if score #tri_crit ic_tmp matches 0 if score #tri_dmg ic_tmp matches 9.. if entity @a[tag=ic_dueno] run function infectcozy:tridente/bonus_prep
execute as @a[tag=ic_dueno,limit=1] at @s run function infectcozy:robo/golpe_directo
