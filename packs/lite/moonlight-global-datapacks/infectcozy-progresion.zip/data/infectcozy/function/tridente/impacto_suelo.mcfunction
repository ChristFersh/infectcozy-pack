scoreboard players set #tri_ent ic_tmp 0
function infectcozy:tridente/impacto
