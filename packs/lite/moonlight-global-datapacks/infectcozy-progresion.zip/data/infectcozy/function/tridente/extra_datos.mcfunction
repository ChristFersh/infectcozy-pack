# (como la copia extra) mismo item y mismo dueno que la copia principal
data modify entity @s item set from entity @e[type=minecraft:trident,tag=ic_tri_src,limit=1] item
data modify entity @s Owner set from entity @e[type=minecraft:trident,tag=ic_tri_src,limit=1] Owner
data remove entity @s item.components."minecraft:enchantments".levels."minecraft:multishot"
scoreboard players set @s ic_tri_lanzas 0
execute if score #ms ic_tmp matches 1 run tag @s add ic_tri_ms1
execute if score #ms ic_tmp matches 2.. run tag @s add ic_tri_ms2
