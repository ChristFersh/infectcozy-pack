# infectcozy:tridente/multi  (como la copia principal recien lanzada; el lanzador tiene ic_tri_lanzador)
tag @s add ic_tri_src
execute as @a[tag=ic_tri_lanzador,limit=1] at @s anchored eyes if score #ms ic_tmp matches 1 rotated ~7 ~ run function infectcozy:tridente/extra
execute as @a[tag=ic_tri_lanzador,limit=1] at @s anchored eyes if score #ms ic_tmp matches 2.. rotated ~-9 ~ run function infectcozy:tridente/extra
execute as @a[tag=ic_tri_lanzador,limit=1] at @s anchored eyes if score #ms ic_tmp matches 2.. rotated ~9 ~ run function infectcozy:tridente/extra
tag @s remove ic_tri_src
playsound minecraft:item.crossbow.shoot player @a ~ ~ ~ 1 0.7
