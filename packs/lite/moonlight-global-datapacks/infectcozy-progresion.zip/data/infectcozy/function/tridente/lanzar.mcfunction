# Como el Tridente del Abismo recien lanzado.
execute on origin if entity @s[type=minecraft:player] run tag @s add ic_tri_lanzador
execute unless entity @a[tag=ic_tri_lanzador] run return 0
# 1) El original vuelve a tu inventario (en creativo nunca se va).
execute if entity @a[tag=ic_tri_lanzador,gamemode=!creative] run function infectcozy:tridente/devolver
# 2) Lo que vuela es una copia: no se recoge como item, sin Lealtad (evita duplicarlo) y dura 2 min clavada.
data merge entity @s {pickup:0b,life:-1200s}
data remove entity @s item.components."minecraft:enchantments".levels."minecraft:loyalty"
# 3) Gasta todas las cargas: la copia se las lleva y el jugador vuelve a 0.
scoreboard players add @a[tag=ic_tri_lanzador] ic_tri_lanzas 0
scoreboard players operation @s ic_tri_lanzas = @a[tag=ic_tri_lanzador,limit=1] ic_tri_lanzas
scoreboard players set @a[tag=ic_tri_lanzador] ic_tri_lanzas 0
execute if score @s ic_tri_lanzas matches 1.. run function infectcozy:tridente/aviso_gasto
# 4) Multidisparo (Yunque del Abismo): I = 2 tridentes, II = 3. Las copias extra no llevan cargas ni Furia.
scoreboard players set #ms ic_tmp 0
execute store result score #ms ic_tmp run data get entity @s item.components."minecraft:enchantments".levels."minecraft:multishot"
execute if score #ms ic_tmp matches 1.. run function infectcozy:tridente/multi
tag @a[tag=ic_tri_lanzador] remove ic_tri_lanzador
