# Como el lanzador: el tridente vuelve a la mano vacia; si no hay mano libre, cae a sus pies y solo el puede recogerlo.
execute unless items entity @s weapon.mainhand * run return run item replace entity @s weapon.mainhand from entity @e[type=minecraft:item_display,tag=ic_tri_tmp,limit=1] contents
execute unless items entity @s weapon.offhand * run return run item replace entity @s weapon.offhand from entity @e[type=minecraft:item_display,tag=ic_tri_tmp,limit=1] contents
summon minecraft:item ~ ~0.3 ~ {Tags:["ic_tri_tmpi"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=minecraft:item,tag=ic_tri_tmpi,limit=1] Item set from entity @e[type=minecraft:item_display,tag=ic_tri_tmp,limit=1] item
data modify entity @e[type=minecraft:item,tag=ic_tri_tmpi,limit=1] Owner set from entity @s UUID
tag @e[type=minecraft:item,tag=ic_tri_tmpi] remove ic_tri_tmpi
