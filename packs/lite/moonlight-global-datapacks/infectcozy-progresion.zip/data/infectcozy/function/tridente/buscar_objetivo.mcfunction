# Como el tridente: marca (ic_tri_obj) la criatura que acaba de recibir el golpe (HurtTime 10 o 9), la mas cercana.
# Si no hay ninguna (golpe durante invulnerabilidad), la criatura viva mas cercana a 3.5 bloques.
execute as @e[type=!#infectcozy:arco_ignorar,distance=..10,nbt={HurtTime:10s}] run tag @s add ic_tri_cand
execute as @e[type=!#infectcozy:arco_ignorar,distance=..10,nbt={HurtTime:9s}] run tag @s add ic_tri_cand
tag @e[tag=ic_tri_cand,sort=nearest,limit=1] add ic_tri_obj
tag @e[tag=ic_tri_cand] remove ic_tri_cand
execute if entity @e[tag=ic_tri_obj] run return 1
execute as @e[type=!#infectcozy:arco_ignorar,distance=..3.5] if data entity @s Health run tag @s add ic_tri_cand
tag @e[tag=ic_tri_cand,sort=nearest,limit=1] add ic_tri_obj
tag @e[tag=ic_tri_cand] remove ic_tri_cand
