# infectcozy:tridente/extra  (como el lanzador, con la rotacion de la copia extra; anclado en los ojos)
# Copia extra: mismo tridente, sin recoger, sin cargas; al caer golpea y explota, y se deshace.
execute positioned ^ ^ ^0.8 run summon minecraft:trident ~ ~ ~ {Tags:["ic_tri_v","ic_tri","ic_tri_extra","ic_tri_nuevo"],pickup:0b,life:-1200s}
execute as @e[type=minecraft:trident,tag=ic_tri_nuevo,limit=1] run function infectcozy:tridente/extra_datos
execute anchored feet positioned 0.0 0.0 0.0 positioned ^ ^ ^2.5 summon minecraft:marker run function infectcozy:tridente/vec
data modify entity @e[type=minecraft:trident,tag=ic_tri_nuevo,limit=1] Motion set from storage infectcozy:tri v
tag @e[type=minecraft:trident,tag=ic_tri_nuevo] remove ic_tri_nuevo
