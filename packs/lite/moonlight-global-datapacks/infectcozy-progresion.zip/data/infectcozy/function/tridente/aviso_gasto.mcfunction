# Como el tridente lanzado con cargas: avisa al lanzador de lo que gasto.
scoreboard players operation #tri_l ic_tmp = @s ic_tri_lanzas
execute as @a[tag=ic_tri_lanzador,limit=1] run function infectcozy:tridente/calc_prob
title @a[tag=ic_tri_lanzador] actionbar [{"text":"Gastas ","color":"gray"},{"score":{"name":"#tri_l","objective":"ic_tmp"},"color":"aqua","bold":true},{"text":" cargas","color":"dark_aqua"},{"text":"  ·  +","color":"gray"},{"score":{"name":"#tri_l","objective":"ic_tmp"},"color":"aqua"},{"text":" daño  ·  Furia ","color":"gray"},{"score":{"name":"#tri_pct","objective":"ic_tmp"},"color":"aqua"},{"text":" %","color":"gray"}]
playsound minecraft:item.trident.riptide_1 player @a[tag=ic_tri_lanzador] ~ ~ ~ 0.8 1.4
particle minecraft:nautilus ~ ~ ~ 0.3 0.3 0.3 0.4 15 force
