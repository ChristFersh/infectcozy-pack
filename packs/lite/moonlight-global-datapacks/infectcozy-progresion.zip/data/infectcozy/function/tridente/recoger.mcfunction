# Como el lanzador que recoge su copia: +1 carga del abismo (maximo 30). El siguiente lanzamiento las gasta todas.
scoreboard players set #tri_recogida ic_tmp 1
scoreboard players add @s ic_tri_lanzas 1
execute if score @s ic_tri_lanzas matches 31.. run scoreboard players set @s ic_tri_lanzas 30
scoreboard players operation #tri_l ic_tmp = @s ic_tri_lanzas
function infectcozy:tridente/calc_prob
title @s actionbar [{"text":"Cargas del abismo ","color":"dark_aqua"},{"score":{"name":"@s","objective":"ic_tri_lanzas"},"color":"aqua","bold":true},{"text":"/30  ·  próximo lanzamiento: +","color":"gray"},{"score":{"name":"@s","objective":"ic_tri_lanzas"},"color":"aqua"},{"text":" daño, Furia ","color":"gray"},{"score":{"name":"#tri_pct","objective":"ic_tmp"},"color":"aqua"},{"text":" %","color":"gray"}]
playsound minecraft:item.trident.return player @s ~ ~ ~ 1 1.3
particle minecraft:nautilus ~ ~1 ~ 0.4 0.6 0.4 0.4 20
