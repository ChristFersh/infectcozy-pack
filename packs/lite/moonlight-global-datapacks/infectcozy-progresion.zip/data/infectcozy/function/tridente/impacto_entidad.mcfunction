scoreboard players set #tri_ent ic_tmp 1
function infectcozy:tridente/impacto
