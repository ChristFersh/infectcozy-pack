# Se ejecuta una sola vez por tridente lanzado.
tag @s add ic_tri_v
execute if entity @s[nbt={item:{components:{"minecraft:custom_data":{ic_tridente:1b}}}}] run tag @s add ic_tri
execute if entity @s[tag=ic_tri] run function infectcozy:tridente/lanzar
