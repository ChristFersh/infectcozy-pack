# (como la copia extra del Multidisparo, cuando su lanzador se acerca)
# Probabilidad de absorberla: Multidisparo I = 50 %, Multidisparo II = 75 % por copia. Si se absorbe, da una carga
# como la copia principal; si no, solo vuelve a la nada.
scoreboard players set #tri_abs ic_tmp 0
execute store result score #tri_r ic_tmp run random value 1..100
execute if entity @s[tag=ic_tri_ms1] if score #tri_r ic_tmp matches ..50 run scoreboard players set #tri_abs ic_tmp 1
execute if entity @s[tag=ic_tri_ms2] if score #tri_r ic_tmp matches ..75 run scoreboard players set #tri_abs ic_tmp 1
execute if score #tri_abs ic_tmp matches 1 on origin run function infectcozy:tridente/recoger
execute if score #tri_abs ic_tmp matches 1 run particle minecraft:glow ~ ~0.6 ~ 0.3 0.4 0.3 0.1 15
execute if score #tri_abs ic_tmp matches 1 run playsound minecraft:block.amethyst_block.chime player @a ~ ~ ~ 1 1.4
execute if score #tri_abs ic_tmp matches 0 run playsound minecraft:item.trident.return player @a ~ ~ ~ 0.7 1.6
execute if score #tri_abs ic_tmp matches 0 run particle minecraft:nautilus ~ ~0.5 ~ 0.3 0.3 0.3 0.3 8
kill @s
