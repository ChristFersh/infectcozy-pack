# MACRO $(d): respaldo con sonic_boom si el tipo propio no existe (mundo sin reiniciar).
$execute if entity @a[tag=ic_dueno] run damage @s $(d) minecraft:sonic_boom by @a[tag=ic_dueno,limit=1]
$execute unless entity @a[tag=ic_dueno] run damage @s $(d) minecraft:sonic_boom
