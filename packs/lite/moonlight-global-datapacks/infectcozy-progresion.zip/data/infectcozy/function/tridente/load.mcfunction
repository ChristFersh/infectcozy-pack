scoreboard objectives add ic_tmp dummy
scoreboard objectives add ic_robo dummy
scoreboard objectives add ic_tri_lanzas dummy
scoreboard objectives add ic_tri_muertes deathCount
scoreboard players set #c30 ic_tmp 30
scoreboard players set #c40 ic_tmp 40
scoreboard players set #c230 ic_tmp 230
scoreboard players set #c10 ic_tmp 10
scoreboard players set #c100 ic_tmp 100
