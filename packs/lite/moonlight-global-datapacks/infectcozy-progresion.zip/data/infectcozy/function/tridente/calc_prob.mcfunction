# Entrada: #tri_l (cargas). Salida: #tri_prob (por mil) y #tri_pct (%).
# La Furia solo puede salir desde 10 cargas. 2 % base + 23 % repartido en 30 cargas (10 = 9,6 %, 30 = 25 %) + 4 % por nivel de suerte. Tope 35 %.
scoreboard players operation #tri_prob ic_tmp = #tri_l ic_tmp
scoreboard players operation #tri_prob ic_tmp *= #c230 ic_tmp
scoreboard players operation #tri_prob ic_tmp /= #c30 ic_tmp
scoreboard players add #tri_prob ic_tmp 20
scoreboard players set #tri_suerte ic_tmp 0
execute if entity @s[type=minecraft:player] store result score #tri_suerte ic_tmp run attribute @s minecraft:generic.luck get 1
scoreboard players operation #tri_suerte ic_tmp *= #c40 ic_tmp
scoreboard players operation #tri_prob ic_tmp += #tri_suerte ic_tmp
execute if score #tri_prob ic_tmp matches ..9 run scoreboard players set #tri_prob ic_tmp 10
execute if score #tri_prob ic_tmp matches 351.. run scoreboard players set #tri_prob ic_tmp 350
scoreboard players operation #tri_pct ic_tmp = #tri_prob ic_tmp
scoreboard players operation #tri_pct ic_tmp /= #c10 ic_tmp
# Menos de 10 cargas: sin Furia
execute if score #tri_l ic_tmp matches ..9 run scoreboard players set #tri_prob ic_tmp 0
execute if score #tri_l ic_tmp matches ..9 run scoreboard players set #tri_pct ic_tmp 0
