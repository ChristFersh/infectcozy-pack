# (como un marcador temporal en 0,0,0 + direccion x 2.5) guarda el vector de velocidad
data modify storage infectcozy:tri v set from entity @s Pos
kill @s
