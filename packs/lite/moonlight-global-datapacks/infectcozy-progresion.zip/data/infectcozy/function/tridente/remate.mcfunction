# Tipo de dano propio (ignora la invulnerabilidad tras un golpe): 1 de dano basta para rematar a quien quedo a 1 de vida.
# Si el tipo no existe (mundo sin reiniciar), solo falla esta funcion y se usa remate_alt.
scoreboard players set #tri_ok ic_tmp 0
execute if entity @a[tag=ic_dueno] run damage @s 1 infectcozy:furia_abismo by @a[tag=ic_dueno,limit=1]
execute unless entity @a[tag=ic_dueno] run damage @s 1 infectcozy:furia_abismo
