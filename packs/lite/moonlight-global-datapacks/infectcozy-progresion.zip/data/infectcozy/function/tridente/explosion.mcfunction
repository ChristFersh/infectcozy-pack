# Explosion en area como la del arco, pero sin relampago. No rompe bloques ni dana a jugadores ni mascotas.
particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
particle minecraft:flash ~ ~ ~ 0 0 0 0 1 force
particle minecraft:bubble_pop ~ ~0.5 ~ 2 1 2 0.2 80 force
particle minecraft:dust{color:[0.05,0.55,0.75],scale:2.5} ~ ~0.5 ~ 2.5 0.6 2.5 0 70 force
particle minecraft:nautilus ~ ~1 ~ 1.5 1 1.5 0.5 40 force
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 2 0.9
playsound minecraft:item.trident.hit_ground player @a ~ ~ ~ 1.5 0.6
execute as @e[type=!#infectcozy:arco_ignorar,distance=..5] run function infectcozy:tridente/area
