# Como cada criatura alcanzada por la explosion normal del Tridente del Abismo: 10 de dano (nunca a mascotas de jugadores).
execute on owner if entity @s[type=minecraft:player] run return 0
execute if entity @a[tag=ic_dueno] run damage @s 10 minecraft:player_explosion by @a[tag=ic_dueno,limit=1]
execute unless entity @a[tag=ic_dueno] run damage @s 10 minecraft:explosion
