# MACRO $(d): dano de la Furia con el tipo propio infectcozy:furia_abismo. #tri_ok = 1 si entro.
$execute if entity @a[tag=ic_dueno] store success score #tri_ok ic_tmp run damage @s $(d) infectcozy:furia_abismo by @a[tag=ic_dueno,limit=1]
$execute unless entity @a[tag=ic_dueno] store success score #tri_ok ic_tmp run damage @s $(d) infectcozy:furia_abismo
