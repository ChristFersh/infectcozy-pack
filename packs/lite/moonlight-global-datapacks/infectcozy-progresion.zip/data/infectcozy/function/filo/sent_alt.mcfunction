# (bajando desde los pies) Cuenta los bloques libres hasta el suelo, como mucho 9
execute unless block ~ ~ ~ #infectcozy:laser_pasa run return 0
scoreboard players add #sh ic_tmp 1
execute if score #sh ic_tmp matches 9.. run return 0
execute positioned ~ ~-1 ~ run function infectcozy:filo/sent_alt
