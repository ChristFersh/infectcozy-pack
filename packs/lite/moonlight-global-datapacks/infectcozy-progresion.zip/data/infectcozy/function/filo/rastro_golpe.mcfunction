execute on owner if entity @s[type=minecraft:player] run return 0
execute if entity @s[type=minecraft:player] run return 0
execute store result score #f ic_tmp run data get entity @s Fire
execute if score #f ic_tmp matches ..20 run data merge entity @s {Fire:60s}
execute if entity @a[tag=ic_fs_d] run damage @s 1 infectcozy:juicio by @a[tag=ic_fs_d,limit=1]
