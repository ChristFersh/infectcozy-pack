# infectcozy:filo/tick
# 1) Descuenta la marca de carga; si llega a 0 (dejo de cargar hace 2-3 ticks) se apaga la guardia.
execute as @a[tag=ic_filo_carga] run function infectcozy:filo/temporizador
# 2) Hace girar el anillo (angulo y fase globales, compartidos por todos los que cargan).
execute if entity @a[tag=ic_filo_carga] run function infectcozy:filo/girar
# 3) Barrido de seguridad una vez por segundo.
scoreboard players add #filo_barrido ic_tmp 1
execute if score #filo_barrido ic_tmp matches 20.. run function infectcozy:filo/barrido
# 4) Ataque cargado: tierra calcinada de las llamaradas (cada 5 ticks) y vortice (cada tick)
execute if score #hh_r5 ic_tmp matches 3 as @e[type=minecraft:marker,tag=ic_fs_m] at @s run function infectcozy:filo/fs_tick
execute as @a[scores={ic_fv=1..}] at @s run function infectcozy:filo/vortice
# 5) Embestida y Sentencia (cada tick) y el rastro de fuego de almas (cada 5 ticks)
execute as @a[tag=ic_fe] at @s run function infectcozy:filo/embestida_paso
execute as @a[tag=ic_fsn] at @s run function infectcozy:filo/sentencia_paso
execute as @a[tag=ic_fsn_f] run function infectcozy:filo/sent_f
execute if score #hh_r5 ic_tmp matches 1 as @e[type=minecraft:marker,tag=ic_fe_r] at @s run function infectcozy:filo/rastro
