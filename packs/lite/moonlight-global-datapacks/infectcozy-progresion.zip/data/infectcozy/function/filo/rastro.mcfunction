# (como un marcador del rastro de la embestida, cada 5 ticks durante 2 s) fuego de almas que quema
scoreboard players remove @s ic_fs_t 5
execute if score @s ic_fs_t matches ..0 run return run kill @s
particle minecraft:soul_fire_flame ~ ~0.15 ~ 0.35 0.05 0.35 0.01 3
particle minecraft:flame ~ ~0.15 ~ 0.3 0.05 0.3 0.01 1
scoreboard players operation #fs_o ic_tmp = @s ic_fs_o
tag @a[tag=ic_fs_d] remove ic_fs_d
execute as @a if score @s ic_id = #fs_o ic_tmp run tag @s add ic_fs_d
tag @a[tag=ic_fs_d] add ic_fc_no
execute as @e[type=!#infectcozy:arco_ignorar,distance=..1.3] run function infectcozy:filo/rastro_golpe
tag @a[tag=ic_fs_d] remove ic_fc_no
tag @a[tag=ic_fs_d] remove ic_fs_d
