# infectcozy:filo/temporizador (as jugador con tag ic_filo_carga)
scoreboard players remove @s ic_filo_t 1
execute unless score @s ic_filo_t matches 1.. at @s run function infectcozy:filo/fin
