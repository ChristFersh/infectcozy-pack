# (como un jugador que no esta en Sentencia) Por si murio o se desconecto a medias
attribute @s minecraft:generic.gravity modifier remove infectcozy:sentencia
attribute @s minecraft:generic.fall_damage_multiplier modifier remove infectcozy:sentencia
