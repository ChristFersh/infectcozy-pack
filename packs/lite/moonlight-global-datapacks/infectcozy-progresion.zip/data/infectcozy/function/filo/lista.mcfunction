# infectcozy:filo/lista (tick 60 de carga: el Incinerador ya puede lanzar su ataque; el mod suena FLAME_BURST)
particle minecraft:flame ~ ~1 ~ 0.3 0.5 0.3 0.06 16
particle minecraft:soul_fire_flame ~ ~0.1 ~ 0.6 0.05 0.6 0.03 10
function infectcozy:filo/aviso
