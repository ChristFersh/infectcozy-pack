# infectcozy:filo/load
# Filo del Juicio (cataclysm:the_incinerator con custom_data {ic_filo:1b}): "Guardia ignea".
# Mientras se carga su habilidad (clic derecho mantenido): aura de fuego y -50 % de dano recibido.
# ic_filo_t    : ticks que le quedan a la marca de carga (la recompensa del avance la pone en 3 cada tick).
# ic_filo_n    : ticks seguidos cargando (60 = carga completa del Incinerador).
# ic_filo_dano : estadistica vanilla damage_taken (x10); solo se mira mientras se carga, para el destello al recibir un golpe.
# ic_tmp       : fake players #filo_ang (angulo del anillo 0..105), #filo_fase (0..19), #filo_barrido (0..19).
scoreboard objectives add ic_tmp dummy
scoreboard objectives add ic_filo_t dummy
scoreboard objectives add ic_filo_n dummy
scoreboard objectives add ic_filo_dano minecraft.custom:minecraft.damage_taken
scoreboard players set #filo_ang ic_tmp 0
scoreboard players set #filo_fase ic_tmp 0
scoreboard players set #filo_barrido ic_tmp 0
data merge storage infectcozy:filo {fx:{a:0,b:0}}
# Ataques nuevos: combo (ic_fc), embestida (ic_fe_*), sentencia (ic_fsn_*), vortice (ic_fv), robo de vida (ic_frv)
scoreboard objectives add ic_id dummy
scoreboard objectives add ic_fc dummy
scoreboard objectives add ic_fc_t dummy
scoreboard objectives add ic_fe_cd dummy
scoreboard objectives add ic_fe_p dummy
scoreboard objectives add ic_fsn_cd dummy
scoreboard objectives add ic_fsn_t dummy
scoreboard objectives add ic_fv dummy
scoreboard objectives add ic_frv dummy
scoreboard objectives add ic_fs_t dummy
scoreboard objectives add ic_fs_o dummy
scoreboard objectives add ic_fs_g dummy
scoreboard players set #c10 ic_tmp 10
scoreboard players set #c20 ic_tmp 20
