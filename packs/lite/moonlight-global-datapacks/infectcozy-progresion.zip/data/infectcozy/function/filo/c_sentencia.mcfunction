# (como el jugador) Comando de Iron's Spells en su propia funcion. Divine Smite tarda 16 ticks: el golpe de la
# animacion termina arriba, justo antes de la picada.
cast @s irons_spellbooks:divine_smite 1
