execute store result score #fq_now ic_tmp run time query gametime
execute if entity @s[tag=ic_fe] run return 0
execute if entity @s[tag=ic_fsn] run return 0
execute if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{flags:{is_sneaking:true}}} run return run function infectcozy:filo/sentencia_intento
function infectcozy:filo/embestida_intento
