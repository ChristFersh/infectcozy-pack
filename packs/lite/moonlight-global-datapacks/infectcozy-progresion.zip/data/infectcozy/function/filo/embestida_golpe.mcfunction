execute on owner if entity @s[type=minecraft:player] run return 0
execute if entity @s[type=minecraft:player] run return 0
tag @s add ic_fe_hit
function infectcozy:encanto/filo_golpe {b:12,t:"ic_fe_yo",ty:"infectcozy:juicio"}
execute store result score #f ic_tmp run data get entity @s Fire
execute if score #f ic_tmp matches ..20 run data merge entity @s {Fire:100s}
particle minecraft:crit ~ ~1 ~ 0.3 0.4 0.3 0.3 10
