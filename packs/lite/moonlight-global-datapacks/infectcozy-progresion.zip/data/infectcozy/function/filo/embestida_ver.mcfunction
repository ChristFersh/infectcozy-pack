# (como el jugador, 3er tick de la embestida) Aparte porque nombra un efecto de Iron's Spells.
execute unless predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{effects:{"irons_spellbooks:burning_dash":{}}}} run tag @s add ic_fe_tp
