effect give @s minecraft:slow_falling 2 0 true
function infectcozy:filo/sent_impacto
