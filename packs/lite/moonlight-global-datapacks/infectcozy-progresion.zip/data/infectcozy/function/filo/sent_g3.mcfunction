# (como el jugador en Sentencia) Gravedad: casi sin gravedad: suspendido
attribute @s minecraft:generic.gravity modifier remove infectcozy:sentencia
attribute @s minecraft:generic.gravity modifier add infectcozy:sentencia -0.075 add_value
