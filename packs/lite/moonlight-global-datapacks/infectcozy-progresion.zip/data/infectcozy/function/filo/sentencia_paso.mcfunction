# (como el jugador en Sentencia, cada tick) 5 ticks subiendo, 4 frenando, suspendido mientras alzas la espada y, al tick 18,
# picada envuelto en fuego hacia donde apuntas (Burning Dash) con la gravedad justa para caer cerca de ese punto.
scoreboard players add @s ic_fsn_t 1
execute if score @s ic_fsn_t matches 70.. run return run function infectcozy:filo/sent_impacto
execute if score @s ic_fsn_t matches 6 run function infectcozy:filo/sent_g2
execute if score @s ic_fsn_t matches 10 run function infectcozy:filo/sent_g3
execute if score @s ic_fsn_t matches 18 run function infectcozy:filo/sent_picada
execute if score @s ic_fsn_t matches 20 run function infectcozy:filo/sent_ver
execute if score @s ic_fsn_t matches ..17 run particle minecraft:flame ~ ~0.2 ~ 0.25 0.1 0.25 0.02 4
execute if score @s ic_fsn_t matches 10 run playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 0.5
execute if score @s ic_fsn_t matches 18.. run particle minecraft:soul_fire_flame ~ ~1 ~ 0.2 0.5 0.2 0.05 6
execute if score @s ic_fsn_t matches 18.. run particle minecraft:flame ~ ~1.5 ~ 0.2 0.5 0.2 0.05 4
# Los demas jugadores cerca no reciben el dano de los hechizos
execute if score @s ic_fsn_t matches 12.. run effect give @a[distance=0.1..6,gamemode=!spectator] minecraft:resistance 1 4 true
# Toca el suelo ya en picada, o cae al agua: la onda sale aqui. Lava debajo: la onda sale en el aire y bajas despacio.
execute if score @s ic_fsn_t matches 19.. if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{flags:{is_on_ground:true}}} run return run function infectcozy:filo/sent_impacto
execute if score @s ic_fsn_t matches 19.. if block ~ ~ ~ minecraft:water run return run function infectcozy:filo/sent_impacto
execute if score @s ic_fsn_t matches 18.. if block ~ ~-1 ~ minecraft:lava run return run function infectcozy:filo/sent_lava
execute if score @s ic_fsn_t matches 18.. if block ~ ~-2 ~ minecraft:lava run return run function infectcozy:filo/sent_lava
