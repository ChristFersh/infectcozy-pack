# (en la criatura golpeada)
particle minecraft:explosion ~ ~1 ~ 0.6 0.4 0.6 0 3 force
particle minecraft:soul_fire_flame ~ ~1 ~ 1.4 0.6 1.4 0.12 60 force
particle minecraft:flame ~ ~1 ~ 1.4 0.6 1.4 0.1 50 force
particle minecraft:lava ~ ~1 ~ 1 0.4 1 0 12
particle minecraft:dust{color:[0.45,0.1,0.6],scale:2.0} ~ ~1 ~ 1.5 0.6 1.5 0 30 force
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 1 1.3
playsound minecraft:entity.blaze.hurt player @a ~ ~ ~ 1 0.6
execute as @e[type=!#infectcozy:arco_ignorar,distance=..3.5] run function infectcozy:filo/combo_golpe
