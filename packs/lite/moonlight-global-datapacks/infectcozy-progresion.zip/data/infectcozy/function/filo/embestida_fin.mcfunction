tag @s remove ic_fe
tag @s remove ic_fe_tp
tag @e[tag=ic_fe_hit,distance=..40] remove ic_fe_hit
playsound minecraft:block.fire.extinguish player @a ~ ~ ~ 0.6 1.2
