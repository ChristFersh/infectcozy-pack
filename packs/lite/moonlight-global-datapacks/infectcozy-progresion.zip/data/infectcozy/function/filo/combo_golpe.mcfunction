execute on owner if entity @s[type=minecraft:player] run return 0
execute if entity @s[type=minecraft:player] run return 0
function infectcozy:encanto/filo_golpe {b:10,t:"ic_fc_yo",ty:"infectcozy:juicio"}
execute store result score #f ic_tmp run data get entity @s Fire
execute if score #f ic_tmp matches ..20 run data merge entity @s {Fire:80s}
