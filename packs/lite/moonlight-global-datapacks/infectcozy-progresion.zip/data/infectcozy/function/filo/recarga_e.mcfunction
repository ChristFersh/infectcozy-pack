scoreboard players operation #fq_r ic_tmp = @s ic_fe_cd
scoreboard players operation #fq_r ic_tmp -= #fq_now ic_tmp
scoreboard players add #fq_r ic_tmp 19
scoreboard players operation #fq_r ic_tmp /= #c20 ic_tmp
title @s actionbar [{"text":"Embestida: ","color":"gold"},{"score":{"name":"#fq_r","objective":"ic_tmp"},"color":"red"},{"text":" s","color":"red"}]
