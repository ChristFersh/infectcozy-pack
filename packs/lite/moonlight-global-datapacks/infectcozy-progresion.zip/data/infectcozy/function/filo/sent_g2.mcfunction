# (como el jugador en Sentencia) Gravedad: frena arriba
attribute @s minecraft:generic.gravity modifier remove infectcozy:sentencia
attribute @s minecraft:generic.gravity modifier add infectcozy:sentencia 0.17 add_value
