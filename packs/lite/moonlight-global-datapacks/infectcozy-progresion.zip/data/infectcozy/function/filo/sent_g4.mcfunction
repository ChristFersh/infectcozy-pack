# (como el jugador en Sentencia) Gravedad: picada
attribute @s minecraft:generic.gravity modifier remove infectcozy:sentencia
attribute @s minecraft:generic.gravity modifier add infectcozy:sentencia 0.42 add_value
