# infectcozy:filo/girar
# El anillo tiene 3 llamas separadas 120 grados, asi que su dibujo se repite cada 120: el angulo va 0,15,...,105.
# Solo hay 8 valores distintos, que caben en la cache de funciones macro (no se re-parsea nada).
scoreboard players add #filo_ang ic_tmp 15
execute if score #filo_ang ic_tmp matches 120.. run scoreboard players remove #filo_ang ic_tmp 120
execute store result storage infectcozy:filo fx.a int 1 run scoreboard players get #filo_ang ic_tmp
execute store result storage infectcozy:filo fx.b int -1 run scoreboard players get #filo_ang ic_tmp
scoreboard players add #filo_fase ic_tmp 1
execute if score #filo_fase ic_tmp matches 20.. run scoreboard players set #filo_fase ic_tmp 0
