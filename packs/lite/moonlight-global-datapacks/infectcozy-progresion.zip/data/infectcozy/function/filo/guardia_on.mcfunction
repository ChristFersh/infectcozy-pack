# infectcozy:filo/guardia_on
# -50 % de dano recibido con el atributo puffish_attributes:resistance (mod Puffish Attributes).
# El mod lo aplica justo despues de la armadura: dano_final = dano_tras_armadura - (applyTo(d) - d),
# y un modificador add_multiplied_base de 0.5 da applyTo(d) = 1.5*d  ->  se recibe exactamente la mitad.
# Va en su propia funcion para que, si algun dia falta el mod, solo fallen estas dos lineas y no el aura.
attribute @s puffish_attributes:resistance modifier remove infectcozy:guardia_ignea
attribute @s puffish_attributes:resistance modifier add infectcozy:guardia_ignea 0.5 add_multiplied_base
