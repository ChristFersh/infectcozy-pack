# (como el jugador al tocar el suelo) onda de fuego de radio 6
tag @s remove ic_fsn
function infectcozy:filo/sent_g0
# Sin dano de caida unos ticks mas (el servidor lo cuenta al aterrizar); los demas jugadores cerca, protegidos del hechizo
scoreboard players set @s ic_fsn_t 0
tag @s add ic_fsn_f
effect give @a[distance=0.1..6,gamemode=!spectator] minecraft:resistance 2 4 true
particle minecraft:explosion_emitter ~ ~0.5 ~ 0 0 0 0 1 force
particle minecraft:lava ~ ~0.5 ~ 2.5 0.3 2.5 0 40 force
particle minecraft:campfire_cosy_smoke ~ ~0.3 ~ 2.5 0.2 2.5 0.02 20 force
particle minecraft:block{block_state:{Name:"minecraft:magma_block"}} ~ ~0.3 ~ 2.5 0.2 2.5 0 50 force
particle minecraft:flame ~2.50 ~0.2 ~0.00 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~2.50 ~0.3 ~0.00 0 0.2 0 0.02 1 force
particle minecraft:flame ~2.31 ~0.2 ~0.96 0 0.15 0 0.02 2 force
particle minecraft:flame ~1.77 ~0.2 ~1.77 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~1.77 ~0.3 ~1.77 0 0.2 0 0.02 1 force
particle minecraft:flame ~0.96 ~0.2 ~2.31 0 0.15 0 0.02 2 force
particle minecraft:flame ~0.00 ~0.2 ~2.50 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~0.00 ~0.3 ~2.50 0 0.2 0 0.02 1 force
particle minecraft:flame ~-0.96 ~0.2 ~2.31 0 0.15 0 0.02 2 force
particle minecraft:flame ~-1.77 ~0.2 ~1.77 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-1.77 ~0.3 ~1.77 0 0.2 0 0.02 1 force
particle minecraft:flame ~-2.31 ~0.2 ~0.96 0 0.15 0 0.02 2 force
particle minecraft:flame ~-2.50 ~0.2 ~0.00 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-2.50 ~0.3 ~0.00 0 0.2 0 0.02 1 force
particle minecraft:flame ~-2.31 ~0.2 ~-0.96 0 0.15 0 0.02 2 force
particle minecraft:flame ~-1.77 ~0.2 ~-1.77 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-1.77 ~0.3 ~-1.77 0 0.2 0 0.02 1 force
particle minecraft:flame ~-0.96 ~0.2 ~-2.31 0 0.15 0 0.02 2 force
particle minecraft:flame ~-0.00 ~0.2 ~-2.50 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-0.00 ~0.3 ~-2.50 0 0.2 0 0.02 1 force
particle minecraft:flame ~0.96 ~0.2 ~-2.31 0 0.15 0 0.02 2 force
particle minecraft:flame ~1.77 ~0.2 ~-1.77 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~1.77 ~0.3 ~-1.77 0 0.2 0 0.02 1 force
particle minecraft:flame ~2.31 ~0.2 ~-0.96 0 0.15 0 0.02 2 force
particle minecraft:flame ~5.00 ~0.2 ~0.00 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~5.00 ~0.3 ~0.00 0 0.2 0 0.02 1 force
particle minecraft:flame ~4.87 ~0.2 ~1.11 0 0.15 0 0.02 2 force
particle minecraft:flame ~4.50 ~0.2 ~2.17 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~4.50 ~0.3 ~2.17 0 0.2 0 0.02 1 force
particle minecraft:flame ~3.91 ~0.2 ~3.12 0 0.15 0 0.02 2 force
particle minecraft:flame ~3.12 ~0.2 ~3.91 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~3.12 ~0.3 ~3.91 0 0.2 0 0.02 1 force
particle minecraft:flame ~2.17 ~0.2 ~4.50 0 0.15 0 0.02 2 force
particle minecraft:flame ~1.11 ~0.2 ~4.87 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~1.11 ~0.3 ~4.87 0 0.2 0 0.02 1 force
particle minecraft:flame ~0.00 ~0.2 ~5.00 0 0.15 0 0.02 2 force
particle minecraft:flame ~-1.11 ~0.2 ~4.87 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-1.11 ~0.3 ~4.87 0 0.2 0 0.02 1 force
particle minecraft:flame ~-2.17 ~0.2 ~4.50 0 0.15 0 0.02 2 force
particle minecraft:flame ~-3.12 ~0.2 ~3.91 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-3.12 ~0.3 ~3.91 0 0.2 0 0.02 1 force
particle minecraft:flame ~-3.91 ~0.2 ~3.12 0 0.15 0 0.02 2 force
particle minecraft:flame ~-4.50 ~0.2 ~2.17 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-4.50 ~0.3 ~2.17 0 0.2 0 0.02 1 force
particle minecraft:flame ~-4.87 ~0.2 ~1.11 0 0.15 0 0.02 2 force
particle minecraft:flame ~-5.00 ~0.2 ~0.00 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-5.00 ~0.3 ~0.00 0 0.2 0 0.02 1 force
particle minecraft:flame ~-4.87 ~0.2 ~-1.11 0 0.15 0 0.02 2 force
particle minecraft:flame ~-4.50 ~0.2 ~-2.17 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-4.50 ~0.3 ~-2.17 0 0.2 0 0.02 1 force
particle minecraft:flame ~-3.91 ~0.2 ~-3.12 0 0.15 0 0.02 2 force
particle minecraft:flame ~-3.12 ~0.2 ~-3.91 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-3.12 ~0.3 ~-3.91 0 0.2 0 0.02 1 force
particle minecraft:flame ~-2.17 ~0.2 ~-4.50 0 0.15 0 0.02 2 force
particle minecraft:flame ~-1.11 ~0.2 ~-4.87 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~-1.11 ~0.3 ~-4.87 0 0.2 0 0.02 1 force
particle minecraft:flame ~-0.00 ~0.2 ~-5.00 0 0.15 0 0.02 2 force
particle minecraft:flame ~1.11 ~0.2 ~-4.87 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~1.11 ~0.3 ~-4.87 0 0.2 0 0.02 1 force
particle minecraft:flame ~2.17 ~0.2 ~-4.50 0 0.15 0 0.02 2 force
particle minecraft:flame ~3.12 ~0.2 ~-3.91 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~3.12 ~0.3 ~-3.91 0 0.2 0 0.02 1 force
particle minecraft:flame ~3.91 ~0.2 ~-3.12 0 0.15 0 0.02 2 force
particle minecraft:flame ~4.50 ~0.2 ~-2.17 0 0.15 0 0.02 2 force
particle minecraft:soul_fire_flame ~4.50 ~0.3 ~-2.17 0 0.2 0 0.02 1 force
particle minecraft:flame ~4.87 ~0.2 ~-1.11 0 0.15 0 0.02 2 force
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 1.5 0.6
playsound minecraft:block.anvil.land player @a ~ ~ ~ 1 0.5
playsound minecraft:entity.blaze.death player @a ~ ~ ~ 0.8 0.6
tag @s add ic_fsn_yo
tag @s add ic_fc_no
execute as @e[type=!#infectcozy:arco_ignorar,distance=..6] run function infectcozy:filo/sent_golpe
tag @s remove ic_fc_no
tag @s remove ic_fsn_yo
