# Embestida: sales disparado envuelto en fuego, girando como con Riptide (hechizo Burning Dash de Iron's Spells).
# El movimiento lo calcula el propio cliente, asi va fluido. Deja un rastro de fuego de almas. Recarga 8 s.
execute if score @s ic_fe_cd > #fq_now ic_tmp run return run function infectcozy:filo/recarga_e
scoreboard players operation @s ic_fe_cd = #fq_now ic_tmp
scoreboard players add @s ic_fe_cd 160
scoreboard players set @s ic_fe_p 0
tag @s remove ic_fe_tp
tag @s add ic_fe
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 0.8
playsound minecraft:item.trident.riptide_1 player @a ~ ~ ~ 1 0.7
particle minecraft:flame ~ ~0.5 ~ 0.4 0.2 0.4 0.08 20
function infectcozy:filo/c_embestida
