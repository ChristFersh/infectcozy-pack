# (como el jugador, tick 20 de Sentencia) Si el hechizo no arranco, picada recta como antes. Aparte porque nombra un efecto de Iron's.
execute unless predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{effects:{"irons_spellbooks:burning_dash":{}}}} run function infectcozy:filo/sent_g4
