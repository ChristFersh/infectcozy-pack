# (como una llamarada nueva) su marcador: encantamientos del Filo, dueno y 5 s de tierra calcinada
tag @s add ic_fs_v
summon minecraft:marker ~ ~ ~ {Tags:["ic_fs_m","ic_fs_nuevo"]}
data modify entity @e[type=minecraft:marker,tag=ic_fs_nuevo,limit=1,distance=..1] data.e set from storage infectcozy:enc e
scoreboard players set @e[type=minecraft:marker,tag=ic_fs_nuevo,limit=1,distance=..1] ic_fs_t 100
scoreboard players operation @e[type=minecraft:marker,tag=ic_fs_nuevo,limit=1,distance=..1] ic_fs_o = #fs_o ic_tmp
tag @e[type=minecraft:marker,tag=ic_fs_nuevo,distance=..1] remove ic_fs_nuevo
