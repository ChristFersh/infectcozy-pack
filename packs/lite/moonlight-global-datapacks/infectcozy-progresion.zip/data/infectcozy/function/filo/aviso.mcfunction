# infectcozy:filo/aviso (barra de accion solo para quien carga)
execute if score @s ic_filo_n matches 60.. run return run title @s actionbar [{"text":"Guardia ígnea","color":"gold","bold":true},{"text":" · ","color":"dark_gray"},{"text":"-50 % de daño recibido","color":"yellow"},{"text":" · ","color":"dark_gray"},{"text":"¡Carga lista!","color":"red","bold":true}]
title @s actionbar [{"text":"Guardia ígnea","color":"gold","bold":true},{"text":" · ","color":"dark_gray"},{"text":"-50 % de daño recibido","color":"yellow"}]
