# infectcozy:filo/fin (dejo de cargar: solto el clic, cambio de item, murio...)
# Solto la carga completa con el Filo en la mano: el ataque especial lleva sus encantamientos de estado
execute if score @s ic_filo_n matches 60.. if items entity @s weapon.mainhand *[minecraft:custom_data~{ic_filo:1b}] run function infectcozy:filo/especial
tag @s remove ic_filo_carga
scoreboard players reset @s ic_filo_t
scoreboard players reset @s ic_filo_n
function infectcozy:filo/guardia_off
title @s actionbar {"text":""}
particle minecraft:smoke ~ ~1 ~ 0.3 0.4 0.3 0.02 5
