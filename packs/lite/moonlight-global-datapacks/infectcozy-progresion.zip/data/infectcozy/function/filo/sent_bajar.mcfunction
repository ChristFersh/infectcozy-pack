particle minecraft:soul_fire_flame ~ ~1 ~ 0.2 0.5 0.2 0.05 6
particle minecraft:flame ~ ~1.5 ~ 0.2 0.5 0.2 0.05 4
execute unless block ~ ~-0.1 ~ #infectcozy:laser_pasa run return run function infectcozy:filo/sent_impacto
# agua o lava debajo: la onda sale aqui y caes normal
execute if block ~ ~-1 ~ minecraft:lava run return run function infectcozy:filo/sent_impacto
execute if block ~ ~-1 ~ minecraft:water run return run function infectcozy:filo/sent_impacto
execute if block ~ ~-1.6 ~ minecraft:lava run return run function infectcozy:filo/sent_impacto
execute if block ~ ~-1 ~ #infectcozy:laser_pasa if block ~ ~-1.6 ~ #infectcozy:laser_pasa run return run tp @s ~ ~-1.6 ~
execute if block ~ ~-0.5 ~ #infectcozy:laser_pasa run return run tp @s ~ ~-0.5 ~
function infectcozy:filo/sent_impacto
