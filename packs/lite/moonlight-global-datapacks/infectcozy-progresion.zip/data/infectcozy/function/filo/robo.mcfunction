# (como el dueno) Robo de vida de las llamaradas: 2 corazones por criatura, maximo 3 por ataque
scoreboard players add @s ic_frv 1
effect give @s minecraft:instant_health 1 0 true
particle minecraft:heart ~ ~2 ~ 0.3 0.2 0.3 0 2
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.3 1.8
