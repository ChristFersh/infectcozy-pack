# (como el jugador en embestida, cada tick) El impulso lo da el hechizo; aqui van el rastro y el golpe alrededor.
scoreboard players add @s ic_fe_p 1
# Si al 3er tick el hechizo no arranco (por ejemplo, estabas lanzando otro hechizo), embestida de respaldo con tp
execute if score @s ic_fe_p matches 3 unless entity @s[tag=ic_fe_tp] run function infectcozy:filo/embestida_ver
execute if entity @s[tag=ic_fe_tp] run function infectcozy:filo/embestida_tp
tag @s add ic_fe_yo
tag @s add ic_fc_no
execute at @s run function infectcozy:filo/embestida_fx
tag @s remove ic_fc_no
tag @s remove ic_fe_yo
# Los demas jugadores pegados a ti no reciben el dano del fuego del hechizo
effect give @a[distance=0.1..3.5,gamemode=!spectator] minecraft:resistance 1 4 true
execute if score @s ic_fe_p matches 16.. run return run function infectcozy:filo/embestida_fin
execute if score @s ic_fe_p matches 7.. unless entity @s[tag=ic_fe_tp] if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{flags:{is_on_ground:true}}} run function infectcozy:filo/embestida_fin
