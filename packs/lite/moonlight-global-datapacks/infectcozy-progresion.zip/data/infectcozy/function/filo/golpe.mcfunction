# infectcozy:filo/golpe (recibio dano mientras cargaba: la guardia ignea absorbe la mitad)
scoreboard players set @s ic_filo_dano 0
particle minecraft:flame ~ ~1 ~ 0.4 0.5 0.4 0.03 8
particle minecraft:lava ~ ~1 ~ 0.3 0.4 0.3 0 2
playsound minecraft:block.fire.extinguish player @a[distance=..24] ~ ~ ~ 0.35 1.8
