# infectcozy:filo/inicio (primer tick de una carga)
tag @s add ic_filo_carga
scoreboard players set @s ic_filo_n 0
scoreboard players set @s ic_filo_dano 0
function infectcozy:filo/guardia_on
playsound minecraft:item.firecharge.use player @a[distance=..24] ~ ~ ~ 0.45 1.3
particle minecraft:flame ~ ~0.1 ~ 0.5 0.05 0.5 0.02 8
function infectcozy:filo/aviso
