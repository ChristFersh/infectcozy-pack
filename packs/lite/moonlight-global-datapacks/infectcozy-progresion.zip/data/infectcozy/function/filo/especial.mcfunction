# infectcozy:filo/especial  (como el jugador que acaba de soltar el ataque cargado)
# Cada llamarada del Incinerador cercana deja "tierra calcinada" 5 s; las criaturas que alcanza reciben los
# encantamientos de estado del Filo y te curan (maximo 3 por ataque). Durante 0.8 s el Vortice las atrae.
execute unless score @s ic_id matches 1.. run scoreboard players add #siguiente ic_id 1
execute unless score @s ic_id matches 1.. run scoreboard players operation @s ic_id = #siguiente ic_id
data modify storage infectcozy:enc e set value {}
data modify storage infectcozy:enc e set from entity @s SelectedItem.components."minecraft:enchantments".levels
scoreboard players operation #fs_o ic_tmp = @s ic_id
scoreboard players set @s ic_fv 16
scoreboard players set @s ic_frv 0
execute as @e[type=cataclysm:flame_strike,distance=..24,tag=!ic_fs_v] at @s run function infectcozy:filo/fs_nuevo
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 0.6
playsound minecraft:block.respawn_anchor.deplete player @a ~ ~ ~ 0.8 0.6
particle minecraft:soul_fire_flame ~ ~1 ~ 0.6 0.4 0.6 0.08 30
