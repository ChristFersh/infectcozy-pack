# Sentencia: subes, quedas suspendido alzando la espada (hechizo Divine Smite de Iron's Spells: golpe por encima
# de la cabeza) y te lanzas en picada hacia donde apuntas; una onda de fuego lanza a los enemigos al aire. Recarga 20 s.
# La subida y la caida van con la gravedad del jugador (atributo), que calcula el propio cliente: fluido.
execute if score @s ic_fsn_cd > #fq_now ic_tmp run return run function infectcozy:filo/recarga_s
scoreboard players operation @s ic_fsn_cd = #fq_now ic_tmp
scoreboard players add @s ic_fsn_cd 400
scoreboard players set @s ic_fsn_t 0
tag @s remove ic_fsn_f
tag @s add ic_fsn
function infectcozy:filo/sent_g1
function infectcozy:filo/c_sentencia
attribute @s minecraft:generic.fall_damage_multiplier modifier remove infectcozy:sentencia
attribute @s minecraft:generic.fall_damage_multiplier modifier add infectcozy:sentencia -1 add_multiplied_total
playsound minecraft:entity.wither.shoot player @a ~ ~ ~ 0.8 0.6
playsound minecraft:item.firecharge.use player @a ~ ~ ~ 1 0.6
particle minecraft:flame ~ ~0.2 ~ 0.6 0.1 0.6 0.1 30
particle minecraft:poof ~ ~0.2 ~ 0.6 0.1 0.6 0.05 15
