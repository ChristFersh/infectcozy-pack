# infectcozy:filo/anillo (macro) $(a) = angulo 0..105, $(b) = -$(a)
# 3 llamas a la cintura (radio 1.1) y 3 llamas de almas a los pies (radio 0.8) girando en sentido contrario.
$execute rotated $(a) 0 run particle minecraft:flame ^ ^0.9 ^1.1 0 0 0 0 1
$execute rotated $(a) 0 rotated ~120 ~ run particle minecraft:flame ^ ^0.9 ^1.1 0 0 0 0 1
$execute rotated $(a) 0 rotated ~240 ~ run particle minecraft:flame ^ ^0.9 ^1.1 0 0 0 0 1
$execute rotated $(b) 0 run particle minecraft:soul_fire_flame ^ ^0.15 ^0.8 0 0 0 0 1
$execute rotated $(b) 0 rotated ~120 ~ run particle minecraft:soul_fire_flame ^ ^0.15 ^0.8 0 0 0 0 1
$execute rotated $(b) 0 rotated ~240 ~ run particle minecraft:soul_fire_flame ^ ^0.15 ^0.8 0 0 0 0 1
