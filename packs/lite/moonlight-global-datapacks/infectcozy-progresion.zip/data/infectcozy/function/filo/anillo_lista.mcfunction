# infectcozy:filo/anillo_lista (macro) corona de llamitas sobre la cabeza cuando la carga esta completa.
$execute rotated $(a) 0 rotated ~60 ~ run particle minecraft:small_flame ^ ^1.95 ^0.45 0 0 0 0 1
$execute rotated $(a) 0 rotated ~180 ~ run particle minecraft:small_flame ^ ^1.95 ^0.45 0 0 0 0 1
$execute rotated $(a) 0 rotated ~300 ~ run particle minecraft:small_flame ^ ^1.95 ^0.45 0 0 0 0 1
