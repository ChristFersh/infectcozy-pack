# (como el jugador, tick 18 de Sentencia) Altura sobre el suelo y hacia donde mira -> gravedad de la tabla; el impulso
# hacia donde apunta lo da Burning Dash (lo aplica el propio cliente: fluido, girando en llamas).
scoreboard players set #sh ic_tmp 0
execute positioned ~ ~-0.1 ~ run function infectcozy:filo/sent_alt
execute store result score #sp ic_tmp run data get entity @s Rotation[1]
function infectcozy:filo/sent_gtabla
function infectcozy:filo/c_embestida
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 0.6
playsound minecraft:item.trident.riptide_2 player @a ~ ~ ~ 1 0.8
