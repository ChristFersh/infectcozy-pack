# infectcozy:filo/barrido
# Seguridad: quita el modificador de guardia a quien no este cargando (muerte, desconexion, /reload a medias...)
# y re-habilita el avance por si alguna recompensa fallo sin revocarlo.
scoreboard players set #filo_barrido ic_tmp 0
execute as @a[tag=!ic_filo_carga] run function infectcozy:filo/guardia_off
advancement revoke @a[tag=!ic_filo_carga] only infectcozy:filo/cargando
execute as @a[tag=!ic_fsn,tag=!ic_fsn_f] run function infectcozy:filo/sent_limpiar
