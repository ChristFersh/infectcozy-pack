# infectcozy:filo/lista_fx (cada tick con la carga completa): corona y el doble de brasas.
function infectcozy:filo/anillo_lista with storage infectcozy:filo fx
execute if score #filo_ang ic_tmp matches 0 run particle minecraft:lava ~ ~0.7 ~ 0.35 0.3 0.35 0 1
execute if score #filo_ang ic_tmp matches 60 run particle minecraft:lava ~ ~0.7 ~ 0.35 0.3 0.35 0 1
