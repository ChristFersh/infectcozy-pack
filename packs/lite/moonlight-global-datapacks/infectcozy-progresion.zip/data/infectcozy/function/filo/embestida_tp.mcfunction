# (respaldo, como el jugador) 1 bloque por tick hacia delante durante 8 ticks o hasta chocar
scoreboard players set #fe_ok ic_tmp 0
execute rotated ~ 0 positioned ^ ^ ^1 if block ~ ~ ~ #infectcozy:laser_pasa if block ~ ~1 ~ #infectcozy:laser_pasa unless block ~ ~ ~ minecraft:lava unless block ~ ~-1 ~ minecraft:lava run scoreboard players set #fe_ok ic_tmp 1
execute if score #fe_ok ic_tmp matches 0 rotated ~ 0 positioned ^ ^1 ^1 if block ~ ~ ~ #infectcozy:laser_pasa if block ~ ~1 ~ #infectcozy:laser_pasa unless block ~ ~ ~ minecraft:lava unless block ~ ~-1 ~ minecraft:lava run scoreboard players set #fe_ok ic_tmp 2
execute if score #fe_ok ic_tmp matches 1 rotated ~ 0 positioned ^ ^ ^1 run tp @s ~ ~ ~
execute if score #fe_ok ic_tmp matches 2 rotated ~ 0 positioned ^ ^1 ^1 run tp @s ~ ~ ~
execute if score #fe_ok ic_tmp matches 0 run scoreboard players set @s ic_fe_p 16
execute if score @s ic_fe_p matches 11.. run scoreboard players set @s ic_fe_p 16
