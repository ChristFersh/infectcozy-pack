# (como el jugador justo despues del impacto de Sentencia, cada tick)
scoreboard players add @s ic_fsn_t 1
execute if score @s ic_fsn_t matches 12.. run function infectcozy:filo/sent_f_fin
