# (como el jugador, cada tick durante 0.8 s tras soltar la carga) atrae a las criaturas hacia la llamarada mas cercana
scoreboard players remove @s ic_fv 1
execute as @e[type=!#infectcozy:arco_ignorar,distance=..11] at @s if entity @e[type=minecraft:marker,tag=ic_fs_m,distance=1.6..10] unless entity @e[type=minecraft:marker,tag=ic_fs_m,distance=..1.6] facing entity @e[type=minecraft:marker,tag=ic_fs_m,sort=nearest,limit=1] feet run function infectcozy:filo/vortice_paso
