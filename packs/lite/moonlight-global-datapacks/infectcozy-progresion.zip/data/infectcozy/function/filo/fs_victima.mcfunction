# (como una criatura sobre la tierra calcinada)
execute on owner if entity @s[type=minecraft:player] run return 0
execute if entity @s[type=minecraft:player] run return 0
# quema: 2 de dano cada 0.5 s y fuego
execute if score #fs_q ic_tmp matches 0 if entity @a[tag=ic_fs_d] run damage @s 2 infectcozy:juicio by @a[tag=ic_fs_d,limit=1]
execute if score #fs_q ic_tmp matches 0 unless entity @a[tag=ic_fs_d] run damage @s 2 infectcozy:juicio
execute store result score #f ic_tmp run data get entity @s Fire
execute if score #f ic_tmp matches ..20 run data merge entity @s {Fire:60s}
# una vez por ataque (3 s): encantamientos de estado y robo de vida
scoreboard players operation #fs_d ic_tmp = #hh_now ic_tmp
scoreboard players operation #fs_d ic_tmp -= @s ic_fs_g
execute if score @s ic_fs_g matches -2147483648.. if score #fs_d ic_tmp matches ..59 run return 0
scoreboard players operation @s ic_fs_g = #hh_now ic_tmp
function infectcozy:encanto/golpe
particle minecraft:soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.02 8
execute as @a[tag=ic_fs_d,limit=1,scores={ic_frv=..2}] at @s run function infectcozy:filo/robo
