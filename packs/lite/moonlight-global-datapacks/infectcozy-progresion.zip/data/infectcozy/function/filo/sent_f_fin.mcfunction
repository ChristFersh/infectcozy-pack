tag @s remove ic_fsn_f
scoreboard players reset @s ic_fsn_t
attribute @s minecraft:generic.fall_damage_multiplier modifier remove infectcozy:sentencia
