# (como el jugador) 3er golpe: explosion de fuego maldito alrededor de la criatura golpeada
scoreboard players set @s ic_fc 0
title @s actionbar [{"text":"Juicio ","color":"gold"},{"text":"● ● ●","color":"dark_red","bold":true}]
tag @s add ic_fc_no
tag @s add ic_fc_yo
execute as @e[type=!#infectcozy:arco_ignorar,distance=..7,nbt={HurtTime:10s},sort=nearest,limit=1] at @s run function infectcozy:filo/combo_centro
tag @s remove ic_fc_yo
tag @s remove ic_fc_no
