summon minecraft:marker ~ ~ ~ {Tags:["ic_fe_r","ic_fe_nuevo"]}
scoreboard players set @e[type=minecraft:marker,tag=ic_fe_nuevo,limit=1,distance=..0.5] ic_fs_t 40
scoreboard players operation @e[type=minecraft:marker,tag=ic_fe_nuevo,limit=1,distance=..0.5] ic_fs_o = @s ic_id
tag @e[type=minecraft:marker,tag=ic_fe_nuevo,distance=..0.5] remove ic_fe_nuevo
particle minecraft:soul_fire_flame ~ ~0.4 ~ 0.3 0.3 0.3 0.03 10
particle minecraft:flame ~ ~0.8 ~ 0.3 0.4 0.3 0.04 8
particle minecraft:smoke ~ ~0.5 ~ 0.2 0.3 0.2 0.02 4
execute as @e[type=!#infectcozy:arco_ignorar,distance=..2.3,tag=!ic_fe_hit] run function infectcozy:filo/embestida_golpe
