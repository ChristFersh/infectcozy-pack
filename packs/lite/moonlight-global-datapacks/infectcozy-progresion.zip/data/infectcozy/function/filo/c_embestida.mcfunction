# (como el jugador) Comando de Iron's Spells en su propia funcion: si algun dia faltara el mod, solo falla esta.
cast @s irons_spellbooks:burning_dash 1
