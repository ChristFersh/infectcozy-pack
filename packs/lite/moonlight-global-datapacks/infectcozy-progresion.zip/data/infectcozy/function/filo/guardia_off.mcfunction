# infectcozy:filo/guardia_off
attribute @s puffish_attributes:resistance modifier remove infectcozy:guardia_ignea
