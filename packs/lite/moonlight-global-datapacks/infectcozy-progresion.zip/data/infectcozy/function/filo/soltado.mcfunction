# (como el item del Filo recien soltado) Si lo solto con Q desde la mano: vuelve a la mano y hace su ataque
execute on origin if entity @s[type=minecraft:player,gamemode=!spectator] run tag @s add ic_filo_lz
execute unless entity @a[tag=ic_filo_lz,limit=1] run return 0
execute as @a[tag=ic_filo_lz,limit=1] unless items entity @s weapon.mainhand * run tag @s add ic_filo_q
execute if entity @a[tag=ic_filo_q] run item replace entity @a[tag=ic_filo_q,limit=1] weapon.mainhand from entity @s contents
execute if entity @a[tag=ic_filo_q] run kill @s
execute as @a[tag=ic_filo_q,limit=1] at @s run function infectcozy:filo/q
tag @a[tag=ic_filo_lz] remove ic_filo_lz
tag @a[tag=ic_filo_q] remove ic_filo_q
