attribute @s minecraft:generic.gravity modifier remove infectcozy:sentencia
