# infectcozy:filo/cargando
# Recompensa del avance infectcozy:filo/cargando (disparador minecraft:using_item): corre cada tick
# mientras el jugador mantiene clic derecho con el Filo del Juicio. @s = jugador, posicion = sus pies.
advancement revoke @s only infectcozy:filo/cargando
execute unless entity @s[tag=ic_filo_carga] run function infectcozy:filo/inicio
scoreboard players set @s ic_filo_t 3
scoreboard players add @s ic_filo_n 1
# Aura: anillo de llamas a la cintura y anillo de fuego de almas a los pies girando al reves.
function infectcozy:filo/anillo with storage infectcozy:filo fx
# Humo cada 4 ticks y brasas cada 4 ticks (desfasados).
execute if score #filo_ang ic_tmp matches 0 run particle minecraft:smoke ~ ~0.2 ~ 0.45 0.1 0.45 0.01 1
execute if score #filo_ang ic_tmp matches 60 run particle minecraft:smoke ~ ~0.2 ~ 0.45 0.1 0.45 0.01 1
execute if score #filo_ang ic_tmp matches 30 run particle minecraft:lava ~ ~0.7 ~ 0.35 0.3 0.35 0 1
execute if score #filo_ang ic_tmp matches 90 run particle minecraft:lava ~ ~0.7 ~ 0.35 0.3 0.35 0 1
# Carga completa (60 ticks, cuando el Incinerador ya puede lanzar su ataque).
execute if score @s ic_filo_n matches 60 run function infectcozy:filo/lista
execute if score @s ic_filo_n matches 60.. run function infectcozy:filo/lista_fx
# Sonido suave una vez por segundo y aviso en la barra de accion cada medio segundo.
execute if score #filo_fase ic_tmp matches 0 run playsound minecraft:block.fire.ambient player @a[distance=..24] ~ ~ ~ 0.6 0.9
execute if score #filo_fase ic_tmp matches 0 run function infectcozy:filo/aviso
execute if score #filo_fase ic_tmp matches 10 run function infectcozy:filo/aviso
# Destello al recibir un golpe mientras la guardia esta activa.
execute if score @s ic_filo_dano matches 1.. run function infectcozy:filo/golpe
