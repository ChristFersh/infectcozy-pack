# (como el marcador de una llamarada, cada 5 ticks) tierra calcinada + estados y robo de vida (una vez por ataque)
scoreboard players remove @s ic_fs_t 5
execute if score @s ic_fs_t matches ..0 run return run kill @s
scoreboard players operation #fs_o ic_tmp = @s ic_fs_o
tag @a[tag=ic_fs_d] remove ic_fs_d
execute as @a if score @s ic_id = #fs_o ic_tmp run tag @s add ic_fs_d
tag @a[tag=ic_fs_d] add ic_fc_no
data modify storage infectcozy:enc e set from entity @s data.e
# suelo ardiendo
particle minecraft:flame ~ ~0.15 ~ 1.1 0.05 1.1 0.01 6
particle minecraft:soul_fire_flame ~ ~0.15 ~ 0.9 0.05 0.9 0.01 3
particle minecraft:lava ~ ~0.2 ~ 0.8 0 0.8 0 1
particle minecraft:smoke ~ ~0.3 ~ 0.9 0.1 0.9 0.01 3
scoreboard players operation #fs_q ic_tmp = @s ic_fs_t
scoreboard players operation #fs_q ic_tmp %= #c10 ic_tmp
execute as @e[type=!#infectcozy:arco_ignorar,distance=..2.6] run function infectcozy:filo/fs_victima
tag @a[tag=ic_fs_d] remove ic_fc_no
tag @a[tag=ic_fs_d] remove ic_fs_d
