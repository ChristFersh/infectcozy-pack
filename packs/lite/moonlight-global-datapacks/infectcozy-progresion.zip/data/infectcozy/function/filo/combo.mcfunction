# Recompensa del avance filo/golpe: golpe cuerpo a cuerpo con el Filo. El 3er golpe seguido (<3 s) estalla.
advancement revoke @s only infectcozy:filo/golpe
execute if entity @s[tag=ic_fc_no] run return 0
execute store result score #fc_now ic_tmp run time query gametime
scoreboard players operation #fc_d ic_tmp = #fc_now ic_tmp
scoreboard players operation #fc_d ic_tmp -= @s ic_fc_t
execute unless score @s ic_fc_t matches -2147483648.. run scoreboard players set @s ic_fc 0
# un barrido que alcanza a varios cuenta como un solo golpe
execute if score @s ic_fc_t matches -2147483648.. if score #fc_d ic_tmp matches 0 run return 0
execute if score #fc_d ic_tmp matches 61.. run scoreboard players set @s ic_fc 0
scoreboard players operation @s ic_fc_t = #fc_now ic_tmp
scoreboard players add @s ic_fc 1
execute if score @s ic_fc matches 1 run title @s actionbar [{"text":"Juicio ","color":"gold"},{"text":"● ","color":"red"},{"text":"○ ○","color":"dark_gray"}]
execute if score @s ic_fc matches 2 run title @s actionbar [{"text":"Juicio ","color":"gold"},{"text":"● ● ","color":"red"},{"text":"○","color":"dark_gray"}]
execute if score @s ic_fc matches 3.. run function infectcozy:filo/combo_estallido
