# (como el jugador en Sentencia) Gravedad: sube
attribute @s minecraft:generic.gravity modifier remove infectcozy:sentencia
attribute @s minecraft:generic.gravity modifier add infectcozy:sentencia -0.30 add_value
