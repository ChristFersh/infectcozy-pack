# (como una criatura, mirando a la llamarada) un paso de 0.45 bloques si no hay pared
execute on owner if entity @s[type=minecraft:player] run return 0
execute if entity @s[type=#c:bosses] run return 0
execute rotated ~ 0 positioned ^ ^ ^0.45 if block ~ ~ ~ #infectcozy:laser_pasa if block ~ ~1 ~ #infectcozy:laser_pasa run tp @s ~ ~ ~
particle minecraft:soul_fire_flame ~ ~0.6 ~ 0.25 0.3 0.25 0.01 1
