# inqui:deep_freeze  (constante: se renueva cada segundo)  #el = nivel
# constante (hacha clavada o zona del suelo): como mucho nivel V
execute if score #el ic_tmp matches 6.. run scoreboard players set #el ic_tmp 5
scoreboard players operation #ea ic_tmp = #el ic_tmp
scoreboard players operation #ea ic_tmp *= #c2 ic_enc
scoreboard players remove #ea ic_tmp 1
scoreboard players set #ed ic_tmp 3
data modify storage infectcozy:enc m.e set value "spore:frostbite"
function infectcozy:encanto/dar_s
