# tombstone:plague_bringer  (constante: se renueva cada segundo)  #el = nivel
# constante (hacha clavada o zona del suelo): como mucho nivel V
execute if score #el ic_tmp matches 6.. run scoreboard players set #el ic_tmp 5
scoreboard players operation #ea ic_tmp = #el ic_tmp
scoreboard players remove #ea ic_tmp 1
scoreboard players operation #ea ic_tmp /= #c2 ic_enc
scoreboard players set #ed ic_tmp 3
execute store result score #pr ic_tmp run random value 1..5
execute if score #pr ic_tmp matches 1 run data modify storage infectcozy:enc m.e set value "minecraft:poison"
execute if score #pr ic_tmp matches 2 run data modify storage infectcozy:enc m.e set value "minecraft:weakness"
execute if score #pr ic_tmp matches 3 run data modify storage infectcozy:enc m.e set value "minecraft:slowness"
execute if score #pr ic_tmp matches 4 run data modify storage infectcozy:enc m.e set value "minecraft:wither"
execute if score #pr ic_tmp matches 5 run data modify storage infectcozy:enc m.e set value "minecraft:blindness"
function infectcozy:encanto/dar_s
