# (como la victima) storage infectcozy:enc e = encantamientos del arma
execute if entity @s[type=minecraft:player] run return 0
execute if data storage infectcozy:enc e."minecraft:fire_aspect" store result score #el ic_tmp run data get storage infectcozy:enc e."minecraft:fire_aspect"
execute if data storage infectcozy:enc e."minecraft:fire_aspect" run function infectcozy:encanto/c/fuego
execute if data storage infectcozy:enc e."minecraft:flame" store result score #el ic_tmp run data get storage infectcozy:enc e."minecraft:flame"
execute if data storage infectcozy:enc e."minecraft:flame" run function infectcozy:encanto/c/llama
execute if data storage infectcozy:enc e."minecraft:bane_of_arthropods" store result score #el ic_tmp run data get storage infectcozy:enc e."minecraft:bane_of_arthropods"
execute if data storage infectcozy:enc e."minecraft:bane_of_arthropods" run function infectcozy:encanto/c/artropodos
execute if data storage infectcozy:enc e."tombstone:decrepitude" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:decrepitude"
execute if data storage infectcozy:enc e."tombstone:decrepitude" run function infectcozy:encanto/c/decrepitud
execute if data storage infectcozy:enc e."tombstone:frostbite" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:frostbite"
execute if data storage infectcozy:enc e."tombstone:frostbite" run function infectcozy:encanto/c/congelacion
execute if data storage infectcozy:enc e."tombstone:incurable_wounds" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:incurable_wounds"
execute if data storage infectcozy:enc e."tombstone:incurable_wounds" run function infectcozy:encanto/c/incurable
execute if data storage infectcozy:enc e."tombstone:plague_bringer" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:plague_bringer"
execute if data storage infectcozy:enc e."tombstone:plague_bringer" run function infectcozy:encanto/c/plaga
execute if data storage infectcozy:enc e."spore:corrosive_potency" store result score #el ic_tmp run data get storage infectcozy:enc e."spore:corrosive_potency"
execute if data storage infectcozy:enc e."spore:corrosive_potency" run function infectcozy:encanto/c/corrosion
execute if data storage infectcozy:enc e."spore:cryogenic_aspect" store result score #el ic_tmp run data get storage infectcozy:enc e."spore:cryogenic_aspect"
execute if data storage infectcozy:enc e."spore:cryogenic_aspect" run function infectcozy:encanto/c/criogenico
execute if data storage infectcozy:enc e."spore:gastric_spewage" store result score #el ic_tmp run data get storage infectcozy:enc e."spore:gastric_spewage"
execute if data storage infectcozy:enc e."spore:gastric_spewage" run function infectcozy:encanto/c/bilis
execute if data storage infectcozy:enc e."inqui:deep_freeze" store result score #el ic_tmp run data get storage infectcozy:enc e."inqui:deep_freeze"
execute if data storage infectcozy:enc e."inqui:deep_freeze" run function infectcozy:encanto/c/ultracongelacion
execute if data storage infectcozy:enc e."inqui:soul_freeze" store result score #el ic_tmp run data get storage infectcozy:enc e."inqui:soul_freeze"
execute if data storage infectcozy:enc e."inqui:soul_freeze" run function infectcozy:encanto/c/alma_helada
execute if data storage infectcozy:enc e."nova_structures:wither_coated" store result score #el ic_tmp run data get storage infectcozy:enc e."nova_structures:wither_coated"
execute if data storage infectcozy:enc e."nova_structures:wither_coated" run function infectcozy:encanto/c/marchitez
