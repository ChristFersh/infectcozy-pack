# tombstone:plague_bringer  (un golpe)  #el = nivel
scoreboard players operation #ea ic_tmp = #el ic_tmp
scoreboard players remove #ea ic_tmp 1
scoreboard players operation #ea ic_tmp /= #c2 ic_enc
scoreboard players operation #ed ic_tmp = #el ic_tmp
scoreboard players operation #ed ic_tmp *= #c2 ic_enc
execute store result score #pr ic_tmp run random value 1..5
execute if score #pr ic_tmp matches 1 run data modify storage infectcozy:enc m.e set value "minecraft:poison"
execute if score #pr ic_tmp matches 2 run data modify storage infectcozy:enc m.e set value "minecraft:weakness"
execute if score #pr ic_tmp matches 3 run data modify storage infectcozy:enc m.e set value "minecraft:slowness"
execute if score #pr ic_tmp matches 4 run data modify storage infectcozy:enc m.e set value "minecraft:wither"
execute if score #pr ic_tmp matches 5 run data modify storage infectcozy:enc m.e set value "minecraft:blindness"
function infectcozy:encanto/dar_s
