$execute store result score #i ic_tmp run random value 0..$(max)
