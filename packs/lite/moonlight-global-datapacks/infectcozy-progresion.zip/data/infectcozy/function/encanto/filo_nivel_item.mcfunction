# (como un item_display) #sh = nivel de Filo del objeto que muestra
scoreboard players set #sh ic_tmp 0
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:1}]] run scoreboard players set #sh ic_tmp 1
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:2}]] run scoreboard players set #sh ic_tmp 2
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:3}]] run scoreboard players set #sh ic_tmp 3
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:4}]] run scoreboard players set #sh ic_tmp 4
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:5}]] run scoreboard players set #sh ic_tmp 5
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:{min:6}}]] run scoreboard players set #sh ic_tmp 6
