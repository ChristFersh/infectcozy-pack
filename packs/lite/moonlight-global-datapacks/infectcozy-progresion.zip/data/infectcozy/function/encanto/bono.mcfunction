# (como la victima) #bono = dano extra por encantamientos del arma (#e_sh, #e_sm, #e_ba, #e_im = niveles)
#  Filo: +3 por nivel contra todo. Castigo: +3 por nivel contra no-muertos.
#  Perdicion de los artropodos: +3 por nivel contra artropodos. Empalamiento: +3 por nivel contra criaturas acuaticas.
scoreboard players set #c3s ic_tmp 3
scoreboard players operation #bono ic_tmp = #e_sh ic_tmp
execute if entity @s[type=#minecraft:sensitive_to_smite] run scoreboard players operation #bono ic_tmp += #e_sm ic_tmp
execute if entity @s[type=#minecraft:sensitive_to_bane_of_arthropods] run scoreboard players operation #bono ic_tmp += #e_ba ic_tmp
execute if entity @s[type=#minecraft:sensitive_to_impaling] run scoreboard players operation #bono ic_tmp += #e_im ic_tmp
scoreboard players operation #bono ic_tmp *= #c3s ic_tmp
