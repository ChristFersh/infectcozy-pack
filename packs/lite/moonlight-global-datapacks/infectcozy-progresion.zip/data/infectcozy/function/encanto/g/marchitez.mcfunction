# nova_structures:wither_coated  (un golpe)  #el = nivel
scoreboard players set #ea ic_tmp 0
scoreboard players set #ed ic_tmp 9
data modify storage infectcozy:enc m.e set value "minecraft:wither"
function infectcozy:encanto/dar_s
