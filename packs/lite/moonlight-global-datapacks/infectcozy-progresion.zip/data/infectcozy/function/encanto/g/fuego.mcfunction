# minecraft:fire_aspect  (un golpe)  #el = nivel
execute if score #el ic_tmp matches 1 run data merge entity @s {Fire:80s}
execute if score #el ic_tmp matches 2 run data merge entity @s {Fire:160s}
execute if score #el ic_tmp matches 3 run data merge entity @s {Fire:240s}
execute if score #el ic_tmp matches 4 run data merge entity @s {Fire:320s}
execute if score #el ic_tmp matches 5 run data merge entity @s {Fire:400s}
execute if score #el ic_tmp matches 6 run data merge entity @s {Fire:480s}
execute if score #el ic_tmp matches 7 run data merge entity @s {Fire:560s}
execute if score #el ic_tmp matches 8 run data merge entity @s {Fire:640s}
execute if score #el ic_tmp matches 9 run data merge entity @s {Fire:720s}
execute if score #el ic_tmp matches 10.. run data merge entity @s {Fire:800s}
