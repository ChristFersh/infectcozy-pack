# tombstone:decrepitude  (un golpe)  #el = nivel
scoreboard players operation #ea ic_tmp = #el ic_tmp
scoreboard players remove #ea ic_tmp 1
scoreboard players operation #ed ic_tmp = #el ic_tmp
scoreboard players operation #ed ic_tmp *= #c2 ic_enc
data modify storage infectcozy:enc m.e set value "tombstone:decrepitude"
function infectcozy:encanto/dar_s
