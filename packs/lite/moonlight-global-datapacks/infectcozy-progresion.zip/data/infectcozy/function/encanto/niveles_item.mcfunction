# (como un item_display) los mismos niveles, del objeto que muestra
scoreboard players set #e_sh ic_tmp 0
scoreboard players set #e_sm ic_tmp 0
scoreboard players set #e_ba ic_tmp 0
scoreboard players set #e_im ic_tmp 0
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:1}]] run scoreboard players set #e_sh ic_tmp 1
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:2}]] run scoreboard players set #e_sh ic_tmp 2
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:3}]] run scoreboard players set #e_sh ic_tmp 3
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:4}]] run scoreboard players set #e_sh ic_tmp 4
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:5}]] run scoreboard players set #e_sh ic_tmp 5
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:{min:6}}]] run scoreboard players set #e_sh ic_tmp 6
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:smite",levels:1}]] run scoreboard players set #e_sm ic_tmp 1
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:smite",levels:2}]] run scoreboard players set #e_sm ic_tmp 2
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:smite",levels:3}]] run scoreboard players set #e_sm ic_tmp 3
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:smite",levels:4}]] run scoreboard players set #e_sm ic_tmp 4
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:smite",levels:5}]] run scoreboard players set #e_sm ic_tmp 5
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:smite",levels:{min:6}}]] run scoreboard players set #e_sm ic_tmp 6
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:bane_of_arthropods",levels:1}]] run scoreboard players set #e_ba ic_tmp 1
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:bane_of_arthropods",levels:2}]] run scoreboard players set #e_ba ic_tmp 2
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:bane_of_arthropods",levels:3}]] run scoreboard players set #e_ba ic_tmp 3
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:bane_of_arthropods",levels:4}]] run scoreboard players set #e_ba ic_tmp 4
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:bane_of_arthropods",levels:5}]] run scoreboard players set #e_ba ic_tmp 5
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:bane_of_arthropods",levels:{min:6}}]] run scoreboard players set #e_ba ic_tmp 6
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:impaling",levels:1}]] run scoreboard players set #e_im ic_tmp 1
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:impaling",levels:2}]] run scoreboard players set #e_im ic_tmp 2
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:impaling",levels:3}]] run scoreboard players set #e_im ic_tmp 3
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:impaling",levels:4}]] run scoreboard players set #e_im ic_tmp 4
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:impaling",levels:5}]] run scoreboard players set #e_im ic_tmp 5
execute if items entity @s contents *[minecraft:enchantments~[{enchantments:"minecraft:impaling",levels:{min:6}}]] run scoreboard players set #e_im ic_tmp 6
