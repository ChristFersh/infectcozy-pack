# spore:cryogenic_aspect  (un golpe)  #el = nivel
scoreboard players set #ea ic_tmp 0
scoreboard players set #ed ic_tmp 6
data modify storage infectcozy:enc m.e set value "spore:frostbite"
function infectcozy:encanto/dar_s
scoreboard players set #ea ic_tmp 0
scoreboard players set #ed ic_tmp 6
data modify storage infectcozy:enc m.e set value "minecraft:slowness"
function infectcozy:encanto/dar_s
