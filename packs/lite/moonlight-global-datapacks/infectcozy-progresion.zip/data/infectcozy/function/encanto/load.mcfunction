scoreboard objectives add ic_enc dummy
scoreboard objectives add ic_tmp dummy
scoreboard objectives add ic_hh_ec dummy
scoreboard objectives add ic_hh_el dummy
scoreboard objectives add ic_fs_g dummy
scoreboard objectives add ic_fs_t dummy
scoreboard players set #c2 ic_enc 2
scoreboard players set #c3 ic_enc 3
scoreboard players set #c5 ic_enc 5
scoreboard players set #c8 ic_enc 8
scoreboard players set #c4 ic_enc 4
