execute if score #ea ic_tmp matches ..-1 run scoreboard players set #ea ic_tmp 0
execute if score #ea ic_tmp matches 256.. run scoreboard players set #ea ic_tmp 255
execute if score #ed ic_tmp matches ..0 run scoreboard players set #ed ic_tmp 1
execute store result storage infectcozy:enc m.a int 1 run scoreboard players get #ea ic_tmp
execute store result storage infectcozy:enc m.d int 1 run scoreboard players get #ed ic_tmp
function infectcozy:encanto/dar with storage infectcozy:enc m
