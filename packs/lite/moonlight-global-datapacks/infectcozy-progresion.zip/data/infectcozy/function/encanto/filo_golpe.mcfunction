# MACRO (como la victima): $(b) dano base, $(t) tag del atacante, $(ty) tipo de dano.
# Suma el bono de encantamientos de dano del arma que el atacante tiene en la mano (ver encanto/bono).
scoreboard players set #e_sh ic_tmp 0
scoreboard players set #e_sm ic_tmp 0
scoreboard players set #e_ba ic_tmp 0
scoreboard players set #e_im ic_tmp 0
$execute as @a[tag=$(t),limit=1] run function infectcozy:encanto/niveles_mano
function infectcozy:encanto/bono
scoreboard players operation #shd ic_tmp = #bono ic_tmp
$scoreboard players add #shd ic_tmp $(b)
execute store result storage infectcozy:sh d int 1 run scoreboard players get #shd ic_tmp
$data modify storage infectcozy:sh t set value "$(t)"
$data modify storage infectcozy:sh ty set value "$(ty)"
function infectcozy:encanto/dano with storage infectcozy:sh
