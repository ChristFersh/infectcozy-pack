# (como una criatura en la zona helada) #enc_c = estado elegido, #el = su nivel
execute if entity @s[type=minecraft:player] run return 0
execute if score #enc_c ic_tmp matches 1 run function infectcozy:encanto/c/fuego
execute if score #enc_c ic_tmp matches 2 run function infectcozy:encanto/c/llama
execute if score #enc_c ic_tmp matches 3 run function infectcozy:encanto/c/artropodos
execute if score #enc_c ic_tmp matches 4 run function infectcozy:encanto/c/decrepitud
execute if score #enc_c ic_tmp matches 5 run function infectcozy:encanto/c/congelacion
execute if score #enc_c ic_tmp matches 6 run function infectcozy:encanto/c/incurable
execute if score #enc_c ic_tmp matches 7 run function infectcozy:encanto/c/plaga
execute if score #enc_c ic_tmp matches 8 run function infectcozy:encanto/c/corrosion
execute if score #enc_c ic_tmp matches 9 run function infectcozy:encanto/c/criogenico
execute if score #enc_c ic_tmp matches 10 run function infectcozy:encanto/c/bilis
execute if score #enc_c ic_tmp matches 11 run function infectcozy:encanto/c/ultracongelacion
execute if score #enc_c ic_tmp matches 12 run function infectcozy:encanto/c/alma_helada
execute if score #enc_c ic_tmp matches 13 run function infectcozy:encanto/c/marchitez
