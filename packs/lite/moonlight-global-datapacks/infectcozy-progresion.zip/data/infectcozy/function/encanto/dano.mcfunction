# MACRO (como la victima)
$damage @s $(d) $(ty) by @a[tag=$(t),limit=1]
