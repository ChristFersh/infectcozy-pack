# minecraft:bane_of_arthropods  (un golpe)  #el = nivel
execute unless entity @s[type=#minecraft:sensitive_to_bane_of_arthropods] run return 0
scoreboard players set #ea ic_tmp 3
scoreboard players operation #ed ic_tmp = #el ic_tmp
scoreboard players operation #ed ic_tmp /= #c2 ic_enc
scoreboard players add #ed ic_tmp 1
data modify storage infectcozy:enc m.e set value "minecraft:slowness"
function infectcozy:encanto/dar_s
