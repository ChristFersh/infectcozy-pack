# inqui:soul_freeze  (un golpe)  #el = nivel
scoreboard players operation #ea ic_tmp = #el ic_tmp
scoreboard players operation #ea ic_tmp *= #c2 ic_enc
scoreboard players remove #ea ic_tmp 1
scoreboard players set #ed ic_tmp 4
data modify storage infectcozy:enc m.e set value "spore:frostbite"
function infectcozy:encanto/dar_s
