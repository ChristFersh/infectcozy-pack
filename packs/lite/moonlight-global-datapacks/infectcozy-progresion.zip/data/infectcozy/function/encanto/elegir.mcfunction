# (como el hacha) elige 1 estado al azar entre sus encantamientos -> @s ic_hh_ec (codigo) e ic_hh_el (nivel)
scoreboard players set @s ic_hh_ec 0
scoreboard players set @s ic_hh_el 0
data modify storage infectcozy:enc lista set value []
execute if data storage infectcozy:enc e."minecraft:fire_aspect" run data modify storage infectcozy:enc lista append value 1
execute if data storage infectcozy:enc e."minecraft:flame" run data modify storage infectcozy:enc lista append value 2
execute if data storage infectcozy:enc e."minecraft:bane_of_arthropods" run data modify storage infectcozy:enc lista append value 3
execute if data storage infectcozy:enc e."tombstone:decrepitude" run data modify storage infectcozy:enc lista append value 4
execute if data storage infectcozy:enc e."tombstone:frostbite" run data modify storage infectcozy:enc lista append value 5
execute if data storage infectcozy:enc e."tombstone:incurable_wounds" run data modify storage infectcozy:enc lista append value 6
execute if data storage infectcozy:enc e."tombstone:plague_bringer" run data modify storage infectcozy:enc lista append value 7
execute if data storage infectcozy:enc e."spore:corrosive_potency" run data modify storage infectcozy:enc lista append value 8
execute if data storage infectcozy:enc e."spore:cryogenic_aspect" run data modify storage infectcozy:enc lista append value 9
execute if data storage infectcozy:enc e."spore:gastric_spewage" run data modify storage infectcozy:enc lista append value 10
execute if data storage infectcozy:enc e."inqui:deep_freeze" run data modify storage infectcozy:enc lista append value 11
execute if data storage infectcozy:enc e."inqui:soul_freeze" run data modify storage infectcozy:enc lista append value 12
execute if data storage infectcozy:enc e."nova_structures:wither_coated" run data modify storage infectcozy:enc lista append value 13
execute store result score #n ic_tmp run data get storage infectcozy:enc lista
execute if score #n ic_tmp matches 0 run return 0
scoreboard players set #i ic_tmp 0
scoreboard players remove #n ic_tmp 1
execute store result storage infectcozy:enc r.max int 1 run scoreboard players get #n ic_tmp
execute if score #n ic_tmp matches 1.. run function infectcozy:encanto/azar with storage infectcozy:enc r
execute store result storage infectcozy:enc r.i int 1 run scoreboard players get #i ic_tmp
function infectcozy:encanto/tomar with storage infectcozy:enc r
execute if score @s ic_hh_ec matches 1 store result score @s ic_hh_el run data get storage infectcozy:enc e."minecraft:fire_aspect"
execute if score @s ic_hh_ec matches 1 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.minecraft.fire_aspect","color":"light_purple"}]
execute if score @s ic_hh_ec matches 2 store result score @s ic_hh_el run data get storage infectcozy:enc e."minecraft:flame"
execute if score @s ic_hh_ec matches 2 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.minecraft.flame","color":"light_purple"}]
execute if score @s ic_hh_ec matches 3 store result score @s ic_hh_el run data get storage infectcozy:enc e."minecraft:bane_of_arthropods"
execute if score @s ic_hh_ec matches 3 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.minecraft.bane_of_arthropods","color":"light_purple"}]
execute if score @s ic_hh_ec matches 4 store result score @s ic_hh_el run data get storage infectcozy:enc e."tombstone:decrepitude"
execute if score @s ic_hh_ec matches 4 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.tombstone.decrepitude","color":"light_purple"}]
execute if score @s ic_hh_ec matches 5 store result score @s ic_hh_el run data get storage infectcozy:enc e."tombstone:frostbite"
execute if score @s ic_hh_ec matches 5 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.tombstone.frostbite","color":"light_purple"}]
execute if score @s ic_hh_ec matches 6 store result score @s ic_hh_el run data get storage infectcozy:enc e."tombstone:incurable_wounds"
execute if score @s ic_hh_ec matches 6 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.tombstone.incurable_wounds","color":"light_purple"}]
execute if score @s ic_hh_ec matches 7 store result score @s ic_hh_el run data get storage infectcozy:enc e."tombstone:plague_bringer"
execute if score @s ic_hh_ec matches 7 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.tombstone.plague_bringer","color":"light_purple"}]
execute if score @s ic_hh_ec matches 8 store result score @s ic_hh_el run data get storage infectcozy:enc e."spore:corrosive_potency"
execute if score @s ic_hh_ec matches 8 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.spore.corrosive_potency","color":"light_purple"}]
execute if score @s ic_hh_ec matches 9 store result score @s ic_hh_el run data get storage infectcozy:enc e."spore:cryogenic_aspect"
execute if score @s ic_hh_ec matches 9 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.spore.cryogenic_aspect","color":"light_purple"}]
execute if score @s ic_hh_ec matches 10 store result score @s ic_hh_el run data get storage infectcozy:enc e."spore:gastric_spewage"
execute if score @s ic_hh_ec matches 10 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.spore.gastric_spewage","color":"light_purple"}]
execute if score @s ic_hh_ec matches 11 store result score @s ic_hh_el run data get storage infectcozy:enc e."inqui:deep_freeze"
execute if score @s ic_hh_ec matches 11 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.inqui.deep_freeze","color":"light_purple"}]
execute if score @s ic_hh_ec matches 12 store result score @s ic_hh_el run data get storage infectcozy:enc e."inqui:soul_freeze"
execute if score @s ic_hh_ec matches 12 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.inqui.soul_freeze","color":"light_purple"}]
execute if score @s ic_hh_ec matches 13 store result score @s ic_hh_el run data get storage infectcozy:enc e."nova_structures:wither_coated"
execute if score @s ic_hh_ec matches 13 run title @a[tag=ic_hh_d] actionbar [{"text":"❄ Zona helada + ","color":"aqua"},{"translate":"enchantment.nova_structures.wither_coated","color":"light_purple"}]
