# spore:gastric_spewage  (un golpe)  #el = nivel
scoreboard players set #ea ic_tmp 0
scoreboard players set #ed ic_tmp 6
data modify storage infectcozy:enc m.e set value "spore:biled"
function infectcozy:encanto/dar_s
