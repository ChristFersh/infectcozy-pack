$execute store result score @s ic_hh_ec run data get storage infectcozy:enc lista[$(i)]
