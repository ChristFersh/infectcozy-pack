$effect give @s $(e) $(d) $(a)
