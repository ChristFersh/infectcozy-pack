# minecraft:fire_aspect  (constante: se renueva cada segundo)  #el = nivel
# constante (hacha clavada o zona del suelo): como mucho nivel V
execute if score #el ic_tmp matches 6.. run scoreboard players set #el ic_tmp 5
execute store result score #f ic_tmp run data get entity @s Fire
execute if score #f ic_tmp matches ..20 run data merge entity @s {Fire:100s}
