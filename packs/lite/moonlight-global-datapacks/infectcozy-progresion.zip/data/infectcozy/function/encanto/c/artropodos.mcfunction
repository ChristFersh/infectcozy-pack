# minecraft:bane_of_arthropods  (constante: se renueva cada segundo)  #el = nivel
# constante (hacha clavada o zona del suelo): como mucho nivel V
execute if score #el ic_tmp matches 6.. run scoreboard players set #el ic_tmp 5
execute unless entity @s[type=#minecraft:sensitive_to_bane_of_arthropods] run return 0
scoreboard players set #ea ic_tmp 3
scoreboard players set #ed ic_tmp 3
data modify storage infectcozy:enc m.e set value "minecraft:slowness"
function infectcozy:encanto/dar_s
