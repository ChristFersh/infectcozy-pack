# spore:cryogenic_aspect  (constante: se renueva cada segundo)  #el = nivel
# constante (hacha clavada o zona del suelo): como mucho nivel V
execute if score #el ic_tmp matches 6.. run scoreboard players set #el ic_tmp 5
scoreboard players set #ea ic_tmp 0
scoreboard players set #ed ic_tmp 3
data modify storage infectcozy:enc m.e set value "spore:frostbite"
function infectcozy:encanto/dar_s
scoreboard players set #ea ic_tmp 0
scoreboard players set #ed ic_tmp 3
data modify storage infectcozy:enc m.e set value "minecraft:slowness"
function infectcozy:encanto/dar_s
