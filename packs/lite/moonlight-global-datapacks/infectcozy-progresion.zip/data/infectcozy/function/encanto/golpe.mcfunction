# (como la victima) storage infectcozy:enc e = encantamientos del arma
execute if entity @s[type=minecraft:player] run return 0
execute if data storage infectcozy:enc e."minecraft:fire_aspect" store result score #el ic_tmp run data get storage infectcozy:enc e."minecraft:fire_aspect"
execute if data storage infectcozy:enc e."minecraft:fire_aspect" run function infectcozy:encanto/g/fuego
execute if data storage infectcozy:enc e."minecraft:flame" store result score #el ic_tmp run data get storage infectcozy:enc e."minecraft:flame"
execute if data storage infectcozy:enc e."minecraft:flame" run function infectcozy:encanto/g/llama
execute if data storage infectcozy:enc e."minecraft:bane_of_arthropods" store result score #el ic_tmp run data get storage infectcozy:enc e."minecraft:bane_of_arthropods"
execute if data storage infectcozy:enc e."minecraft:bane_of_arthropods" run function infectcozy:encanto/g/artropodos
execute if data storage infectcozy:enc e."tombstone:decrepitude" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:decrepitude"
execute if data storage infectcozy:enc e."tombstone:decrepitude" run function infectcozy:encanto/g/decrepitud
execute if data storage infectcozy:enc e."tombstone:frostbite" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:frostbite"
execute if data storage infectcozy:enc e."tombstone:frostbite" run function infectcozy:encanto/g/congelacion
execute if data storage infectcozy:enc e."tombstone:incurable_wounds" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:incurable_wounds"
execute if data storage infectcozy:enc e."tombstone:incurable_wounds" run function infectcozy:encanto/g/incurable
execute if data storage infectcozy:enc e."tombstone:plague_bringer" store result score #el ic_tmp run data get storage infectcozy:enc e."tombstone:plague_bringer"
execute if data storage infectcozy:enc e."tombstone:plague_bringer" run function infectcozy:encanto/g/plaga
execute if data storage infectcozy:enc e."spore:corrosive_potency" store result score #el ic_tmp run data get storage infectcozy:enc e."spore:corrosive_potency"
execute if data storage infectcozy:enc e."spore:corrosive_potency" run function infectcozy:encanto/g/corrosion
execute if data storage infectcozy:enc e."spore:cryogenic_aspect" store result score #el ic_tmp run data get storage infectcozy:enc e."spore:cryogenic_aspect"
execute if data storage infectcozy:enc e."spore:cryogenic_aspect" run function infectcozy:encanto/g/criogenico
execute if data storage infectcozy:enc e."spore:gastric_spewage" store result score #el ic_tmp run data get storage infectcozy:enc e."spore:gastric_spewage"
execute if data storage infectcozy:enc e."spore:gastric_spewage" run function infectcozy:encanto/g/bilis
execute if data storage infectcozy:enc e."inqui:deep_freeze" store result score #el ic_tmp run data get storage infectcozy:enc e."inqui:deep_freeze"
execute if data storage infectcozy:enc e."inqui:deep_freeze" run function infectcozy:encanto/g/ultracongelacion
execute if data storage infectcozy:enc e."inqui:soul_freeze" store result score #el ic_tmp run data get storage infectcozy:enc e."inqui:soul_freeze"
execute if data storage infectcozy:enc e."inqui:soul_freeze" run function infectcozy:encanto/g/alma_helada
execute if data storage infectcozy:enc e."nova_structures:wither_coated" store result score #el ic_tmp run data get storage infectcozy:enc e."nova_structures:wither_coated"
execute if data storage infectcozy:enc e."nova_structures:wither_coated" run function infectcozy:encanto/g/marchitez
