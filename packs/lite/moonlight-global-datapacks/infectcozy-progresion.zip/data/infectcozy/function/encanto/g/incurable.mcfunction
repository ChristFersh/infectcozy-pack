# tombstone:incurable_wounds  (un golpe)  #el = nivel
scoreboard players operation #ea ic_tmp = #el ic_tmp
scoreboard players remove #ea ic_tmp 1
scoreboard players operation #ed ic_tmp = #el ic_tmp
scoreboard players operation #ed ic_tmp *= #c2 ic_enc
scoreboard players add #ed ic_tmp 3
data modify storage infectcozy:enc m.e set value "tombstone:incurable"
function infectcozy:encanto/dar_s
