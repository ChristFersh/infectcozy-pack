# minecraft:flame  (un golpe)  #el = nivel
execute if score #el ic_tmp matches 1 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 2 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 3 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 4 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 5 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 6 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 7 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 8 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 9 run data merge entity @s {Fire:100s}
execute if score #el ic_tmp matches 10.. run data merge entity @s {Fire:100s}
