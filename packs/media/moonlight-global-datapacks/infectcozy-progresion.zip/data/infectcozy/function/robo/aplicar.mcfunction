# infectcozy:robo/aplicar  (as + at jugador). Entrada: #t_dmg ic_robo = dano x10 de UN golpe directo.
execute if score #t_dmg ic_robo matches ..0 run return fail
# Set completo obligatorio
execute unless items entity @s armor.head *[minecraft:custom_data~{ic_amanecer:1b}] run return fail
execute unless items entity @s armor.chest *[minecraft:custom_data~{ic_amanecer:1b}] run return fail
execute unless items entity @s armor.legs *[minecraft:custom_data~{ic_amanecer:1b}] run return fail
execute unless items entity @s armor.feet *[minecraft:custom_data~{ic_amanecer:1b}] run return fail
# Muerto o con la vida llena: nada que curar (tampoco se acumula acarreo)
execute store result score #t_vida ic_robo run data get entity @s Health 10
execute if score #t_vida ic_robo matches ..0 run return fail
execute store result score #t_vmax ic_robo run attribute @s minecraft:generic.max_health get 10
execute if score #t_vida ic_robo >= #t_vmax ic_robo run return fail
# cura_decimas = min(dano_decimas / 10, 30)  -> 10 %, tope 3 HP
scoreboard players operation #t_cura ic_robo = #t_dmg ic_robo
scoreboard players operation #t_cura ic_robo /= #10 ic_robo
scoreboard players operation #t_cura ic_robo < #30 ic_robo
# Acarreo de decimas: se cura en HP enteros y el sobrante (0..9 decimas) pasa al siguiente golpe.
# Maximo por golpe: (30 + 9) / 10 = 3 HP.
scoreboard players add @s ic_robo_resto 0
scoreboard players operation #t_cura ic_robo += @s ic_robo_resto
scoreboard players operation @s ic_robo_resto = #t_cura ic_robo
scoreboard players operation @s ic_robo_resto %= #10 ic_robo
scoreboard players operation #t_cura ic_robo /= #10 ic_robo
execute if score #t_cura ic_robo matches ..0 run return 0
function infectcozy:robo/curar
