# Como el tridente, en el punto de impacto. Furia del Abismo: onda de 150 de dano verdadero en radio 5
# (la criatura acertada ya recibio los suyos en golpe). Efecto purpura propio.
execute as @e[type=!#infectcozy:arco_ignorar,distance=..5,tag=!ic_tri_obj] at @s run function infectcozy:tridente/furia_area
particle minecraft:flash ~ ~0.5 ~ 0 0 0 0 1 force
particle minecraft:explosion_emitter ~ ~0.5 ~ 0 0 0 0 1 force
particle minecraft:dragon_breath ~ ~0.5 ~ 2.5 0.6 2.5 0.05 160 force
particle minecraft:reverse_portal ~ ~1 ~ 2 1.5 2 0.6 150 force
particle minecraft:witch ~ ~1 ~ 2.5 1 2.5 0.3 80 force
particle minecraft:dust{color:[0.72,0.15,1.0],scale:3.0} ~ ~0.5 ~ 3 0.8 3 0 120 force
particle minecraft:dust{color:[0.85,0.45,1.0],scale:1.6} ~ ~3 ~ 0.15 3 0.15 0 70 force
function infectcozy:tridente/anillo_furia
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 2.5 0.6
playsound minecraft:block.end_portal.spawn player @a ~ ~ ~ 0.9 1.6
playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 2 0.5
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 2 0.7
title @a[tag=ic_dueno,limit=1] actionbar [{"text":"¡FURIA DEL ABISMO! ","color":"light_purple","bold":true},{"text":"150 de daño verdadero (jefes: 6 % de su vida)","color":"dark_purple"}]
