# Como la victima. Furia del Abismo: dano verdadero (ignora armadura, resistencias e invulnerabilidad).
#  - Criaturas normales: 150.
#  - Jefes (#c:bosses): el 6 % de su vida maxima, como mucho 150 (se salta sus topes de dano).
# 1) Golpe del lanzador por esa cantidad (credito del kill y botin).
# 2) Si perdio menos (topes de dano, resistencias...), se le resta la diferencia directamente.
# 3) Si con eso moriria, se la deja a 1 de vida y se remata con 1 de dano del lanzador.
execute unless data entity @s Health run return 0
execute if entity @s[nbt={Invulnerable:1b}] run return 0
execute store result score #f_h0 ic_tmp run data get entity @s Health 100
particle minecraft:witch ~ ~1 ~ 0.4 0.8 0.4 0.2 25 force
particle minecraft:dust{color:[0.72,0.15,1.0],scale:1.8} ~ ~1 ~ 0.4 0.8 0.4 0 25 force
particle minecraft:reverse_portal ~ ~1 ~ 0.3 0.6 0.3 0.4 30 force
# Cantidad (x100): 15000, o el 6 % de la vida maxima si es jefe
scoreboard players set #f_q ic_tmp 15000
execute if entity @s[type=#c:bosses] store result score #f_q ic_tmp run attribute @s minecraft:generic.max_health get 6
execute if score #f_q ic_tmp matches 15001.. run scoreboard players set #f_q ic_tmp 15000
execute if score #f_q ic_tmp matches ..99 run scoreboard players set #f_q ic_tmp 100
scoreboard players operation #f_d ic_tmp = #f_q ic_tmp
scoreboard players operation #f_d ic_tmp /= #c100 ic_tmp
execute store result storage infectcozy:tri f.d int 1 run scoreboard players get #f_d ic_tmp
scoreboard players set #tri_ok ic_tmp 0
function infectcozy:tridente/dano_var with storage infectcozy:tri f
execute if score #tri_ok ic_tmp matches 0 run function infectcozy:tridente/dano_var_alt with storage infectcozy:tri f
execute store result score #f_h1 ic_tmp run data get entity @s Health 100
execute if score #f_h1 ic_tmp matches ..0 run return 1
# Los munecos de prueba (Target Dummy) no pierden vida: se quedan con el numero del golpe, sin corregir.
execute if entity @s[type=#infectcozy:furia_sin_correccion] run return 1
scoreboard players operation #f_h2 ic_tmp = #f_h0 ic_tmp
scoreboard players operation #f_h2 ic_tmp -= #f_q ic_tmp
execute if score #f_h1 ic_tmp <= #f_h2 ic_tmp run return 1
execute if score #f_h2 ic_tmp matches 1.. store result entity @s Health float 0.01 run scoreboard players get #f_h2 ic_tmp
execute if score #f_h2 ic_tmp matches 1.. run return 1
data modify entity @s Health set value 1.0f
scoreboard players set #tri_ok ic_tmp -1
function infectcozy:tridente/remate
execute if score #tri_ok ic_tmp matches -1 run function infectcozy:tridente/remate_alt
