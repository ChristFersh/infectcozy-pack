# Primer impacto del Tridente del Abismo (#tri_ent = 1 si golpeo a una criatura, 0 si cayo en un bloque).
tag @s add ic_tri_boom
# Encantamientos de dano del tridente lanzado (bono en el golpe directo)
scoreboard players set #t_sh ic_tmp 0
execute store result score #t_sh ic_tmp run data get entity @s item.components."minecraft:enchantments".levels."minecraft:sharpness"
scoreboard players set #t_sm ic_tmp 0
execute store result score #t_sm ic_tmp run data get entity @s item.components."minecraft:enchantments".levels."minecraft:smite"
scoreboard players set #t_ba ic_tmp 0
execute store result score #t_ba ic_tmp run data get entity @s item.components."minecraft:enchantments".levels."minecraft:bane_of_arthropods"
scoreboard players set #t_im ic_tmp 0
execute store result score #t_im ic_tmp run data get entity @s item.components."minecraft:enchantments".levels."minecraft:impaling"
execute on origin if entity @s[type=minecraft:player] run tag @s add ic_dueno
# Cargas que se llevo este lanzamiento
scoreboard players add @s ic_tri_lanzas 0
scoreboard players operation #tri_l ic_tmp = @s ic_tri_lanzas
# Furia: una tirada por lanzamiento (con la suerte del dueno si esta conectado)
execute if entity @a[tag=ic_dueno] as @a[tag=ic_dueno,limit=1] run function infectcozy:tridente/calc_prob
execute unless entity @a[tag=ic_dueno] run function infectcozy:tridente/calc_prob
# Copias extra del multidisparo: nunca Furia
execute if entity @s[tag=ic_tri_extra] run scoreboard players set #tri_prob ic_tmp 0
scoreboard players set #tri_crit ic_tmp 0
execute store result score #tri_r ic_tmp run random value 1..1000
execute if score #tri_r ic_tmp <= #tri_prob ic_tmp run scoreboard players set #tri_crit ic_tmp 1
# Golpe directo a la criatura acertada
tag @e[tag=ic_tri_obj] remove ic_tri_obj
execute if score #tri_ent ic_tmp matches 1 run function infectcozy:tridente/buscar_objetivo
execute as @e[tag=ic_tri_obj,limit=1] at @s run function infectcozy:tridente/golpe
# Onda expansiva: si salio la Furia, 150 de dano verdadero a todo lo que alcance; si no, la explosion normal
execute if score #tri_crit ic_tmp matches 1 run function infectcozy:tridente/critico
execute if score #tri_crit ic_tmp matches 0 run function infectcozy:tridente/explosion
tag @e[tag=ic_tri_obj] remove ic_tri_obj
tag @a[tag=ic_dueno] remove ic_dueno
# Las copias extra del Multidisparo se quedan clavadas como la principal (sin cargas ni Furia)
