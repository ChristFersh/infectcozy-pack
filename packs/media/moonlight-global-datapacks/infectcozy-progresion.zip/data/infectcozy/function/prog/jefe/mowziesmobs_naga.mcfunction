# [1.6] no cuenta para la amenaza: es un jefe menor
tellraw @a [{"text":"⚔ ","color":"gold"},{"selector":"@s","color":"yellow","bold":true},{"text":" derroto a ","color":"gray"},{"text":"una Naga","color":"red","bold":true},{"text":" por primera vez","color":"gray"}]
title @s times 10 60 20
title @s title {"text":"¡Jefe derrotado!","color":"gold","bold":true}
title @s subtitle {"text":"una Naga","color":"red"}
xp add @s 500 points
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1
