scoreboard players set @s amenaza 0
scoreboard players enable @s amenaza
scoreboard players add @s ic_amz_n 0
tellraw @s [{"text":"☣ Nivel de amenaza: ","color":"dark_red"},{"score":{"name":"@s","objective":"ic_amz_n"},"color":"red","bold":true},{"text":"/5  (puntaje ","color":"gray"},{"score":{"name":"@s","objective":"ic_amz_g"},"color":"white"},{"text":": armadura ","color":"gray"},{"score":{"name":"@s","objective":"ic_amz_arm"},"color":"white"},{"text":" + ataque ","color":"gray"},{"score":{"name":"@s","objective":"ic_amz_atk"},"color":"white"},{"text":" + 3 x jefes ","color":"gray"},{"score":{"name":"@s","objective":"ic_jefes"},"color":"white"},{"text":")","color":"gray"}]
tellraw @s {"text":"Niveles: 20 / 32 / 48 / 75 puntos. Los enemigos que aparecen toman el nivel del jugador mas cercano. Cuenta el equipo que llevas (armadura hasta 20).","color":"dark_gray"}
