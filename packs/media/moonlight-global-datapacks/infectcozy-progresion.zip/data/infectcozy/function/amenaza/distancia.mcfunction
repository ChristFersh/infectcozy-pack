# dano de arco o ballesta (Ranged Weapon API): deja el mayor en #k
execute store result score #b ic_tmp run attribute @s ranged_weapon:damage get 1
execute if score #b ic_tmp > #k ic_tmp run scoreboard players operation #k ic_tmp = #b ic_tmp
