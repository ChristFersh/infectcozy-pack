# infectcozy:amenaza/mob  (como el enemigo; #amz_l = nivel)
tag @s add ic_amz
# solo criaturas que atacan, sin dueno, que no sean jefes (vida base de 150 o mas)
execute store success score #ok ic_tmp run attribute @s minecraft:generic.attack_damage base get
execute if score #ok ic_tmp matches 0 run return 0
execute on owner run return 0
execute if entity @s[type=#c:bosses] run return 0
execute store result score #hp ic_tmp run attribute @s minecraft:generic.max_health base get 1
execute if score #hp ic_tmp matches 150.. run return 0
scoreboard players operation @s ic_amz = #amz_l ic_tmp
execute if score #amz_l ic_tmp matches 2 run function infectcozy:amenaza/buff2
execute if score #amz_l ic_tmp matches 3 run function infectcozy:amenaza/buff3
execute if score #amz_l ic_tmp matches 4 run function infectcozy:amenaza/buff4
execute if score #amz_l ic_tmp matches 5 run function infectcozy:amenaza/buff5
# cerca de un novato no salen campeones
execute if score #amz_camp ic_amz matches 1 if score #amz_nov ic_tmp matches 0 run function infectcozy:amenaza/campeon
execute store result entity @s Health float 1 run attribute @s minecraft:generic.max_health get 1
