# infectcozy:campeones/elegir  (como y en el mob elegido)
tag @s add ic_camp_x
execute if entity @s[nbt={NoAI:1b}] run return 0
execute if entity @s[nbt={Invulnerable:1b}] run return 0
execute if data entity @s CustomName run return 0
# Ya es campeon natural: no se toca
execute if data entity @s "neoforge:attachments"."champions:champion_data".tier run return 0
# Rango
scoreboard players operation #camp_rank ic_camp = #camp_base ic_camp
execute store result score #camp_r ic_camp run random value 1..100
execute if score #camp_r ic_camp <= #camp_sube ic_camp run scoreboard players add #camp_rank ic_camp 1
# Nunca por encima del nivel de amenaza del jugador al que vino a buscar
execute if score #camp_rank ic_camp > #camp_pl ic_camp run scoreboard players operation #camp_rank ic_camp = #camp_pl ic_camp
function infectcozy:campeones/aplicar
tag @s add ic_camp
effect give @s minecraft:glowing 12 0 true
particle minecraft:sculk_soul ~ ~1 ~ 0.6 1 0.6 0.05 40 force
particle minecraft:spore_blossom_air ~ ~1 ~ 1.5 1.5 1.5 0 80 force
particle minecraft:dust{color:[0.35,0.75,0.2],scale:1.6} ~ ~1 ~ 0.8 1.2 0.8 0 60 force
playsound minecraft:entity.warden.roar hostile @a[distance=..48] ~ ~ ~ 0.8 0.6
playsound minecraft:entity.elder_guardian.curse hostile @a[distance=..48] ~ ~ ~ 0.5 0.5
tellraw @a[distance=..64] [{"text":"☣ ","color":"dark_green"},{"text":"La colmena ha coronado a ","color":"green"},{"selector":"@s","color":"white"},{"text":" como campeón (rango ","color":"green"},{"score":{"name":"#camp_rank","objective":"ic_camp"},"color":"gold"},{"text":").","color":"green"}]
