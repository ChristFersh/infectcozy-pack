# infectcozy:amanecer/actualizar  (como el jugador) piezas del Ultimo Amanecer fabricadas antes de la 1.6: nuevos valores
execute if items entity @s armor.head *[minecraft:custom_data~{ic_amanecer:1b}] unless items entity @s armor.head *[minecraft:custom_data~{ic_amz_v:2b}] run item modify entity @s armor.head infectcozy:amanecer/head
execute if items entity @s armor.chest *[minecraft:custom_data~{ic_amanecer:1b}] unless items entity @s armor.chest *[minecraft:custom_data~{ic_amz_v:2b}] run item modify entity @s armor.chest infectcozy:amanecer/chest
execute if items entity @s armor.legs *[minecraft:custom_data~{ic_amanecer:1b}] unless items entity @s armor.legs *[minecraft:custom_data~{ic_amz_v:2b}] run item modify entity @s armor.legs infectcozy:amanecer/legs
execute if items entity @s armor.feet *[minecraft:custom_data~{ic_amanecer:1b}] unless items entity @s armor.feet *[minecraft:custom_data~{ic_amz_v:2b}] run item modify entity @s armor.feet infectcozy:amanecer/feet
