scoreboard players enable @a amenaza
# cada minuto (12 pasadas de 5 s) lo guardado de cada jugador baja 1 punto
scoreboard players add #amz_m ic_amz 1
scoreboard players set #amz_dec ic_amz 0
execute if score #amz_m ic_amz matches 12.. run scoreboard players set #amz_dec ic_amz 1
execute if score #amz_m ic_amz matches 12.. run scoreboard players set #amz_m ic_amz 0
execute as @a[gamemode=!creative,gamemode=!spectator] run function infectcozy:amenaza/calcular
