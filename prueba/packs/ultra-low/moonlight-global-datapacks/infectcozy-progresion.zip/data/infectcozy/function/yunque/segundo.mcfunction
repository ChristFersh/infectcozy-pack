scoreboard players set #yq_t ic_enc 0
execute as @e[type=minecraft:marker,tag=ic_yq] at @s run function infectcozy:yunque/revisar
