scoreboard players set #hito ic_mec 10
tellraw @a [{"text":"[La Colmena] ","color":"dark_red","bold":true},{"text":"La tierra empieza a pudrirse. Algo se mueve bajo el suelo...","color":"dark_green","italic":true}]
execute as @a at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.6
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.5
