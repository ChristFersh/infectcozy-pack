scoreboard objectives add ic_mec dummy
scoreboard objectives add ic_muertes deathCount {"text":"Muertes","color":"red"}
scoreboard objectives add ic_infectados dummy {"text":"Infectados eliminados","color":"dark_green"}
scoreboard objectives setdisplay list ic_muertes
schedule function infectcozy:mec/cada_minuto 60s replace
