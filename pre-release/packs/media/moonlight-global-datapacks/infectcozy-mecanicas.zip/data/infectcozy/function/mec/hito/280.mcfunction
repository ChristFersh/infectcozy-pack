scoreboard players set #hito ic_mec 280
tellraw @a [{"text":"[La Colmena] ","color":"dark_red","bold":true},{"text":"MEDIANOCHE. La ultima Ordalia ha comenzado.","color":"dark_red","italic":true}]
execute as @a at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.6
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.5
