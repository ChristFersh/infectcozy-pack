scoreboard players set #hito ic_mec 70
tellraw @a [{"text":"[La Colmena] ","color":"dark_red","bold":true},{"text":"LA PRIMERA ORDALIA SE ACERCA.","color":"gold","italic":true}]
execute as @a at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.6
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.5
