scoreboard players add @s ic_infectados 1
advancement revoke @s only infectcozy:mec/mato_infectado
