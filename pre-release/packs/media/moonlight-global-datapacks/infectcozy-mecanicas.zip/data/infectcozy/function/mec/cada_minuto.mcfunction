# revisa la corrupcion de Spore Inquisition una vez por minuto
schedule function infectcozy:mec/cada_minuto 60s replace
execute unless score #hito ic_mec matches 0.. run scoreboard players set #hito ic_mec 0
execute if score !finale proto matches 10.. unless score #hito ic_mec matches 10.. run function infectcozy:mec/hito/10
execute if score !finale proto matches 25.. unless score #hito ic_mec matches 25.. run function infectcozy:mec/hito/25
execute if score !finale proto matches 50.. unless score #hito ic_mec matches 50.. run function infectcozy:mec/hito/50
execute if score !finale proto matches 70.. unless score #hito ic_mec matches 70.. run function infectcozy:mec/hito/70
execute if score !finale proto matches 140.. unless score #hito ic_mec matches 140.. run function infectcozy:mec/hito/140
execute if score !finale proto matches 210.. unless score #hito ic_mec matches 210.. run function infectcozy:mec/hito/210
execute if score !finale proto matches 280.. unless score #hito ic_mec matches 280.. run function infectcozy:mec/hito/280
