# Infect Cozy: version optimizada de wide_mining:check/prepare
# Solo se llama si el item de la mano tiene Wide Mining (el mod solo usa el nivel 1).
scoreboard players set @s .wide_mining.level 1
scoreboard players operation $active .wide_mining.target_owner = @s .wide_mining.player_id
tag @e[type=minecraft:item_display,tag=wide_mining.target.owner_match] remove wide_mining.target.owner_match
tag @e[type=minecraft:item_display,tag=wide_mining.target.ready] remove wide_mining.target.ready
tag @e[type=minecraft:item_display,tag=wide_mining.target.selected] remove wide_mining.target.selected
execute as @e[type=minecraft:item_display,tag=wide_mining.target] if score @s .wide_mining.target_owner = $active .wide_mining.target_owner run tag @s add wide_mining.target.owner_match
function wide_mining:check/check_tool
tag @e[type=minecraft:item_display,tag=wide_mining.target.owner_match] remove wide_mining.target.owner_match
tag @e[type=minecraft:item_display,tag=wide_mining.target.ready] remove wide_mining.target.ready
tag @e[type=minecraft:item_display,tag=wide_mining.target.selected] remove wide_mining.target.selected
