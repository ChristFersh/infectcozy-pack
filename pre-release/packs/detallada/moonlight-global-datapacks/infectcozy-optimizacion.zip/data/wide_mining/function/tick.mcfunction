# Infect Cozy: version optimizada de wide_mining:tick
# El original usaba "if data entity @s SelectedItem..." hasta 5 veces por tick y por jugador:
# eso guarda TODO el NBT del jugador (incluido el libro de recetas) cada vez y bajaba el TPS a ~5.
# "if items" revisa solo el item de la mano, sin serializar al jugador.
execute in minecraft:overworld run scoreboard players add @e[type=minecraft:item_display,tag=wide_mining.target] .wide_mining.target_age 1
execute in minecraft:the_nether run scoreboard players add @e[type=minecraft:item_display,tag=wide_mining.target] .wide_mining.target_age 1
execute in minecraft:the_end run scoreboard players add @e[type=minecraft:item_display,tag=wide_mining.target] .wide_mining.target_age 1
execute in minecraft:overworld as @e[type=minecraft:item_display,tag=wide_mining.target,scores={.wide_mining.target_age=12001..}] run function wide_mining:target/discard
execute in minecraft:the_nether as @e[type=minecraft:item_display,tag=wide_mining.target,scores={.wide_mining.target_age=12001..}] run function wide_mining:target/discard
execute in minecraft:the_end as @e[type=minecraft:item_display,tag=wide_mining.target,scores={.wide_mining.target_age=12001..}] run function wide_mining:target/discard
execute as @a unless score @s .wide_mining.player_id matches 1.. run function wide_mining:target/assign_player
execute as @a at @s unless items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"wide_mining:wide_mining"}]] run function wide_mining:target/cancel_unarmed
execute as @a at @s if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"wide_mining:wide_mining"}]] run function wide_mining:check/prepare
